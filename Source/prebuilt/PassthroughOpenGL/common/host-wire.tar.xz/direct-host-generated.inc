/* Generated from Mavericks SDK; do not edit. */
case 0: {
    GLenum op=0;memcpy(&op,&dg_wire_message->args[0],sizeof(op));
    GLfloat value=0;memcpy(&value,&dg_wire_message->args[1],sizeof(value));
    DGHostAccumulation(context,op,value,0);
    return 0;
}
case 1: {
    GLenum func=0;memcpy(&func,&dg_wire_message->args[0],sizeof(func));
    GLclampf ref=0;memcpy(&ref,&dg_wire_message->args[1],sizeof(ref));
    typedef void (*Proc)(GLenum func, GLclampf ref);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glAlphaFunc");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(func,ref);
    return 0;
}
case 2: {
    GLsizei n=0;memcpy(&n,&dg_wire_message->args[0],sizeof(n));
    const GLuint * textures=NULL;
    GLboolean * residences=NULL;
    textures=(const GLuint *)DGHostPointer(dg_wire_message,1,((DGQueryArrayBytes(n,sizeof(GLuint))) ? (DGQueryArrayBytes(n,sizeof(GLuint))) : 1));
    if(!textures) return -1;
    residences=(GLboolean *)DGHostPointer(dg_wire_message,2,((DGQueryArrayBytes(n,sizeof(GLboolean))) ? (DGQueryArrayBytes(n,sizeof(GLboolean))) : 1));
    if(!residences) return -1;
    typedef GLboolean (*Proc)(GLsizei n, const GLuint *textures, GLboolean *residences);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glAreTexturesResident");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    if(n>=0 && !context->inside_begin)for(GLsizei i=0;i<n;++i)
        if(DGPrivateTextureContains(context->alias_group->private_textures,textures[i])){context->error=GL_INVALID_VALUE;reply->result=GL_FALSE;return 0;}
    GLboolean result=proc(n,textures,residences);
    reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 3: return DGHostArrayElement(context,dg_wire_message);
case 4: {
    GLenum mode=0;memcpy(&mode,&dg_wire_message->args[0],sizeof(mode));
    typedef void (*Proc)(GLenum mode);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glBegin");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    if(dg_diagnostics && !context->inside_begin) DGTraceProgram(context,dg_wire_message,NULL,0);
    DGPrepareDrawableAliases(context,0);
    if(!DGDrawableWritable(context)) return 0;
    proc(mode);
    context->inside_begin=1;
    return 0;
}
case 5: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint texture=0;memcpy(&texture,&dg_wire_message->args[1],sizeof(texture));
    typedef void (*Proc)(GLenum target, GLuint texture);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glBindTexture");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    if(texture && !context->inside_begin && (target==GL_TEXTURE_1D || target==GL_TEXTURE_2D || target==GL_TEXTURE_3D || target==GL_TEXTURE_CUBE_MAP || target==GL_TEXTURE_RECTANGLE_ARB) && DGPrivateTextureContains(context->alias_group->private_textures,texture)){
        GLenum prior=glGetError();if(prior && !context->error)context->error=prior;
        GLenum moved=DGPrivateTextureClaim(context->alias_group->private_textures,texture);
        if(moved){if(!context->error)context->error=moved;return 0;}
    }
    proc(target,texture);
    if(dg_diagnostics && !context->inside_begin){
        GLenum error=glGetError();if(error){if(!context->error)context->error=error;
            if(context->texture_debug_count++<32)fprintf(stderr,"PassthroughOpenGL native bind failed context=%p target=%x texture=%u error=%x\n",(void *)context,target,texture,error);}
    }
    DGRecordAliasBinding(context,target);
    return 0;
}
case 6: {
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[0],sizeof(width));
    GLsizei height=0;memcpy(&height,&dg_wire_message->args[1],sizeof(height));
    GLfloat xorig=0;memcpy(&xorig,&dg_wire_message->args[2],sizeof(xorig));
    GLfloat yorig=0;memcpy(&yorig,&dg_wire_message->args[3],sizeof(yorig));
    GLfloat xmove=0;memcpy(&xmove,&dg_wire_message->args[4],sizeof(xmove));
    GLfloat ymove=0;memcpy(&ymove,&dg_wire_message->args[5],sizeof(ymove));
    const GLubyte * bitmap=NULL;
    void *pixel_pointer=NULL;
    int admitted=DGHostCompatRasterPointer(context,dg_wire_message,width,height,GL_COLOR_INDEX,GL_BITMAP,6,0,&pixel_pointer);
    if(admitted<=0)return admitted;bitmap=(const GLubyte *)pixel_pointer;
    typedef void (*Proc)(GLsizei width, GLsizei height, GLfloat xorig, GLfloat yorig, GLfloat xmove, GLfloat ymove, const GLubyte *bitmap);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glBitmap");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    DGPrepareDrawableAliases(context,0);
    if(!DGDrawableWritable(context)) return 0;
    proc(width,height,xorig,yorig,xmove,ymove,bitmap);
    DGMarkDrawableDamage(context);
    return 0;
}
case 7: {
    GLenum sfactor=0;memcpy(&sfactor,&dg_wire_message->args[0],sizeof(sfactor));
    GLenum dfactor=0;memcpy(&dfactor,&dg_wire_message->args[1],sizeof(dfactor));
    typedef void (*Proc)(GLenum sfactor, GLenum dfactor);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glBlendFunc");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(sfactor,dfactor);
    return 0;
}
case 8: {
    GLuint list=0;memcpy(&list,&dg_wire_message->args[0],sizeof(list));
    typedef void (*Proc)(GLuint list);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glCallList");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    DGPrepareDrawableAliases(context,1);
    if(!DGDrawableWritable(context)) return 0;
#ifdef VIM_ALIAS_REBIND_EXPERIMENT
    DGInvalidateAliasStorage(context);
#endif
    proc(list);
    DGForgetUniformShapes(context,0);
    context->alias_bindings_dirty=1;
    context->iosurface_draw_dirty=1;
    context->iosurface_mark_all=1;
    DGMarkDrawableDamage(context);
    return 0;
}
case 9: {
    GLsizei n=0;memcpy(&n,&dg_wire_message->args[0],sizeof(n));
    GLenum type=0;memcpy(&type,&dg_wire_message->args[1],sizeof(type));
    const GLvoid * lists=NULL;
    lists=(const GLvoid *)DGHostPointer(dg_wire_message,2,(DGCallListsBytes(n,type)));
    if((DGCallListsBytes(n,type) && !lists) || (dg_wire_message->args[2] && !lists)) return -1;
    typedef void (*Proc)(GLsizei n, GLenum type, const GLvoid *lists);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glCallLists");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    DGPrepareDrawableAliases(context,1);
    if(!DGDrawableWritable(context)) return 0;
#ifdef VIM_ALIAS_REBIND_EXPERIMENT
    DGInvalidateAliasStorage(context);
#endif
    proc(n,type,lists);
    DGForgetUniformShapes(context,0);
    context->alias_bindings_dirty=1;
    context->iosurface_draw_dirty=1;
    context->iosurface_mark_all=1;
    DGMarkDrawableDamage(context);
    return 0;
}
case 10: {
    GLbitfield mask=0;memcpy(&mask,&dg_wire_message->args[0],sizeof(mask));
    if(!DGDrawableWritable(context))return 0;
    DGHostClear(context,mask);
    return 0;
}
case 11: {
    GLfloat red=0;memcpy(&red,&dg_wire_message->args[0],sizeof(red));
    GLfloat green=0;memcpy(&green,&dg_wire_message->args[1],sizeof(green));
    GLfloat blue=0;memcpy(&blue,&dg_wire_message->args[2],sizeof(blue));
    GLfloat alpha=0;memcpy(&alpha,&dg_wire_message->args[3],sizeof(alpha));
    typedef void (*Proc)(GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glClearAccum");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(red,green,blue,alpha);
    return 0;
}
case 12: {
    GLclampf red=0;memcpy(&red,&dg_wire_message->args[0],sizeof(red));
    GLclampf green=0;memcpy(&green,&dg_wire_message->args[1],sizeof(green));
    GLclampf blue=0;memcpy(&blue,&dg_wire_message->args[2],sizeof(blue));
    GLclampf alpha=0;memcpy(&alpha,&dg_wire_message->args[3],sizeof(alpha));
    typedef void (*Proc)(GLclampf red, GLclampf green, GLclampf blue, GLclampf alpha);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glClearColor");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(red,green,blue,alpha);
    return 0;
}
case 13: {
    GLclampd depth=0;memcpy(&depth,&dg_wire_message->args[0],sizeof(depth));
    typedef void (*Proc)(GLclampd depth);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glClearDepth");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(depth);
    return 0;
}
case 14: {
    GLfloat c=0;memcpy(&c,&dg_wire_message->args[0],sizeof(c));
    typedef void (*Proc)(GLfloat c);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glClearIndex");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(c);
    return 0;
}
case 15: {
    GLint s=0;memcpy(&s,&dg_wire_message->args[0],sizeof(s));
    typedef void (*Proc)(GLint s);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glClearStencil");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(s);
    return 0;
}
case 16: {
    GLenum plane=0;memcpy(&plane,&dg_wire_message->args[0],sizeof(plane));
    const GLdouble * equation=NULL;
    equation=(const GLdouble *)DGHostPointer(dg_wire_message,1,(4*sizeof(GLdouble)));
    if(!equation) return -1;
    typedef void (*Proc)(GLenum plane, const GLdouble *equation);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glClipPlane");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(plane,equation);
    return 0;
}
case 17: {
    GLbyte red=0;memcpy(&red,&dg_wire_message->args[0],sizeof(red));
    GLbyte green=0;memcpy(&green,&dg_wire_message->args[1],sizeof(green));
    GLbyte blue=0;memcpy(&blue,&dg_wire_message->args[2],sizeof(blue));
    typedef void (*Proc)(GLbyte red, GLbyte green, GLbyte blue);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor3b");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(red,green,blue);
    return 0;
}
case 18: {
    const GLbyte * v=NULL;
    v=(const GLbyte *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLbyte)));
    if(!v) return -1;
    typedef void (*Proc)(const GLbyte *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor3bv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 19: {
    GLdouble red=0;memcpy(&red,&dg_wire_message->args[0],sizeof(red));
    GLdouble green=0;memcpy(&green,&dg_wire_message->args[1],sizeof(green));
    GLdouble blue=0;memcpy(&blue,&dg_wire_message->args[2],sizeof(blue));
    typedef void (*Proc)(GLdouble red, GLdouble green, GLdouble blue);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor3d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(red,green,blue);
    return 0;
}
case 20: {
    const GLdouble * v=NULL;
    v=(const GLdouble *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLdouble)));
    if(!v) return -1;
    typedef void (*Proc)(const GLdouble *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor3dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 21: {
    GLfloat red=0;memcpy(&red,&dg_wire_message->args[0],sizeof(red));
    GLfloat green=0;memcpy(&green,&dg_wire_message->args[1],sizeof(green));
    GLfloat blue=0;memcpy(&blue,&dg_wire_message->args[2],sizeof(blue));
    typedef void (*Proc)(GLfloat red, GLfloat green, GLfloat blue);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor3f");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(red,green,blue);
    return 0;
}
case 22: {
    const GLfloat * v=NULL;
    v=(const GLfloat *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLfloat)));
    if(!v) return -1;
    typedef void (*Proc)(const GLfloat *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor3fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 23: {
    GLint red=0;memcpy(&red,&dg_wire_message->args[0],sizeof(red));
    GLint green=0;memcpy(&green,&dg_wire_message->args[1],sizeof(green));
    GLint blue=0;memcpy(&blue,&dg_wire_message->args[2],sizeof(blue));
    typedef void (*Proc)(GLint red, GLint green, GLint blue);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor3i");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(red,green,blue);
    return 0;
}
case 24: {
    const GLint * v=NULL;
    v=(const GLint *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLint)));
    if(!v) return -1;
    typedef void (*Proc)(const GLint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor3iv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 25: {
    GLshort red=0;memcpy(&red,&dg_wire_message->args[0],sizeof(red));
    GLshort green=0;memcpy(&green,&dg_wire_message->args[1],sizeof(green));
    GLshort blue=0;memcpy(&blue,&dg_wire_message->args[2],sizeof(blue));
    typedef void (*Proc)(GLshort red, GLshort green, GLshort blue);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor3s");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(red,green,blue);
    return 0;
}
case 26: {
    const GLshort * v=NULL;
    v=(const GLshort *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLshort)));
    if(!v) return -1;
    typedef void (*Proc)(const GLshort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor3sv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 27: {
    GLubyte red=0;memcpy(&red,&dg_wire_message->args[0],sizeof(red));
    GLubyte green=0;memcpy(&green,&dg_wire_message->args[1],sizeof(green));
    GLubyte blue=0;memcpy(&blue,&dg_wire_message->args[2],sizeof(blue));
    typedef void (*Proc)(GLubyte red, GLubyte green, GLubyte blue);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor3ub");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(red,green,blue);
    return 0;
}
case 28: {
    const GLubyte * v=NULL;
    v=(const GLubyte *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLubyte)));
    if(!v) return -1;
    typedef void (*Proc)(const GLubyte *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor3ubv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 29: {
    GLuint red=0;memcpy(&red,&dg_wire_message->args[0],sizeof(red));
    GLuint green=0;memcpy(&green,&dg_wire_message->args[1],sizeof(green));
    GLuint blue=0;memcpy(&blue,&dg_wire_message->args[2],sizeof(blue));
    typedef void (*Proc)(GLuint red, GLuint green, GLuint blue);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor3ui");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(red,green,blue);
    return 0;
}
case 30: {
    const GLuint * v=NULL;
    v=(const GLuint *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLuint)));
    if(!v) return -1;
    typedef void (*Proc)(const GLuint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor3uiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 31: {
    GLushort red=0;memcpy(&red,&dg_wire_message->args[0],sizeof(red));
    GLushort green=0;memcpy(&green,&dg_wire_message->args[1],sizeof(green));
    GLushort blue=0;memcpy(&blue,&dg_wire_message->args[2],sizeof(blue));
    typedef void (*Proc)(GLushort red, GLushort green, GLushort blue);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor3us");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(red,green,blue);
    return 0;
}
case 32: {
    const GLushort * v=NULL;
    v=(const GLushort *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLushort)));
    if(!v) return -1;
    typedef void (*Proc)(const GLushort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor3usv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 33: {
    GLbyte red=0;memcpy(&red,&dg_wire_message->args[0],sizeof(red));
    GLbyte green=0;memcpy(&green,&dg_wire_message->args[1],sizeof(green));
    GLbyte blue=0;memcpy(&blue,&dg_wire_message->args[2],sizeof(blue));
    GLbyte alpha=0;memcpy(&alpha,&dg_wire_message->args[3],sizeof(alpha));
    typedef void (*Proc)(GLbyte red, GLbyte green, GLbyte blue, GLbyte alpha);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor4b");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(red,green,blue,alpha);
    return 0;
}
case 34: {
    const GLbyte * v=NULL;
    v=(const GLbyte *)DGHostPointer(dg_wire_message,0,(4*sizeof(GLbyte)));
    if(!v) return -1;
    typedef void (*Proc)(const GLbyte *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor4bv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 35: {
    GLdouble red=0;memcpy(&red,&dg_wire_message->args[0],sizeof(red));
    GLdouble green=0;memcpy(&green,&dg_wire_message->args[1],sizeof(green));
    GLdouble blue=0;memcpy(&blue,&dg_wire_message->args[2],sizeof(blue));
    GLdouble alpha=0;memcpy(&alpha,&dg_wire_message->args[3],sizeof(alpha));
    typedef void (*Proc)(GLdouble red, GLdouble green, GLdouble blue, GLdouble alpha);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor4d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(red,green,blue,alpha);
    return 0;
}
case 36: {
    const GLdouble * v=NULL;
    v=(const GLdouble *)DGHostPointer(dg_wire_message,0,(4*sizeof(GLdouble)));
    if(!v) return -1;
    typedef void (*Proc)(const GLdouble *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor4dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 37: {
    GLfloat red=0;memcpy(&red,&dg_wire_message->args[0],sizeof(red));
    GLfloat green=0;memcpy(&green,&dg_wire_message->args[1],sizeof(green));
    GLfloat blue=0;memcpy(&blue,&dg_wire_message->args[2],sizeof(blue));
    GLfloat alpha=0;memcpy(&alpha,&dg_wire_message->args[3],sizeof(alpha));
    typedef void (*Proc)(GLfloat red, GLfloat green, GLfloat blue, GLfloat alpha);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor4f");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(red,green,blue,alpha);
    return 0;
}
case 38: {
    const GLfloat * v=NULL;
    v=(const GLfloat *)DGHostPointer(dg_wire_message,0,(4*sizeof(GLfloat)));
    if(!v) return -1;
    typedef void (*Proc)(const GLfloat *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor4fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 39: {
    GLint red=0;memcpy(&red,&dg_wire_message->args[0],sizeof(red));
    GLint green=0;memcpy(&green,&dg_wire_message->args[1],sizeof(green));
    GLint blue=0;memcpy(&blue,&dg_wire_message->args[2],sizeof(blue));
    GLint alpha=0;memcpy(&alpha,&dg_wire_message->args[3],sizeof(alpha));
    typedef void (*Proc)(GLint red, GLint green, GLint blue, GLint alpha);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor4i");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(red,green,blue,alpha);
    return 0;
}
case 40: {
    const GLint * v=NULL;
    v=(const GLint *)DGHostPointer(dg_wire_message,0,(4*sizeof(GLint)));
    if(!v) return -1;
    typedef void (*Proc)(const GLint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor4iv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 41: {
    GLshort red=0;memcpy(&red,&dg_wire_message->args[0],sizeof(red));
    GLshort green=0;memcpy(&green,&dg_wire_message->args[1],sizeof(green));
    GLshort blue=0;memcpy(&blue,&dg_wire_message->args[2],sizeof(blue));
    GLshort alpha=0;memcpy(&alpha,&dg_wire_message->args[3],sizeof(alpha));
    typedef void (*Proc)(GLshort red, GLshort green, GLshort blue, GLshort alpha);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor4s");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(red,green,blue,alpha);
    return 0;
}
case 42: {
    const GLshort * v=NULL;
    v=(const GLshort *)DGHostPointer(dg_wire_message,0,(4*sizeof(GLshort)));
    if(!v) return -1;
    typedef void (*Proc)(const GLshort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor4sv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 43: {
    GLubyte red=0;memcpy(&red,&dg_wire_message->args[0],sizeof(red));
    GLubyte green=0;memcpy(&green,&dg_wire_message->args[1],sizeof(green));
    GLubyte blue=0;memcpy(&blue,&dg_wire_message->args[2],sizeof(blue));
    GLubyte alpha=0;memcpy(&alpha,&dg_wire_message->args[3],sizeof(alpha));
    typedef void (*Proc)(GLubyte red, GLubyte green, GLubyte blue, GLubyte alpha);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor4ub");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(red,green,blue,alpha);
    return 0;
}
case 44: {
    const GLubyte * v=NULL;
    v=(const GLubyte *)DGHostPointer(dg_wire_message,0,(4*sizeof(GLubyte)));
    if(!v) return -1;
    typedef void (*Proc)(const GLubyte *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor4ubv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 45: {
    GLuint red=0;memcpy(&red,&dg_wire_message->args[0],sizeof(red));
    GLuint green=0;memcpy(&green,&dg_wire_message->args[1],sizeof(green));
    GLuint blue=0;memcpy(&blue,&dg_wire_message->args[2],sizeof(blue));
    GLuint alpha=0;memcpy(&alpha,&dg_wire_message->args[3],sizeof(alpha));
    typedef void (*Proc)(GLuint red, GLuint green, GLuint blue, GLuint alpha);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor4ui");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(red,green,blue,alpha);
    return 0;
}
case 46: {
    const GLuint * v=NULL;
    v=(const GLuint *)DGHostPointer(dg_wire_message,0,(4*sizeof(GLuint)));
    if(!v) return -1;
    typedef void (*Proc)(const GLuint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor4uiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 47: {
    GLushort red=0;memcpy(&red,&dg_wire_message->args[0],sizeof(red));
    GLushort green=0;memcpy(&green,&dg_wire_message->args[1],sizeof(green));
    GLushort blue=0;memcpy(&blue,&dg_wire_message->args[2],sizeof(blue));
    GLushort alpha=0;memcpy(&alpha,&dg_wire_message->args[3],sizeof(alpha));
    typedef void (*Proc)(GLushort red, GLushort green, GLushort blue, GLushort alpha);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor4us");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(red,green,blue,alpha);
    return 0;
}
case 48: {
    const GLushort * v=NULL;
    v=(const GLushort *)DGHostPointer(dg_wire_message,0,(4*sizeof(GLushort)));
    if(!v) return -1;
    typedef void (*Proc)(const GLushort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColor4usv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 49: {
    GLboolean red=0;memcpy(&red,&dg_wire_message->args[0],sizeof(red));
    GLboolean green=0;memcpy(&green,&dg_wire_message->args[1],sizeof(green));
    GLboolean blue=0;memcpy(&blue,&dg_wire_message->args[2],sizeof(blue));
    GLboolean alpha=0;memcpy(&alpha,&dg_wire_message->args[3],sizeof(alpha));
    typedef void (*Proc)(GLboolean red, GLboolean green, GLboolean blue, GLboolean alpha);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColorMask");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(red,green,blue,alpha);
    return 0;
}
case 50: {
    GLenum face=0;memcpy(&face,&dg_wire_message->args[0],sizeof(face));
    GLenum mode=0;memcpy(&mode,&dg_wire_message->args[1],sizeof(mode));
    typedef void (*Proc)(GLenum face, GLenum mode);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColorMaterial");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(face,mode);
    return 0;
}
case 52: {
    GLint x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLint y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[2],sizeof(width));
    GLsizei height=0;memcpy(&height,&dg_wire_message->args[3],sizeof(height));
    GLenum type=0;memcpy(&type,&dg_wire_message->args[4],sizeof(type));
    typedef void (*Proc)(GLint x, GLint y, GLsizei width, GLsizei height, GLenum type);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glCopyPixels");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    DGPrepareDrawableAliases(context,0);
    if(!DGDrawableWritable(context)) return 0;
    proc(x,y,width,height,type);
    DGMarkDrawableDamage(context);
    return 0;
}
case 53: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLint level=0;memcpy(&level,&dg_wire_message->args[1],sizeof(level));
    GLenum internalFormat=0;memcpy(&internalFormat,&dg_wire_message->args[2],sizeof(internalFormat));
    GLint x=0;memcpy(&x,&dg_wire_message->args[3],sizeof(x));
    GLint y=0;memcpy(&y,&dg_wire_message->args[4],sizeof(y));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[5],sizeof(width));
    GLint border=0;memcpy(&border,&dg_wire_message->args[6],sizeof(border));
    typedef void (*Proc)(GLenum target, GLint level, GLenum internalFormat, GLint x, GLint y, GLsizei width, GLint border);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glCopyTexImage1D");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    struct DGAutomaticMipmapScope automatic=DGBeginAutomaticMipmap(target,level,context->profile==kCGLOGLPVersion_Legacy,context->inside_begin,context->list_mode,&context->error,1,DGNonzeroMipmapBasePossible(context));
    proc(target,level,internalFormat,x,y,width,border);
    DGEndAutomaticMipmap(&automatic,NULL,&context->error);
    return 0;
}
case 54: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLint level=0;memcpy(&level,&dg_wire_message->args[1],sizeof(level));
    GLenum internalFormat=0;memcpy(&internalFormat,&dg_wire_message->args[2],sizeof(internalFormat));
    GLint x=0;memcpy(&x,&dg_wire_message->args[3],sizeof(x));
    GLint y=0;memcpy(&y,&dg_wire_message->args[4],sizeof(y));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[5],sizeof(width));
    GLsizei height=0;memcpy(&height,&dg_wire_message->args[6],sizeof(height));
    GLint border=0;memcpy(&border,&dg_wire_message->args[7],sizeof(border));
    typedef void (*Proc)(GLenum target, GLint level, GLenum internalFormat, GLint x, GLint y, GLsizei width, GLsizei height, GLint border);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glCopyTexImage2D");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLuint redefining_alias=DGBeginAliasRedefinition(context,target,level);
    struct DGAutomaticMipmapScope automatic=DGBeginAutomaticMipmap(target,level,context->profile==kCGLOGLPVersion_Legacy,context->inside_begin,context->list_mode,&context->error,1,DGNonzeroMipmapBasePossible(context));
    proc(target,level,internalFormat,x,y,width,height,border);
    DGEndAliasRedefinition(context,redefining_alias);
    DGEndAutomaticMipmap(&automatic,NULL,&context->error);
    return 0;
}
case 55: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLint level=0;memcpy(&level,&dg_wire_message->args[1],sizeof(level));
    GLint xoffset=0;memcpy(&xoffset,&dg_wire_message->args[2],sizeof(xoffset));
    GLint x=0;memcpy(&x,&dg_wire_message->args[3],sizeof(x));
    GLint y=0;memcpy(&y,&dg_wire_message->args[4],sizeof(y));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[5],sizeof(width));
    typedef void (*Proc)(GLenum target, GLint level, GLint xoffset, GLint x, GLint y, GLsizei width);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glCopyTexSubImage1D");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    struct DGAutomaticMipmapScope automatic=DGBeginAutomaticMipmap(target,level,context->profile==kCGLOGLPVersion_Legacy,context->inside_begin,context->list_mode,&context->error,1,DGNonzeroMipmapBasePossible(context));
    proc(target,level,xoffset,x,y,width);
    DGEndAutomaticMipmap(&automatic,NULL,&context->error);
    return 0;
}
case 56: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLint level=0;memcpy(&level,&dg_wire_message->args[1],sizeof(level));
    GLint xoffset=0;memcpy(&xoffset,&dg_wire_message->args[2],sizeof(xoffset));
    GLint yoffset=0;memcpy(&yoffset,&dg_wire_message->args[3],sizeof(yoffset));
    GLint x=0;memcpy(&x,&dg_wire_message->args[4],sizeof(x));
    GLint y=0;memcpy(&y,&dg_wire_message->args[5],sizeof(y));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[6],sizeof(width));
    GLsizei height=0;memcpy(&height,&dg_wire_message->args[7],sizeof(height));
    typedef void (*Proc)(GLenum target, GLint level, GLint xoffset, GLint yoffset, GLint x, GLint y, GLsizei width, GLsizei height);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glCopyTexSubImage2D");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    struct DGAutomaticMipmapScope automatic=DGBeginAutomaticMipmap(target,level,context->profile==kCGLOGLPVersion_Legacy,context->inside_begin,context->list_mode,&context->error,1,DGNonzeroMipmapBasePossible(context));
    proc(target,level,xoffset,yoffset,x,y,width,height);
    DGEndAutomaticMipmap(&automatic,NULL,&context->error);
    DGMarkIOSurfaceTextureWrite(context,target);
    return 0;
}
case 57: {
    GLenum mode=0;memcpy(&mode,&dg_wire_message->args[0],sizeof(mode));
    typedef void (*Proc)(GLenum mode);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glCullFace");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(mode);
    return 0;
}
case 58: {
    GLuint list=0;memcpy(&list,&dg_wire_message->args[0],sizeof(list));
    GLsizei range=0;memcpy(&range,&dg_wire_message->args[1],sizeof(range));
    typedef void (*Proc)(GLuint list, GLsizei range);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glDeleteLists");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(list,range);
    return 0;
}
case 59: {
    GLsizei n=0;memcpy(&n,&dg_wire_message->args[0],sizeof(n));
    const GLuint * textures=NULL;
    textures=(const GLuint *)DGHostPointer(dg_wire_message,1,(DGArrayBytes(n,sizeof(GLuint))));
    if(!textures) return -1;
    typedef void (*Proc)(GLsizei n, const GLuint *textures);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glDeleteTextures");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    if(n>=0 && !context->inside_begin){
        for(GLsizei i=0;i<n;++i)if(!DGPrivateTextureContains(context->alias_group->private_textures,textures[i]))proc(1,textures+i);
        DGForgetAliases(context,n,textures);return 0;
    }
    proc(n,textures);
    DGForgetAliases(context,n,textures);
    return 0;
}
case 60: {
    GLenum func=0;memcpy(&func,&dg_wire_message->args[0],sizeof(func));
    typedef void (*Proc)(GLenum func);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glDepthFunc");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(func);
    return 0;
}
case 61: {
    GLboolean flag=0;memcpy(&flag,&dg_wire_message->args[0],sizeof(flag));
    typedef void (*Proc)(GLboolean flag);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glDepthMask");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(flag);
    return 0;
}
case 62: {
    GLclampd zNear=0;memcpy(&zNear,&dg_wire_message->args[0],sizeof(zNear));
    GLclampd zFar=0;memcpy(&zFar,&dg_wire_message->args[1],sizeof(zFar));
    typedef void (*Proc)(GLclampd zNear, GLclampd zFar);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glDepthRange");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(zNear,zFar);
    return 0;
}
case 63: {
    GLenum cap=0;memcpy(&cap,&dg_wire_message->args[0],sizeof(cap));
    typedef void (*Proc)(GLenum cap);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glDisable");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(cap);
    if(cap==0x8f9d && context->profile!=kCGLOGLPVersion_Legacy)context->primitive_restart=0;
    return 0;
}
case 66: {
    GLenum mode=0;memcpy(&mode,&dg_wire_message->args[0],sizeof(mode));
    DGSetBuffer(context,mode,0);
    context->iosurface_draw_dirty=1;
    return 0;
}
case 68: {
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[0],sizeof(width));
    GLsizei height=0;memcpy(&height,&dg_wire_message->args[1],sizeof(height));
    GLenum format=0;memcpy(&format,&dg_wire_message->args[2],sizeof(format));
    GLenum type=0;memcpy(&type,&dg_wire_message->args[3],sizeof(type));
    const GLvoid * pixels=NULL;
    void *pixel_pointer=NULL;
    int admitted=DGHostCompatRasterPointer(context,dg_wire_message,width,height,format,type,4,0,&pixel_pointer);
    if(admitted<=0)return admitted;pixels=(const GLvoid *)pixel_pointer;
    typedef void (*Proc)(GLsizei width, GLsizei height, GLenum format, GLenum type, const GLvoid *pixels);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glDrawPixels");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    DGPrepareDrawableAliases(context,0);
    if(!DGDrawableWritable(context)) return 0;
    proc(width,height,format,type,pixels);
    DGMarkDrawableDamage(context);
    return 0;
}
case 69: {
    GLboolean flag=0;memcpy(&flag,&dg_wire_message->args[0],sizeof(flag));
    typedef void (*Proc)(GLboolean flag);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glEdgeFlag");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(flag);
    return 0;
}
case 71: {
    const GLboolean * flag=NULL;
    flag=(const GLboolean *)DGHostPointer(dg_wire_message,0,(sizeof(GLboolean)));
    if(!flag) return -1;
    typedef void (*Proc)(const GLboolean *flag);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glEdgeFlagv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(flag);
    return 0;
}
case 72: {
    GLenum cap=0;memcpy(&cap,&dg_wire_message->args[0],sizeof(cap));
    typedef void (*Proc)(GLenum cap);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glEnable");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(cap);
    if(cap==0x8f9d && context->profile!=kCGLOGLPVersion_Legacy)context->primitive_restart=1;
    return 0;
}
case 74: {
    typedef void (*Proc)(void);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glEnd");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc();
    context->inside_begin=0;
    DGMarkDrawableDamage(context);
    return 0;
}
case 75: {
    typedef void (*Proc)(void);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glEndList");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc();
    DGHostListModeChanged(context);
    return 0;
}
case 76: {
    GLdouble u=0;memcpy(&u,&dg_wire_message->args[0],sizeof(u));
    typedef void (*Proc)(GLdouble u);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glEvalCoord1d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(u);
    return 0;
}
case 77: {
    const GLdouble * u=NULL;
    u=(const GLdouble *)DGHostPointer(dg_wire_message,0,(sizeof(GLdouble)));
    if(!u) return -1;
    typedef void (*Proc)(const GLdouble *u);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glEvalCoord1dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(u);
    return 0;
}
case 78: {
    GLfloat u=0;memcpy(&u,&dg_wire_message->args[0],sizeof(u));
    typedef void (*Proc)(GLfloat u);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glEvalCoord1f");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(u);
    return 0;
}
case 79: {
    const GLfloat * u=NULL;
    u=(const GLfloat *)DGHostPointer(dg_wire_message,0,(sizeof(GLfloat)));
    if(!u) return -1;
    typedef void (*Proc)(const GLfloat *u);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glEvalCoord1fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(u);
    return 0;
}
case 80: {
    GLdouble u=0;memcpy(&u,&dg_wire_message->args[0],sizeof(u));
    GLdouble v=0;memcpy(&v,&dg_wire_message->args[1],sizeof(v));
    typedef void (*Proc)(GLdouble u, GLdouble v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glEvalCoord2d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(u,v);
    return 0;
}
case 81: {
    const GLdouble * u=NULL;
    u=(const GLdouble *)DGHostPointer(dg_wire_message,0,(2*sizeof(GLdouble)));
    if(!u) return -1;
    typedef void (*Proc)(const GLdouble *u);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glEvalCoord2dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(u);
    return 0;
}
case 82: {
    GLfloat u=0;memcpy(&u,&dg_wire_message->args[0],sizeof(u));
    GLfloat v=0;memcpy(&v,&dg_wire_message->args[1],sizeof(v));
    typedef void (*Proc)(GLfloat u, GLfloat v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glEvalCoord2f");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(u,v);
    return 0;
}
case 83: {
    const GLfloat * u=NULL;
    u=(const GLfloat *)DGHostPointer(dg_wire_message,0,(2*sizeof(GLfloat)));
    if(!u) return -1;
    typedef void (*Proc)(const GLfloat *u);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glEvalCoord2fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(u);
    return 0;
}
case 84: {
    GLenum mode=0;memcpy(&mode,&dg_wire_message->args[0],sizeof(mode));
    GLint i1=0;memcpy(&i1,&dg_wire_message->args[1],sizeof(i1));
    GLint i2=0;memcpy(&i2,&dg_wire_message->args[2],sizeof(i2));
    typedef void (*Proc)(GLenum mode, GLint i1, GLint i2);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glEvalMesh1");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    DGPrepareDrawableAliases(context,0);
    if(!DGDrawableWritable(context)) return 0;
    proc(mode,i1,i2);
    DGMarkDrawableDamage(context);
    return 0;
}
case 85: {
    GLenum mode=0;memcpy(&mode,&dg_wire_message->args[0],sizeof(mode));
    GLint i1=0;memcpy(&i1,&dg_wire_message->args[1],sizeof(i1));
    GLint i2=0;memcpy(&i2,&dg_wire_message->args[2],sizeof(i2));
    GLint j1=0;memcpy(&j1,&dg_wire_message->args[3],sizeof(j1));
    GLint j2=0;memcpy(&j2,&dg_wire_message->args[4],sizeof(j2));
    typedef void (*Proc)(GLenum mode, GLint i1, GLint i2, GLint j1, GLint j2);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glEvalMesh2");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    DGPrepareDrawableAliases(context,0);
    if(!DGDrawableWritable(context)) return 0;
    proc(mode,i1,i2,j1,j2);
    DGMarkDrawableDamage(context);
    return 0;
}
case 86: {
    GLint i=0;memcpy(&i,&dg_wire_message->args[0],sizeof(i));
    typedef void (*Proc)(GLint i);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glEvalPoint1");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(i);
    return 0;
}
case 87: {
    GLint i=0;memcpy(&i,&dg_wire_message->args[0],sizeof(i));
    GLint j=0;memcpy(&j,&dg_wire_message->args[1],sizeof(j));
    typedef void (*Proc)(GLint i, GLint j);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glEvalPoint2");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(i,j);
    return 0;
}
case 88: return DGHostRegisterRenderBuffer(context,dg_wire_message,reply,1);
case 89: {
    typedef void (*Proc)(void);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glFinish");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    DGRefreshFlippedAliases(context,0);
    proc();
    DGSubmitIOSurfaceWrites(context);
    return 0;
}
case 90: {
    typedef void (*Proc)(void);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glFlush");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    DGRefreshFlippedAliases(context,0);
    proc();
    DGSubmitIOSurfaceWrites(context);
    return 0;
}
case 91: {
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[0],sizeof(pname));
    GLfloat param=0;memcpy(&param,&dg_wire_message->args[1],sizeof(param));
    typedef void (*Proc)(GLenum pname, GLfloat param);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glFogf");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pname,param);
    return 0;
}
case 92: {
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[0],sizeof(pname));
    const GLfloat * params=NULL;
    params=(const GLfloat *)DGHostPointer(dg_wire_message,1,(DGArrayBytes(DGLightingCount(3,pname),sizeof(GLfloat))));
    if(!params) return -1;
    typedef void (*Proc)(GLenum pname, const GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glFogfv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pname,params);
    return 0;
}
case 93: {
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[0],sizeof(pname));
    GLint param=0;memcpy(&param,&dg_wire_message->args[1],sizeof(param));
    typedef void (*Proc)(GLenum pname, GLint param);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glFogi");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pname,param);
    return 0;
}
case 94: {
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[0],sizeof(pname));
    const GLint * params=NULL;
    params=(const GLint *)DGHostPointer(dg_wire_message,1,(DGArrayBytes(DGLightingCount(3,pname),sizeof(GLint))));
    if(!params) return -1;
    typedef void (*Proc)(GLenum pname, const GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glFogiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pname,params);
    return 0;
}
case 95: {
    GLenum mode=0;memcpy(&mode,&dg_wire_message->args[0],sizeof(mode));
    typedef void (*Proc)(GLenum mode);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glFrontFace");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(mode);
    return 0;
}
case 96: {
    GLdouble left=0;memcpy(&left,&dg_wire_message->args[0],sizeof(left));
    GLdouble right=0;memcpy(&right,&dg_wire_message->args[1],sizeof(right));
    GLdouble bottom=0;memcpy(&bottom,&dg_wire_message->args[2],sizeof(bottom));
    GLdouble top=0;memcpy(&top,&dg_wire_message->args[3],sizeof(top));
    GLdouble zNear=0;memcpy(&zNear,&dg_wire_message->args[4],sizeof(zNear));
    GLdouble zFar=0;memcpy(&zFar,&dg_wire_message->args[5],sizeof(zFar));
    typedef void (*Proc)(GLdouble left, GLdouble right, GLdouble bottom, GLdouble top, GLdouble zNear, GLdouble zFar);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glFrustum");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(left,right,bottom,top,zNear,zFar);
    return 0;
}
case 97: {
    GLsizei range=0;memcpy(&range,&dg_wire_message->args[0],sizeof(range));
    typedef GLuint (*Proc)(GLsizei range);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGenLists");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLuint result=proc(range);
    reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 98: {
    GLsizei n=0;memcpy(&n,&dg_wire_message->args[0],sizeof(n));
    GLuint * textures=NULL;
    textures=(GLuint *)DGHostPointer(dg_wire_message,1,((DGQueryArrayBytes(n,sizeof(GLuint))) ? (DGQueryArrayBytes(n,sizeof(GLuint))) : 1));
    if(!textures) return -1;
    typedef void (*Proc)(GLsizei n, GLuint *textures);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGenTextures");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(n,textures);
    return 0;
}
case 99: {
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[0],sizeof(pname));
    GLint binary_count=0;GLenum count_key=DGStateArrayCountKey(pname);
    if(count_key) {
        if(dg_wire_message->args[14]>DG_MAX_BYTES/sizeof(GLboolean))return -1;
        binary_count=(GLint)dg_wire_message->args[14];
        if(!DGHostStateArrayCapacity(context,count_key,binary_count))return 0;
    }
    GLboolean * params=NULL;
    params=(GLboolean *)DGHostPointer(dg_wire_message,1,((DGStateGetBytes(pname,binary_count,sizeof(GLboolean))) ? (DGStateGetBytes(pname,binary_count,sizeof(GLboolean))) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum pname, GLboolean *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetBooleanv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pname,params);
    GLint virtual_value=0;if(params && DGVirtualInteger(context,pname,&virtual_value)) *params=(GLboolean)(!!virtual_value);
    return 0;
}
case 100: {
    GLenum plane=0;memcpy(&plane,&dg_wire_message->args[0],sizeof(plane));
    GLdouble * equation=NULL;
    equation=(GLdouble *)DGHostPointer(dg_wire_message,1,((4*sizeof(GLdouble)) ? (4*sizeof(GLdouble)) : 1));
    if(!equation) return -1;
    typedef void (*Proc)(GLenum plane, GLdouble *equation);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetClipPlane");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(plane,equation);
    return 0;
}
case 101: {
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[0],sizeof(pname));
    GLint binary_count=0;GLenum count_key=DGStateArrayCountKey(pname);
    if(count_key) {
        if(dg_wire_message->args[14]>DG_MAX_BYTES/sizeof(GLdouble))return -1;
        binary_count=(GLint)dg_wire_message->args[14];
        if(!DGHostStateArrayCapacity(context,count_key,binary_count))return 0;
    }
    GLdouble * params=NULL;
    params=(GLdouble *)DGHostPointer(dg_wire_message,1,((DGStateGetBytes(pname,binary_count,sizeof(GLdouble))) ? (DGStateGetBytes(pname,binary_count,sizeof(GLdouble))) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum pname, GLdouble *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetDoublev");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pname,params);
    GLint virtual_value=0;if(params && DGVirtualInteger(context,pname,&virtual_value)) *params=(GLdouble)(virtual_value);
    return 0;
}
case 103: {
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[0],sizeof(pname));
    GLint binary_count=0;GLenum count_key=DGStateArrayCountKey(pname);
    if(count_key) {
        if(dg_wire_message->args[14]>DG_MAX_BYTES/sizeof(GLfloat))return -1;
        binary_count=(GLint)dg_wire_message->args[14];
        if(!DGHostStateArrayCapacity(context,count_key,binary_count))return 0;
    }
    GLfloat * params=NULL;
    params=(GLfloat *)DGHostPointer(dg_wire_message,1,((DGStateGetBytes(pname,binary_count,sizeof(GLfloat))) ? (DGStateGetBytes(pname,binary_count,sizeof(GLfloat))) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum pname, GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetFloatv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pname,params);
    GLint virtual_value=0;if(params && DGVirtualInteger(context,pname,&virtual_value)) *params=(GLfloat)(virtual_value);
    return 0;
}
case 104: {
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[0],sizeof(pname));
    GLint binary_count=0;GLenum count_key=DGStateArrayCountKey(pname);
    if(count_key) {
        if(dg_wire_message->args[14]>DG_MAX_BYTES/sizeof(GLint))return -1;
        binary_count=(GLint)dg_wire_message->args[14];
        if(!DGHostStateArrayCapacity(context,count_key,binary_count))return 0;
    }
    GLint * params=NULL;
    params=(GLint *)DGHostPointer(dg_wire_message,1,((DGStateGetBytes(pname,binary_count,sizeof(GLint))) ? (DGStateGetBytes(pname,binary_count,sizeof(GLint))) : 1));
    if(!params) return -1;
    if(pname==GL_MAX_VERTEX_UNITS_ARB && !context->inside_begin) { GLint units=DGHostWeightUnits(context);if(units){*params=units;return 0;} }
    typedef void (*Proc)(GLenum pname, GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetIntegerv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pname,params);
    GLint virtual_value=0;if(params && DGVirtualInteger(context,pname,&virtual_value)) *params=(GLint)(virtual_value);
    return 0;
}
case 105: {
    GLenum light=0;memcpy(&light,&dg_wire_message->args[0],sizeof(light));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLfloat * params=NULL;
    params=(GLfloat *)DGHostPointer(dg_wire_message,2,((DGArrayBytes(DGLightingCount(0,pname),sizeof(GLfloat))) ? (DGArrayBytes(DGLightingCount(0,pname),sizeof(GLfloat))) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum light, GLenum pname, GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetLightfv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(light,pname,params);
    return 0;
}
case 106: {
    GLenum light=0;memcpy(&light,&dg_wire_message->args[0],sizeof(light));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint * params=NULL;
    params=(GLint *)DGHostPointer(dg_wire_message,2,((DGArrayBytes(DGLightingCount(0,pname),sizeof(GLint))) ? (DGArrayBytes(DGLightingCount(0,pname),sizeof(GLint))) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum light, GLenum pname, GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetLightiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(light,pname,params);
    return 0;
}
case 107: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum query=0;memcpy(&query,&dg_wire_message->args[1],sizeof(query));
    if(context->inside_begin || context->profile!=kCGLOGLPVersion_Legacy) { reply->error=GL_INVALID_OPERATION;return 0; }
    if(!DGMapDimensions(target) || (query!=GL_ORDER && query!=GL_DOMAIN && query!=GL_COEFF)) { reply->error=GL_INVALID_ENUM;return 0; }
    GLenum prior=glGetError();if(prior && !context->error)context->error=prior;
    GLint order[2]={0,0};if(query==GL_COEFF){glGetMapiv(target,GL_ORDER,order);reply->error=glGetError();if(reply->error)return 0;}
    size_t map_bytes=DGMapQueryBytes(target,query,order[0],order[1],sizeof(GLdouble));
    if(dg_wire_message->args[2]!=1 || dg_wire_message->bytes!=map_bytes)return -1;
    GLdouble * v=NULL;
    v=(GLdouble *)DGHostPointer(dg_wire_message,2,((map_bytes) ? (map_bytes) : 1));
    if(!v) return -1;
    typedef void (*Proc)(GLenum target, GLenum query, GLdouble *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetMapdv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,query,v);
    reply->error=glGetError();if(!reply->error)reply->result=map_bytes;
    return 0;
}
case 108: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum query=0;memcpy(&query,&dg_wire_message->args[1],sizeof(query));
    if(context->inside_begin || context->profile!=kCGLOGLPVersion_Legacy) { reply->error=GL_INVALID_OPERATION;return 0; }
    if(!DGMapDimensions(target) || (query!=GL_ORDER && query!=GL_DOMAIN && query!=GL_COEFF)) { reply->error=GL_INVALID_ENUM;return 0; }
    GLenum prior=glGetError();if(prior && !context->error)context->error=prior;
    GLint order[2]={0,0};if(query==GL_COEFF){glGetMapiv(target,GL_ORDER,order);reply->error=glGetError();if(reply->error)return 0;}
    size_t map_bytes=DGMapQueryBytes(target,query,order[0],order[1],sizeof(GLfloat));
    if(dg_wire_message->args[2]!=1 || dg_wire_message->bytes!=map_bytes)return -1;
    GLfloat * v=NULL;
    v=(GLfloat *)DGHostPointer(dg_wire_message,2,((map_bytes) ? (map_bytes) : 1));
    if(!v) return -1;
    typedef void (*Proc)(GLenum target, GLenum query, GLfloat *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetMapfv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,query,v);
    reply->error=glGetError();if(!reply->error)reply->result=map_bytes;
    return 0;
}
case 109: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum query=0;memcpy(&query,&dg_wire_message->args[1],sizeof(query));
    if(context->inside_begin || context->profile!=kCGLOGLPVersion_Legacy) { reply->error=GL_INVALID_OPERATION;return 0; }
    if(!DGMapDimensions(target) || (query!=GL_ORDER && query!=GL_DOMAIN && query!=GL_COEFF)) { reply->error=GL_INVALID_ENUM;return 0; }
    GLenum prior=glGetError();if(prior && !context->error)context->error=prior;
    GLint order[2]={0,0};if(query==GL_COEFF){glGetMapiv(target,GL_ORDER,order);reply->error=glGetError();if(reply->error)return 0;}
    size_t map_bytes=DGMapQueryBytes(target,query,order[0],order[1],sizeof(GLint));
    if(dg_wire_message->args[2]!=1 || dg_wire_message->bytes!=map_bytes)return -1;
    GLint * v=NULL;
    v=(GLint *)DGHostPointer(dg_wire_message,2,((map_bytes) ? (map_bytes) : 1));
    if(!v) return -1;
    typedef void (*Proc)(GLenum target, GLenum query, GLint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetMapiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,query,v);
    reply->error=glGetError();if(!reply->error)reply->result=map_bytes;
    return 0;
}
case 110: {
    GLenum face=0;memcpy(&face,&dg_wire_message->args[0],sizeof(face));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLfloat * params=NULL;
    params=(GLfloat *)DGHostPointer(dg_wire_message,2,((DGArrayBytes(DGLightingCount(1,pname),sizeof(GLfloat))) ? (DGArrayBytes(DGLightingCount(1,pname),sizeof(GLfloat))) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum face, GLenum pname, GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetMaterialfv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(face,pname,params);
    return 0;
}
case 111: {
    GLenum face=0;memcpy(&face,&dg_wire_message->args[0],sizeof(face));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint * params=NULL;
    params=(GLint *)DGHostPointer(dg_wire_message,2,((DGArrayBytes(DGLightingCount(1,pname),sizeof(GLint))) ? (DGArrayBytes(DGLightingCount(1,pname),sizeof(GLint))) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum face, GLenum pname, GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetMaterialiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(face,pname,params);
    return 0;
}
case 112: {
    GLenum map=0;memcpy(&map,&dg_wire_message->args[0],sizeof(map));
    GLfloat * values=NULL;
    void *pixel_pointer=NULL;
    int admitted=DGHostPixelMapPointer(context,dg_wire_message,map,0,sizeof(*values),1,1,&pixel_pointer);
    if(admitted<=0)return admitted;values=(GLfloat *)pixel_pointer;
    typedef void (*Proc)(GLenum map, GLfloat *values);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetPixelMapfv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(map,values);
    if(dg_wire_message->args[15])DGPBOWritten(context);
    return 0;
}
case 113: {
    GLenum map=0;memcpy(&map,&dg_wire_message->args[0],sizeof(map));
    GLuint * values=NULL;
    void *pixel_pointer=NULL;
    int admitted=DGHostPixelMapPointer(context,dg_wire_message,map,0,sizeof(*values),1,1,&pixel_pointer);
    if(admitted<=0)return admitted;values=(GLuint *)pixel_pointer;
    typedef void (*Proc)(GLenum map, GLuint *values);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetPixelMapuiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(map,values);
    if(dg_wire_message->args[15])DGPBOWritten(context);
    return 0;
}
case 114: {
    GLenum map=0;memcpy(&map,&dg_wire_message->args[0],sizeof(map));
    GLushort * values=NULL;
    void *pixel_pointer=NULL;
    int admitted=DGHostPixelMapPointer(context,dg_wire_message,map,0,sizeof(*values),1,1,&pixel_pointer);
    if(admitted<=0)return admitted;values=(GLushort *)pixel_pointer;
    typedef void (*Proc)(GLenum map, GLushort *values);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetPixelMapusv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(map,values);
    if(dg_wire_message->args[15])DGPBOWritten(context);
    return 0;
}
case 116: {
    GLubyte * mask=NULL;
    void *pixel_pointer=NULL;
    int admitted=DGHostCompatRasterPointer(context,dg_wire_message,32,32,GL_COLOR_INDEX,GL_BITMAP,0,1,&pixel_pointer);
    if(admitted<=0)return admitted;mask=(GLubyte *)pixel_pointer;
    DGHostGetPolygonStipple(context,mask);
    return 0;
}
case 118: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLfloat * params=NULL;
    params=(GLfloat *)DGHostPointer(dg_wire_message,2,(((pname==GL_TEXTURE_ENV_COLOR ? 4 : 1)*sizeof(GLfloat)) ? ((pname==GL_TEXTURE_ENV_COLOR ? 4 : 1)*sizeof(GLfloat)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLenum pname, GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetTexEnvfv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,pname,params);
    return 0;
}
case 119: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint * params=NULL;
    params=(GLint *)DGHostPointer(dg_wire_message,2,(((pname==GL_TEXTURE_ENV_COLOR ? 4 : 1)*sizeof(GLint)) ? ((pname==GL_TEXTURE_ENV_COLOR ? 4 : 1)*sizeof(GLint)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLenum pname, GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetTexEnviv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,pname,params);
    return 0;
}
case 120: {
    GLenum coord=0;memcpy(&coord,&dg_wire_message->args[0],sizeof(coord));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLdouble * params=NULL;
    params=(GLdouble *)DGHostPointer(dg_wire_message,2,(((pname==GL_OBJECT_PLANE || pname==GL_EYE_PLANE ? 4 : 1)*sizeof(GLdouble)) ? ((pname==GL_OBJECT_PLANE || pname==GL_EYE_PLANE ? 4 : 1)*sizeof(GLdouble)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum coord, GLenum pname, GLdouble *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetTexGendv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(coord,pname,params);
    return 0;
}
case 121: {
    GLenum coord=0;memcpy(&coord,&dg_wire_message->args[0],sizeof(coord));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLfloat * params=NULL;
    params=(GLfloat *)DGHostPointer(dg_wire_message,2,(((pname==GL_OBJECT_PLANE || pname==GL_EYE_PLANE ? 4 : 1)*sizeof(GLfloat)) ? ((pname==GL_OBJECT_PLANE || pname==GL_EYE_PLANE ? 4 : 1)*sizeof(GLfloat)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum coord, GLenum pname, GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetTexGenfv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(coord,pname,params);
    return 0;
}
case 122: {
    GLenum coord=0;memcpy(&coord,&dg_wire_message->args[0],sizeof(coord));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint * params=NULL;
    params=(GLint *)DGHostPointer(dg_wire_message,2,(((pname==GL_OBJECT_PLANE || pname==GL_EYE_PLANE ? 4 : 1)*sizeof(GLint)) ? ((pname==GL_OBJECT_PLANE || pname==GL_EYE_PLANE ? 4 : 1)*sizeof(GLint)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum coord, GLenum pname, GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetTexGeniv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(coord,pname,params);
    return 0;
}
case 123: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLint level=0;memcpy(&level,&dg_wire_message->args[1],sizeof(level));
    GLenum format=0;memcpy(&format,&dg_wire_message->args[2],sizeof(format));
    GLenum type=0;memcpy(&type,&dg_wire_message->args[3],sizeof(type));
    GLint width=0,height=0,pack_buffer=0;
    if(context->inside_begin || (target!=GL_TEXTURE_RECTANGLE_ARB && target!=GL_TEXTURE_2D)) { context->error=GL_INVALID_OPERATION;return 0; }
    glGetIntegerv(GL_PIXEL_PACK_BUFFER_BINDING,&pack_buffer);if(pack_buffer) { context->error=GL_INVALID_OPERATION;return 0; }
    glGetTexLevelParameteriv(target,level,GL_TEXTURE_WIDTH,&width);
    glGetTexLevelParameteriv(target,level,GL_TEXTURE_HEIGHT,&height);
    if(width<=0 || height<=0)return 0;
    GLvoid * pixels=NULL;
    pixels=(GLvoid *)DGHostPointer(dg_wire_message,4,((DGPixelBytes(context,width,height,format,type,1)) ? (DGPixelBytes(context,width,height,format,type,1)) : 1));
    if(!pixels) return -1;
    typedef void (*Proc)(GLenum target, GLint level, GLenum format, GLenum type, GLvoid *pixels);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetTexImage");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,level,format,type,pixels);
    return 0;
}
case 124: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLint level=0;memcpy(&level,&dg_wire_message->args[1],sizeof(level));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[2],sizeof(pname));
    GLfloat * params=NULL;
    params=(GLfloat *)DGHostPointer(dg_wire_message,3,((sizeof(GLfloat)) ? (sizeof(GLfloat)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLint level, GLenum pname, GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetTexLevelParameterfv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,level,pname,params);
    return 0;
}
case 125: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLint level=0;memcpy(&level,&dg_wire_message->args[1],sizeof(level));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[2],sizeof(pname));
    GLint * params=NULL;
    params=(GLint *)DGHostPointer(dg_wire_message,3,((sizeof(GLint)) ? (sizeof(GLint)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLint level, GLenum pname, GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetTexLevelParameteriv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,level,pname,params);
    return 0;
}
case 126: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLfloat * params=NULL;
    params=(GLfloat *)DGHostPointer(dg_wire_message,2,(((pname==GL_TEXTURE_BORDER_COLOR || pname==0x8e46 ? 4 : 1)*sizeof(GLfloat)) ? ((pname==GL_TEXTURE_BORDER_COLOR || pname==0x8e46 ? 4 : 1)*sizeof(GLfloat)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLenum pname, GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetTexParameterfv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,pname,params);
    return 0;
}
case 127: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint * params=NULL;
    if(!DGParameterCount(pname) && dg_wire_message->bytes==1 && dg_wire_message->args[2]==1) { if(!context->error)context->error=context->inside_begin?GL_INVALID_OPERATION:GL_INVALID_ENUM;return 0; }
    params=(GLint *)DGHostPointer(dg_wire_message,2,(((pname==GL_TEXTURE_BORDER_COLOR || pname==0x8e46 ? 4 : 1)*sizeof(GLint)) ? ((pname==GL_TEXTURE_BORDER_COLOR || pname==0x8e46 ? 4 : 1)*sizeof(GLint)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLenum pname, GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetTexParameteriv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,pname,params);
    return 0;
}
case 128: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum mode=0;memcpy(&mode,&dg_wire_message->args[1],sizeof(mode));
    typedef void (*Proc)(GLenum target, GLenum mode);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glHint");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,mode);
    return 0;
}
case 129: {
    GLuint mask=0;memcpy(&mask,&dg_wire_message->args[0],sizeof(mask));
    typedef void (*Proc)(GLuint mask);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glIndexMask");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(mask);
    return 0;
}
case 131: {
    GLdouble c=0;memcpy(&c,&dg_wire_message->args[0],sizeof(c));
    typedef void (*Proc)(GLdouble c);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glIndexd");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(c);
    return 0;
}
case 132: {
    const GLdouble * c=NULL;
    c=(const GLdouble *)DGHostPointer(dg_wire_message,0,(sizeof(GLdouble)));
    if(!c) return -1;
    typedef void (*Proc)(const GLdouble *c);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glIndexdv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(c);
    return 0;
}
case 133: {
    GLfloat c=0;memcpy(&c,&dg_wire_message->args[0],sizeof(c));
    typedef void (*Proc)(GLfloat c);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glIndexf");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(c);
    return 0;
}
case 134: {
    const GLfloat * c=NULL;
    c=(const GLfloat *)DGHostPointer(dg_wire_message,0,(sizeof(GLfloat)));
    if(!c) return -1;
    typedef void (*Proc)(const GLfloat *c);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glIndexfv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(c);
    return 0;
}
case 135: {
    GLint c=0;memcpy(&c,&dg_wire_message->args[0],sizeof(c));
    typedef void (*Proc)(GLint c);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glIndexi");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(c);
    return 0;
}
case 136: {
    const GLint * c=NULL;
    c=(const GLint *)DGHostPointer(dg_wire_message,0,(sizeof(GLint)));
    if(!c) return -1;
    typedef void (*Proc)(const GLint *c);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glIndexiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(c);
    return 0;
}
case 137: {
    GLshort c=0;memcpy(&c,&dg_wire_message->args[0],sizeof(c));
    typedef void (*Proc)(GLshort c);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glIndexs");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(c);
    return 0;
}
case 138: {
    const GLshort * c=NULL;
    c=(const GLshort *)DGHostPointer(dg_wire_message,0,(sizeof(GLshort)));
    if(!c) return -1;
    typedef void (*Proc)(const GLshort *c);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glIndexsv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(c);
    return 0;
}
case 139: {
    GLubyte c=0;memcpy(&c,&dg_wire_message->args[0],sizeof(c));
    typedef void (*Proc)(GLubyte c);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glIndexub");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(c);
    return 0;
}
case 140: {
    const GLubyte * c=NULL;
    c=(const GLubyte *)DGHostPointer(dg_wire_message,0,(sizeof(GLubyte)));
    if(!c) return -1;
    typedef void (*Proc)(const GLubyte *c);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glIndexubv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(c);
    return 0;
}
case 141: {
    typedef void (*Proc)(void);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glInitNames");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc();
    return 0;
}
case 143: {
    GLenum cap=0;memcpy(&cap,&dg_wire_message->args[0],sizeof(cap));
    typedef GLboolean (*Proc)(GLenum cap);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glIsEnabled");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLboolean result=proc(cap);
    reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 144: {
    GLuint list=0;memcpy(&list,&dg_wire_message->args[0],sizeof(list));
    typedef GLboolean (*Proc)(GLuint list);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glIsList");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLboolean result=proc(list);
    reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 145: {
    GLuint texture=0;memcpy(&texture,&dg_wire_message->args[0],sizeof(texture));
    typedef GLboolean (*Proc)(GLuint texture);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glIsTexture");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    if(!context->inside_begin && DGPrivateTextureContains(context->alias_group->private_textures,texture)){reply->result=GL_FALSE;return 0;}
    GLboolean result=proc(texture);
    reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 146: {
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[0],sizeof(pname));
    GLfloat param=0;memcpy(&param,&dg_wire_message->args[1],sizeof(param));
    typedef void (*Proc)(GLenum pname, GLfloat param);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glLightModelf");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pname,param);
    return 0;
}
case 147: {
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[0],sizeof(pname));
    const GLfloat * params=NULL;
    params=(const GLfloat *)DGHostPointer(dg_wire_message,1,(DGArrayBytes(DGLightingCount(2,pname),sizeof(GLfloat))));
    if(!params) return -1;
    typedef void (*Proc)(GLenum pname, const GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glLightModelfv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pname,params);
    return 0;
}
case 148: {
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[0],sizeof(pname));
    GLint param=0;memcpy(&param,&dg_wire_message->args[1],sizeof(param));
    typedef void (*Proc)(GLenum pname, GLint param);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glLightModeli");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pname,param);
    return 0;
}
case 149: {
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[0],sizeof(pname));
    const GLint * params=NULL;
    params=(const GLint *)DGHostPointer(dg_wire_message,1,(DGArrayBytes(DGLightingCount(2,pname),sizeof(GLint))));
    if(!params) return -1;
    typedef void (*Proc)(GLenum pname, const GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glLightModeliv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pname,params);
    return 0;
}
case 150: {
    GLenum light=0;memcpy(&light,&dg_wire_message->args[0],sizeof(light));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLfloat param=0;memcpy(&param,&dg_wire_message->args[2],sizeof(param));
    typedef void (*Proc)(GLenum light, GLenum pname, GLfloat param);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glLightf");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(light,pname,param);
    return 0;
}
case 151: {
    GLenum light=0;memcpy(&light,&dg_wire_message->args[0],sizeof(light));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    const GLfloat * params=NULL;
    params=(const GLfloat *)DGHostPointer(dg_wire_message,2,(DGArrayBytes(DGLightingCount(0,pname),sizeof(GLfloat))));
    if(!params) return -1;
    typedef void (*Proc)(GLenum light, GLenum pname, const GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glLightfv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(light,pname,params);
    return 0;
}
case 152: {
    GLenum light=0;memcpy(&light,&dg_wire_message->args[0],sizeof(light));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint param=0;memcpy(&param,&dg_wire_message->args[2],sizeof(param));
    typedef void (*Proc)(GLenum light, GLenum pname, GLint param);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glLighti");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(light,pname,param);
    return 0;
}
case 153: {
    GLenum light=0;memcpy(&light,&dg_wire_message->args[0],sizeof(light));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    const GLint * params=NULL;
    params=(const GLint *)DGHostPointer(dg_wire_message,2,(DGArrayBytes(DGLightingCount(0,pname),sizeof(GLint))));
    if(!params) return -1;
    typedef void (*Proc)(GLenum light, GLenum pname, const GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glLightiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(light,pname,params);
    return 0;
}
case 154: {
    GLint factor=0;memcpy(&factor,&dg_wire_message->args[0],sizeof(factor));
    GLushort pattern=0;memcpy(&pattern,&dg_wire_message->args[1],sizeof(pattern));
    typedef void (*Proc)(GLint factor, GLushort pattern);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glLineStipple");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(factor,pattern);
    return 0;
}
case 155: {
    GLfloat width=0;memcpy(&width,&dg_wire_message->args[0],sizeof(width));
    typedef void (*Proc)(GLfloat width);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glLineWidth");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(width);
    return 0;
}
case 156: {
    GLuint base=0;memcpy(&base,&dg_wire_message->args[0],sizeof(base));
    typedef void (*Proc)(GLuint base);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glListBase");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(base);
    return 0;
}
case 157: {
    typedef void (*Proc)(void);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glLoadIdentity");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc();
    return 0;
}
case 158: {
    const GLdouble * m=NULL;
    m=(const GLdouble *)DGHostPointer(dg_wire_message,0,(16*sizeof(GLdouble)));
    if(!m) return -1;
    typedef void (*Proc)(const GLdouble *m);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glLoadMatrixd");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(m);
    return 0;
}
case 159: {
    const GLfloat * m=NULL;
    m=(const GLfloat *)DGHostPointer(dg_wire_message,0,(16*sizeof(GLfloat)));
    if(!m) return -1;
    typedef void (*Proc)(const GLfloat *m);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glLoadMatrixf");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(m);
    return 0;
}
case 160: {
    GLuint name=0;memcpy(&name,&dg_wire_message->args[0],sizeof(name));
    typedef void (*Proc)(GLuint name);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glLoadName");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(name);
    return 0;
}
case 161: {
    GLenum opcode=0;memcpy(&opcode,&dg_wire_message->args[0],sizeof(opcode));
    typedef void (*Proc)(GLenum opcode);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glLogicOp");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(opcode);
    return 0;
}
case 162: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLdouble u1=0;memcpy(&u1,&dg_wire_message->args[1],sizeof(u1));
    GLdouble u2=0;memcpy(&u2,&dg_wire_message->args[2],sizeof(u2));
    GLint stride=0;memcpy(&stride,&dg_wire_message->args[3],sizeof(stride));
    GLint order=0;memcpy(&order,&dg_wire_message->args[4],sizeof(order));
    const GLdouble * points=NULL;
    int admitted=DGHostEvaluatorInput(context,dg_wire_message,reply,target,DGMapComponents(target),stride,order,0,1,u1!=u2,sizeof(GLdouble),1,5,0);
    if(admitted<=0)return admitted;
    points=(const GLdouble *)(dg_wire_message+1);
    typedef void (*Proc)(GLenum target, GLdouble u1, GLdouble u2, GLint stride, GLint order, const GLdouble *points);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMap1d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,u1,u2,stride,order,points);
    return 0;
}
case 163: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLfloat u1=0;memcpy(&u1,&dg_wire_message->args[1],sizeof(u1));
    GLfloat u2=0;memcpy(&u2,&dg_wire_message->args[2],sizeof(u2));
    GLint stride=0;memcpy(&stride,&dg_wire_message->args[3],sizeof(stride));
    GLint order=0;memcpy(&order,&dg_wire_message->args[4],sizeof(order));
    const GLfloat * points=NULL;
    int admitted=DGHostEvaluatorInput(context,dg_wire_message,reply,target,DGMapComponents(target),stride,order,0,1,u1!=u2,sizeof(GLfloat),1,5,0);
    if(admitted<=0)return admitted;
    points=(const GLfloat *)(dg_wire_message+1);
    typedef void (*Proc)(GLenum target, GLfloat u1, GLfloat u2, GLint stride, GLint order, const GLfloat *points);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMap1f");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,u1,u2,stride,order,points);
    return 0;
}
case 164: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLdouble u1=0;memcpy(&u1,&dg_wire_message->args[1],sizeof(u1));
    GLdouble u2=0;memcpy(&u2,&dg_wire_message->args[2],sizeof(u2));
    GLint ustride=0;memcpy(&ustride,&dg_wire_message->args[3],sizeof(ustride));
    GLint uorder=0;memcpy(&uorder,&dg_wire_message->args[4],sizeof(uorder));
    GLdouble v1=0;memcpy(&v1,&dg_wire_message->args[5],sizeof(v1));
    GLdouble v2=0;memcpy(&v2,&dg_wire_message->args[6],sizeof(v2));
    GLint vstride=0;memcpy(&vstride,&dg_wire_message->args[7],sizeof(vstride));
    GLint vorder=0;memcpy(&vorder,&dg_wire_message->args[8],sizeof(vorder));
    const GLdouble * points=NULL;
    int admitted=DGHostEvaluatorInput(context,dg_wire_message,reply,target,DGMapComponents(target),ustride,uorder,vstride,vorder,u1!=u2 && v1!=v2,sizeof(GLdouble),2,9,0);
    if(admitted<=0)return admitted;
    points=(const GLdouble *)(dg_wire_message+1);
    typedef void (*Proc)(GLenum target, GLdouble u1, GLdouble u2, GLint ustride, GLint uorder, GLdouble v1, GLdouble v2, GLint vstride, GLint vorder, const GLdouble *points);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMap2d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,u1,u2,ustride,uorder,v1,v2,vstride,vorder,points);
    return 0;
}
case 165: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLfloat u1=0;memcpy(&u1,&dg_wire_message->args[1],sizeof(u1));
    GLfloat u2=0;memcpy(&u2,&dg_wire_message->args[2],sizeof(u2));
    GLint ustride=0;memcpy(&ustride,&dg_wire_message->args[3],sizeof(ustride));
    GLint uorder=0;memcpy(&uorder,&dg_wire_message->args[4],sizeof(uorder));
    GLfloat v1=0;memcpy(&v1,&dg_wire_message->args[5],sizeof(v1));
    GLfloat v2=0;memcpy(&v2,&dg_wire_message->args[6],sizeof(v2));
    GLint vstride=0;memcpy(&vstride,&dg_wire_message->args[7],sizeof(vstride));
    GLint vorder=0;memcpy(&vorder,&dg_wire_message->args[8],sizeof(vorder));
    const GLfloat * points=NULL;
    int admitted=DGHostEvaluatorInput(context,dg_wire_message,reply,target,DGMapComponents(target),ustride,uorder,vstride,vorder,u1!=u2 && v1!=v2,sizeof(GLfloat),2,9,0);
    if(admitted<=0)return admitted;
    points=(const GLfloat *)(dg_wire_message+1);
    typedef void (*Proc)(GLenum target, GLfloat u1, GLfloat u2, GLint ustride, GLint uorder, GLfloat v1, GLfloat v2, GLint vstride, GLint vorder, const GLfloat *points);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMap2f");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,u1,u2,ustride,uorder,v1,v2,vstride,vorder,points);
    return 0;
}
case 166: {
    GLint un=0;memcpy(&un,&dg_wire_message->args[0],sizeof(un));
    GLdouble u1=0;memcpy(&u1,&dg_wire_message->args[1],sizeof(u1));
    GLdouble u2=0;memcpy(&u2,&dg_wire_message->args[2],sizeof(u2));
    typedef void (*Proc)(GLint un, GLdouble u1, GLdouble u2);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMapGrid1d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(un,u1,u2);
    return 0;
}
case 167: {
    GLint un=0;memcpy(&un,&dg_wire_message->args[0],sizeof(un));
    GLfloat u1=0;memcpy(&u1,&dg_wire_message->args[1],sizeof(u1));
    GLfloat u2=0;memcpy(&u2,&dg_wire_message->args[2],sizeof(u2));
    typedef void (*Proc)(GLint un, GLfloat u1, GLfloat u2);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMapGrid1f");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(un,u1,u2);
    return 0;
}
case 168: {
    GLint un=0;memcpy(&un,&dg_wire_message->args[0],sizeof(un));
    GLdouble u1=0;memcpy(&u1,&dg_wire_message->args[1],sizeof(u1));
    GLdouble u2=0;memcpy(&u2,&dg_wire_message->args[2],sizeof(u2));
    GLint vn=0;memcpy(&vn,&dg_wire_message->args[3],sizeof(vn));
    GLdouble v1=0;memcpy(&v1,&dg_wire_message->args[4],sizeof(v1));
    GLdouble v2=0;memcpy(&v2,&dg_wire_message->args[5],sizeof(v2));
    typedef void (*Proc)(GLint un, GLdouble u1, GLdouble u2, GLint vn, GLdouble v1, GLdouble v2);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMapGrid2d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(un,u1,u2,vn,v1,v2);
    return 0;
}
case 169: {
    GLint un=0;memcpy(&un,&dg_wire_message->args[0],sizeof(un));
    GLfloat u1=0;memcpy(&u1,&dg_wire_message->args[1],sizeof(u1));
    GLfloat u2=0;memcpy(&u2,&dg_wire_message->args[2],sizeof(u2));
    GLint vn=0;memcpy(&vn,&dg_wire_message->args[3],sizeof(vn));
    GLfloat v1=0;memcpy(&v1,&dg_wire_message->args[4],sizeof(v1));
    GLfloat v2=0;memcpy(&v2,&dg_wire_message->args[5],sizeof(v2));
    typedef void (*Proc)(GLint un, GLfloat u1, GLfloat u2, GLint vn, GLfloat v1, GLfloat v2);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMapGrid2f");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(un,u1,u2,vn,v1,v2);
    return 0;
}
case 170: {
    GLenum face=0;memcpy(&face,&dg_wire_message->args[0],sizeof(face));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLfloat param=0;memcpy(&param,&dg_wire_message->args[2],sizeof(param));
    typedef void (*Proc)(GLenum face, GLenum pname, GLfloat param);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMaterialf");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(face,pname,param);
    return 0;
}
case 171: {
    GLenum face=0;memcpy(&face,&dg_wire_message->args[0],sizeof(face));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    const GLfloat * params=NULL;
    params=(const GLfloat *)DGHostPointer(dg_wire_message,2,(DGArrayBytes(DGLightingCount(1,pname),sizeof(GLfloat))));
    if(!params) return -1;
    typedef void (*Proc)(GLenum face, GLenum pname, const GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMaterialfv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(face,pname,params);
    return 0;
}
case 172: {
    GLenum face=0;memcpy(&face,&dg_wire_message->args[0],sizeof(face));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint param=0;memcpy(&param,&dg_wire_message->args[2],sizeof(param));
    typedef void (*Proc)(GLenum face, GLenum pname, GLint param);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMateriali");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(face,pname,param);
    return 0;
}
case 173: {
    GLenum face=0;memcpy(&face,&dg_wire_message->args[0],sizeof(face));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    const GLint * params=NULL;
    params=(const GLint *)DGHostPointer(dg_wire_message,2,(DGArrayBytes(DGLightingCount(1,pname),sizeof(GLint))));
    if(!params) return -1;
    typedef void (*Proc)(GLenum face, GLenum pname, const GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMaterialiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(face,pname,params);
    return 0;
}
case 174: {
    GLenum mode=0;memcpy(&mode,&dg_wire_message->args[0],sizeof(mode));
    typedef void (*Proc)(GLenum mode);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMatrixMode");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(mode);
    return 0;
}
case 175: {
    const GLdouble * m=NULL;
    m=(const GLdouble *)DGHostPointer(dg_wire_message,0,(16*sizeof(GLdouble)));
    if(!m) return -1;
    typedef void (*Proc)(const GLdouble *m);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultMatrixd");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(m);
    return 0;
}
case 176: {
    const GLfloat * m=NULL;
    m=(const GLfloat *)DGHostPointer(dg_wire_message,0,(16*sizeof(GLfloat)));
    if(!m) return -1;
    typedef void (*Proc)(const GLfloat *m);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultMatrixf");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(m);
    return 0;
}
case 177: {
    GLuint list=0;memcpy(&list,&dg_wire_message->args[0],sizeof(list));
    GLenum mode=0;memcpy(&mode,&dg_wire_message->args[1],sizeof(mode));
    typedef void (*Proc)(GLuint list, GLenum mode);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glNewList");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(list,mode);
    DGHostListModeChanged(context);
    return 0;
}
case 178: {
    GLbyte nx=0;memcpy(&nx,&dg_wire_message->args[0],sizeof(nx));
    GLbyte ny=0;memcpy(&ny,&dg_wire_message->args[1],sizeof(ny));
    GLbyte nz=0;memcpy(&nz,&dg_wire_message->args[2],sizeof(nz));
    typedef void (*Proc)(GLbyte nx, GLbyte ny, GLbyte nz);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glNormal3b");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(nx,ny,nz);
    return 0;
}
case 179: {
    const GLbyte * v=NULL;
    v=(const GLbyte *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLbyte)));
    if(!v) return -1;
    typedef void (*Proc)(const GLbyte *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glNormal3bv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 180: {
    GLdouble nx=0;memcpy(&nx,&dg_wire_message->args[0],sizeof(nx));
    GLdouble ny=0;memcpy(&ny,&dg_wire_message->args[1],sizeof(ny));
    GLdouble nz=0;memcpy(&nz,&dg_wire_message->args[2],sizeof(nz));
    typedef void (*Proc)(GLdouble nx, GLdouble ny, GLdouble nz);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glNormal3d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(nx,ny,nz);
    return 0;
}
case 181: {
    const GLdouble * v=NULL;
    v=(const GLdouble *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLdouble)));
    if(!v) return -1;
    typedef void (*Proc)(const GLdouble *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glNormal3dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 182: {
    GLfloat nx=0;memcpy(&nx,&dg_wire_message->args[0],sizeof(nx));
    GLfloat ny=0;memcpy(&ny,&dg_wire_message->args[1],sizeof(ny));
    GLfloat nz=0;memcpy(&nz,&dg_wire_message->args[2],sizeof(nz));
    typedef void (*Proc)(GLfloat nx, GLfloat ny, GLfloat nz);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glNormal3f");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(nx,ny,nz);
    return 0;
}
case 183: {
    const GLfloat * v=NULL;
    v=(const GLfloat *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLfloat)));
    if(!v) return -1;
    typedef void (*Proc)(const GLfloat *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glNormal3fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 184: {
    GLint nx=0;memcpy(&nx,&dg_wire_message->args[0],sizeof(nx));
    GLint ny=0;memcpy(&ny,&dg_wire_message->args[1],sizeof(ny));
    GLint nz=0;memcpy(&nz,&dg_wire_message->args[2],sizeof(nz));
    typedef void (*Proc)(GLint nx, GLint ny, GLint nz);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glNormal3i");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(nx,ny,nz);
    return 0;
}
case 185: {
    const GLint * v=NULL;
    v=(const GLint *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLint)));
    if(!v) return -1;
    typedef void (*Proc)(const GLint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glNormal3iv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 186: {
    GLshort nx=0;memcpy(&nx,&dg_wire_message->args[0],sizeof(nx));
    GLshort ny=0;memcpy(&ny,&dg_wire_message->args[1],sizeof(ny));
    GLshort nz=0;memcpy(&nz,&dg_wire_message->args[2],sizeof(nz));
    typedef void (*Proc)(GLshort nx, GLshort ny, GLshort nz);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glNormal3s");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(nx,ny,nz);
    return 0;
}
case 187: {
    const GLshort * v=NULL;
    v=(const GLshort *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLshort)));
    if(!v) return -1;
    typedef void (*Proc)(const GLshort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glNormal3sv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 189: {
    GLdouble left=0;memcpy(&left,&dg_wire_message->args[0],sizeof(left));
    GLdouble right=0;memcpy(&right,&dg_wire_message->args[1],sizeof(right));
    GLdouble bottom=0;memcpy(&bottom,&dg_wire_message->args[2],sizeof(bottom));
    GLdouble top=0;memcpy(&top,&dg_wire_message->args[3],sizeof(top));
    GLdouble zNear=0;memcpy(&zNear,&dg_wire_message->args[4],sizeof(zNear));
    GLdouble zFar=0;memcpy(&zFar,&dg_wire_message->args[5],sizeof(zFar));
    typedef void (*Proc)(GLdouble left, GLdouble right, GLdouble bottom, GLdouble top, GLdouble zNear, GLdouble zFar);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glOrtho");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(left,right,bottom,top,zNear,zFar);
    return 0;
}
case 190: {
    GLfloat token=0;memcpy(&token,&dg_wire_message->args[0],sizeof(token));
    typedef void (*Proc)(GLfloat token);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPassThrough");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(token);
    return 0;
}
case 191: {
    GLenum map=0;memcpy(&map,&dg_wire_message->args[0],sizeof(map));
    GLsizei mapsize=0;memcpy(&mapsize,&dg_wire_message->args[1],sizeof(mapsize));
    const GLfloat * values=NULL;
    void *pixel_pointer=NULL;
    int admitted=DGHostPixelMapPointer(context,dg_wire_message,map,mapsize,sizeof(*values),2,0,&pixel_pointer);
    if(admitted<=0)return admitted;values=(const GLfloat *)pixel_pointer;
    typedef void (*Proc)(GLenum map, GLsizei mapsize, const GLfloat *values);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPixelMapfv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(map,mapsize,values);
    return 0;
}
case 192: {
    GLenum map=0;memcpy(&map,&dg_wire_message->args[0],sizeof(map));
    GLsizei mapsize=0;memcpy(&mapsize,&dg_wire_message->args[1],sizeof(mapsize));
    const GLuint * values=NULL;
    void *pixel_pointer=NULL;
    int admitted=DGHostPixelMapPointer(context,dg_wire_message,map,mapsize,sizeof(*values),2,0,&pixel_pointer);
    if(admitted<=0)return admitted;values=(const GLuint *)pixel_pointer;
    typedef void (*Proc)(GLenum map, GLsizei mapsize, const GLuint *values);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPixelMapuiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(map,mapsize,values);
    return 0;
}
case 193: {
    GLenum map=0;memcpy(&map,&dg_wire_message->args[0],sizeof(map));
    GLsizei mapsize=0;memcpy(&mapsize,&dg_wire_message->args[1],sizeof(mapsize));
    const GLushort * values=NULL;
    void *pixel_pointer=NULL;
    int admitted=DGHostPixelMapPointer(context,dg_wire_message,map,mapsize,sizeof(*values),2,0,&pixel_pointer);
    if(admitted<=0)return admitted;values=(const GLushort *)pixel_pointer;
    typedef void (*Proc)(GLenum map, GLsizei mapsize, const GLushort *values);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPixelMapusv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(map,mapsize,values);
    return 0;
}
case 194: {
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[0],sizeof(pname));
    GLfloat param=0;memcpy(&param,&dg_wire_message->args[1],sizeof(param));
    if(pname==GL_UNPACK_CLIENT_STORAGE_APPLE) { context->client_storage=!!param;return 0; }
    typedef void (*Proc)(GLenum pname, GLfloat param);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPixelStoref");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pname,param);
    return 0;
}
case 195: {
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[0],sizeof(pname));
    GLint param=0;memcpy(&param,&dg_wire_message->args[1],sizeof(param));
    if(pname==GL_UNPACK_CLIENT_STORAGE_APPLE) { context->client_storage=!!param;return 0; }
    typedef void (*Proc)(GLenum pname, GLint param);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPixelStorei");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pname,param);
    return 0;
}
case 196: {
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[0],sizeof(pname));
    GLfloat param=0;memcpy(&param,&dg_wire_message->args[1],sizeof(param));
    typedef void (*Proc)(GLenum pname, GLfloat param);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPixelTransferf");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pname,param);
    return 0;
}
case 197: {
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[0],sizeof(pname));
    GLint param=0;memcpy(&param,&dg_wire_message->args[1],sizeof(param));
    typedef void (*Proc)(GLenum pname, GLint param);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPixelTransferi");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pname,param);
    return 0;
}
case 198: {
    GLfloat xfactor=0;memcpy(&xfactor,&dg_wire_message->args[0],sizeof(xfactor));
    GLfloat yfactor=0;memcpy(&yfactor,&dg_wire_message->args[1],sizeof(yfactor));
    typedef void (*Proc)(GLfloat xfactor, GLfloat yfactor);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPixelZoom");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(xfactor,yfactor);
    return 0;
}
case 199: {
    GLfloat size=0;memcpy(&size,&dg_wire_message->args[0],sizeof(size));
    typedef void (*Proc)(GLfloat size);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPointSize");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(size);
    return 0;
}
case 200: {
    GLenum face=0;memcpy(&face,&dg_wire_message->args[0],sizeof(face));
    GLenum mode=0;memcpy(&mode,&dg_wire_message->args[1],sizeof(mode));
    typedef void (*Proc)(GLenum face, GLenum mode);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPolygonMode");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(face,mode);
    return 0;
}
case 201: {
    GLfloat factor=0;memcpy(&factor,&dg_wire_message->args[0],sizeof(factor));
    GLfloat units=0;memcpy(&units,&dg_wire_message->args[1],sizeof(units));
    typedef void (*Proc)(GLfloat factor, GLfloat units);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPolygonOffset");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(factor,units);
    return 0;
}
case 202: {
    const GLubyte * mask=NULL;
    void *pixel_pointer=NULL;
    int admitted=DGHostCompatRasterPointer(context,dg_wire_message,32,32,GL_COLOR_INDEX,GL_BITMAP,0,0,&pixel_pointer);
    if(admitted<=0)return admitted;mask=(const GLubyte *)pixel_pointer;
    typedef void (*Proc)(const GLubyte *mask);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPolygonStipple");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(mask);
    return 0;
}
case 203: {
    typedef void (*Proc)(void);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPopAttrib");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc();
    context->alias_bindings_dirty=1;
    context->iosurface_draw_dirty=1;
    return 0;
}
case 204: {
    typedef void (*Proc)(void);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPopClientAttrib");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc();
    context->array_enable_valid=0;
    return 0;
}
case 205: {
    typedef void (*Proc)(void);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPopMatrix");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc();
    return 0;
}
case 206: {
    typedef void (*Proc)(void);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPopName");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc();
    return 0;
}
case 207: {
    GLsizei n=0;memcpy(&n,&dg_wire_message->args[0],sizeof(n));
    const GLuint * textures=NULL;
    const GLclampf * priorities=NULL;
    textures=(const GLuint *)DGHostPointer(dg_wire_message,1,((DGQueryArrayBytes(n,sizeof(GLuint))) ? (DGQueryArrayBytes(n,sizeof(GLuint))) : 1));
    if(!textures) return -1;
    priorities=(const GLclampf *)DGHostPointer(dg_wire_message,2,((DGQueryArrayBytes(n,sizeof(GLclampf))) ? (DGQueryArrayBytes(n,sizeof(GLclampf))) : 1));
    if(!priorities) return -1;
    typedef void (*Proc)(GLsizei n, const GLuint *textures, const GLclampf *priorities);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPrioritizeTextures");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    if(n>=0 && !context->inside_begin){
        for(GLsizei i=0;i<n;++i)if(!DGPrivateTextureContains(context->alias_group->private_textures,textures[i]))proc(1,textures+i,priorities+i);
        return 0;
    }
    proc(n,textures,priorities);
    return 0;
}
case 208: {
    GLbitfield mask=0;memcpy(&mask,&dg_wire_message->args[0],sizeof(mask));
    typedef void (*Proc)(GLbitfield mask);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPushAttrib");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(mask);
    return 0;
}
case 209: {
    GLbitfield mask=0;memcpy(&mask,&dg_wire_message->args[0],sizeof(mask));
    typedef void (*Proc)(GLbitfield mask);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPushClientAttrib");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(mask);
    context->array_enable_valid=0;
    return 0;
}
case 210: {
    typedef void (*Proc)(void);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPushMatrix");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc();
    return 0;
}
case 211: {
    GLuint name=0;memcpy(&name,&dg_wire_message->args[0],sizeof(name));
    typedef void (*Proc)(GLuint name);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPushName");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(name);
    return 0;
}
case 212: {
    GLdouble x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLdouble y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    typedef void (*Proc)(GLdouble x, GLdouble y);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRasterPos2d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y);
    return 0;
}
case 213: {
    const GLdouble * v=NULL;
    v=(const GLdouble *)DGHostPointer(dg_wire_message,0,(2*sizeof(GLdouble)));
    if(!v) return -1;
    typedef void (*Proc)(const GLdouble *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRasterPos2dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 214: {
    GLfloat x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLfloat y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    typedef void (*Proc)(GLfloat x, GLfloat y);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRasterPos2f");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y);
    return 0;
}
case 215: {
    const GLfloat * v=NULL;
    v=(const GLfloat *)DGHostPointer(dg_wire_message,0,(2*sizeof(GLfloat)));
    if(!v) return -1;
    typedef void (*Proc)(const GLfloat *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRasterPos2fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 216: {
    GLint x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLint y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    typedef void (*Proc)(GLint x, GLint y);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRasterPos2i");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y);
    return 0;
}
case 217: {
    const GLint * v=NULL;
    v=(const GLint *)DGHostPointer(dg_wire_message,0,(2*sizeof(GLint)));
    if(!v) return -1;
    typedef void (*Proc)(const GLint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRasterPos2iv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 218: {
    GLshort x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLshort y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    typedef void (*Proc)(GLshort x, GLshort y);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRasterPos2s");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y);
    return 0;
}
case 219: {
    const GLshort * v=NULL;
    v=(const GLshort *)DGHostPointer(dg_wire_message,0,(2*sizeof(GLshort)));
    if(!v) return -1;
    typedef void (*Proc)(const GLshort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRasterPos2sv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 220: {
    GLdouble x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLdouble y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    GLdouble z=0;memcpy(&z,&dg_wire_message->args[2],sizeof(z));
    typedef void (*Proc)(GLdouble x, GLdouble y, GLdouble z);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRasterPos3d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y,z);
    return 0;
}
case 221: {
    const GLdouble * v=NULL;
    v=(const GLdouble *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLdouble)));
    if(!v) return -1;
    typedef void (*Proc)(const GLdouble *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRasterPos3dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 222: {
    GLfloat x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLfloat y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    GLfloat z=0;memcpy(&z,&dg_wire_message->args[2],sizeof(z));
    typedef void (*Proc)(GLfloat x, GLfloat y, GLfloat z);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRasterPos3f");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y,z);
    return 0;
}
case 223: {
    const GLfloat * v=NULL;
    v=(const GLfloat *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLfloat)));
    if(!v) return -1;
    typedef void (*Proc)(const GLfloat *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRasterPos3fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 224: {
    GLint x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLint y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    GLint z=0;memcpy(&z,&dg_wire_message->args[2],sizeof(z));
    typedef void (*Proc)(GLint x, GLint y, GLint z);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRasterPos3i");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y,z);
    return 0;
}
case 225: {
    const GLint * v=NULL;
    v=(const GLint *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLint)));
    if(!v) return -1;
    typedef void (*Proc)(const GLint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRasterPos3iv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 226: {
    GLshort x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLshort y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    GLshort z=0;memcpy(&z,&dg_wire_message->args[2],sizeof(z));
    typedef void (*Proc)(GLshort x, GLshort y, GLshort z);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRasterPos3s");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y,z);
    return 0;
}
case 227: {
    const GLshort * v=NULL;
    v=(const GLshort *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLshort)));
    if(!v) return -1;
    typedef void (*Proc)(const GLshort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRasterPos3sv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 228: {
    GLdouble x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLdouble y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    GLdouble z=0;memcpy(&z,&dg_wire_message->args[2],sizeof(z));
    GLdouble w=0;memcpy(&w,&dg_wire_message->args[3],sizeof(w));
    typedef void (*Proc)(GLdouble x, GLdouble y, GLdouble z, GLdouble w);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRasterPos4d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y,z,w);
    return 0;
}
case 229: {
    const GLdouble * v=NULL;
    v=(const GLdouble *)DGHostPointer(dg_wire_message,0,(4*sizeof(GLdouble)));
    if(!v) return -1;
    typedef void (*Proc)(const GLdouble *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRasterPos4dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 230: {
    GLfloat x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLfloat y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    GLfloat z=0;memcpy(&z,&dg_wire_message->args[2],sizeof(z));
    GLfloat w=0;memcpy(&w,&dg_wire_message->args[3],sizeof(w));
    typedef void (*Proc)(GLfloat x, GLfloat y, GLfloat z, GLfloat w);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRasterPos4f");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y,z,w);
    return 0;
}
case 231: {
    const GLfloat * v=NULL;
    v=(const GLfloat *)DGHostPointer(dg_wire_message,0,(4*sizeof(GLfloat)));
    if(!v) return -1;
    typedef void (*Proc)(const GLfloat *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRasterPos4fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 232: {
    GLint x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLint y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    GLint z=0;memcpy(&z,&dg_wire_message->args[2],sizeof(z));
    GLint w=0;memcpy(&w,&dg_wire_message->args[3],sizeof(w));
    typedef void (*Proc)(GLint x, GLint y, GLint z, GLint w);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRasterPos4i");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y,z,w);
    return 0;
}
case 233: {
    const GLint * v=NULL;
    v=(const GLint *)DGHostPointer(dg_wire_message,0,(4*sizeof(GLint)));
    if(!v) return -1;
    typedef void (*Proc)(const GLint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRasterPos4iv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 234: {
    GLshort x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLshort y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    GLshort z=0;memcpy(&z,&dg_wire_message->args[2],sizeof(z));
    GLshort w=0;memcpy(&w,&dg_wire_message->args[3],sizeof(w));
    typedef void (*Proc)(GLshort x, GLshort y, GLshort z, GLshort w);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRasterPos4s");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y,z,w);
    return 0;
}
case 235: {
    const GLshort * v=NULL;
    v=(const GLshort *)DGHostPointer(dg_wire_message,0,(4*sizeof(GLshort)));
    if(!v) return -1;
    typedef void (*Proc)(const GLshort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRasterPos4sv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 236: {
    GLenum mode=0;memcpy(&mode,&dg_wire_message->args[0],sizeof(mode));
    DGSetBuffer(context,mode,1);
    return 0;
}
case 237: {
    GLint pixel_buffer=0;if(context->inside_begin) { context->error=GL_INVALID_OPERATION;return 0; }glGetIntegerv(GL_PIXEL_PACK_BUFFER_BINDING,&pixel_buffer);if(pixel_buffer) { context->error=GL_INVALID_OPERATION;return 0; }
    GLint x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLint y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[2],sizeof(width));
    GLsizei height=0;memcpy(&height,&dg_wire_message->args[3],sizeof(height));
    GLenum format=0;memcpy(&format,&dg_wire_message->args[4],sizeof(format));
    GLenum type=0;memcpy(&type,&dg_wire_message->args[5],sizeof(type));
    return DGHostReadPixels(context,dg_wire_message,x,y,width,height,format,type);
}
case 238: {
    GLdouble x1=0;memcpy(&x1,&dg_wire_message->args[0],sizeof(x1));
    GLdouble y1=0;memcpy(&y1,&dg_wire_message->args[1],sizeof(y1));
    GLdouble x2=0;memcpy(&x2,&dg_wire_message->args[2],sizeof(x2));
    GLdouble y2=0;memcpy(&y2,&dg_wire_message->args[3],sizeof(y2));
    typedef void (*Proc)(GLdouble x1, GLdouble y1, GLdouble x2, GLdouble y2);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRectd");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    DGPrepareDrawableAliases(context,0);
    if(!DGDrawableWritable(context)) return 0;
    proc(x1,y1,x2,y2);
    DGMarkDrawableDamage(context);
    return 0;
}
case 239: {
    const GLdouble * v1=NULL;
    const GLdouble * v2=NULL;
    v1=(const GLdouble *)DGHostPointer(dg_wire_message,0,(2*sizeof(GLdouble)));
    if(!v1) return -1;
    v2=(const GLdouble *)DGHostPointer(dg_wire_message,1,(2*sizeof(GLdouble)));
    if(!v2) return -1;
    typedef void (*Proc)(const GLdouble *v1, const GLdouble *v2);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRectdv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    DGPrepareDrawableAliases(context,0);
    if(!DGDrawableWritable(context)) return 0;
    proc(v1,v2);
    DGMarkDrawableDamage(context);
    return 0;
}
case 240: {
    GLfloat x1=0;memcpy(&x1,&dg_wire_message->args[0],sizeof(x1));
    GLfloat y1=0;memcpy(&y1,&dg_wire_message->args[1],sizeof(y1));
    GLfloat x2=0;memcpy(&x2,&dg_wire_message->args[2],sizeof(x2));
    GLfloat y2=0;memcpy(&y2,&dg_wire_message->args[3],sizeof(y2));
    typedef void (*Proc)(GLfloat x1, GLfloat y1, GLfloat x2, GLfloat y2);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRectf");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    DGPrepareDrawableAliases(context,0);
    if(!DGDrawableWritable(context)) return 0;
    proc(x1,y1,x2,y2);
    DGMarkDrawableDamage(context);
    return 0;
}
case 241: {
    const GLfloat * v1=NULL;
    const GLfloat * v2=NULL;
    v1=(const GLfloat *)DGHostPointer(dg_wire_message,0,(2*sizeof(GLfloat)));
    if(!v1) return -1;
    v2=(const GLfloat *)DGHostPointer(dg_wire_message,1,(2*sizeof(GLfloat)));
    if(!v2) return -1;
    typedef void (*Proc)(const GLfloat *v1, const GLfloat *v2);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRectfv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    DGPrepareDrawableAliases(context,0);
    if(!DGDrawableWritable(context)) return 0;
    proc(v1,v2);
    DGMarkDrawableDamage(context);
    return 0;
}
case 242: {
    GLint x1=0;memcpy(&x1,&dg_wire_message->args[0],sizeof(x1));
    GLint y1=0;memcpy(&y1,&dg_wire_message->args[1],sizeof(y1));
    GLint x2=0;memcpy(&x2,&dg_wire_message->args[2],sizeof(x2));
    GLint y2=0;memcpy(&y2,&dg_wire_message->args[3],sizeof(y2));
    typedef void (*Proc)(GLint x1, GLint y1, GLint x2, GLint y2);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRecti");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    DGPrepareDrawableAliases(context,0);
    if(!DGDrawableWritable(context)) return 0;
    proc(x1,y1,x2,y2);
    DGMarkDrawableDamage(context);
    return 0;
}
case 243: {
    const GLint * v1=NULL;
    const GLint * v2=NULL;
    v1=(const GLint *)DGHostPointer(dg_wire_message,0,(2*sizeof(GLint)));
    if(!v1) return -1;
    v2=(const GLint *)DGHostPointer(dg_wire_message,1,(2*sizeof(GLint)));
    if(!v2) return -1;
    typedef void (*Proc)(const GLint *v1, const GLint *v2);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRectiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    DGPrepareDrawableAliases(context,0);
    if(!DGDrawableWritable(context)) return 0;
    proc(v1,v2);
    DGMarkDrawableDamage(context);
    return 0;
}
case 244: {
    GLshort x1=0;memcpy(&x1,&dg_wire_message->args[0],sizeof(x1));
    GLshort y1=0;memcpy(&y1,&dg_wire_message->args[1],sizeof(y1));
    GLshort x2=0;memcpy(&x2,&dg_wire_message->args[2],sizeof(x2));
    GLshort y2=0;memcpy(&y2,&dg_wire_message->args[3],sizeof(y2));
    typedef void (*Proc)(GLshort x1, GLshort y1, GLshort x2, GLshort y2);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRects");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    DGPrepareDrawableAliases(context,0);
    if(!DGDrawableWritable(context)) return 0;
    proc(x1,y1,x2,y2);
    DGMarkDrawableDamage(context);
    return 0;
}
case 245: {
    const GLshort * v1=NULL;
    const GLshort * v2=NULL;
    v1=(const GLshort *)DGHostPointer(dg_wire_message,0,(2*sizeof(GLshort)));
    if(!v1) return -1;
    v2=(const GLshort *)DGHostPointer(dg_wire_message,1,(2*sizeof(GLshort)));
    if(!v2) return -1;
    typedef void (*Proc)(const GLshort *v1, const GLshort *v2);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRectsv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    DGPrepareDrawableAliases(context,0);
    if(!DGDrawableWritable(context)) return 0;
    proc(v1,v2);
    DGMarkDrawableDamage(context);
    return 0;
}
case 246: return DGHostRenderMode(context,dg_wire_message,reply);
case 247: {
    GLdouble angle=0;memcpy(&angle,&dg_wire_message->args[0],sizeof(angle));
    GLdouble x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    GLdouble y=0;memcpy(&y,&dg_wire_message->args[2],sizeof(y));
    GLdouble z=0;memcpy(&z,&dg_wire_message->args[3],sizeof(z));
    typedef void (*Proc)(GLdouble angle, GLdouble x, GLdouble y, GLdouble z);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRotated");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(angle,x,y,z);
    return 0;
}
case 248: {
    GLfloat angle=0;memcpy(&angle,&dg_wire_message->args[0],sizeof(angle));
    GLfloat x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    GLfloat y=0;memcpy(&y,&dg_wire_message->args[2],sizeof(y));
    GLfloat z=0;memcpy(&z,&dg_wire_message->args[3],sizeof(z));
    typedef void (*Proc)(GLfloat angle, GLfloat x, GLfloat y, GLfloat z);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRotatef");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(angle,x,y,z);
    return 0;
}
case 249: {
    GLdouble x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLdouble y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    GLdouble z=0;memcpy(&z,&dg_wire_message->args[2],sizeof(z));
    typedef void (*Proc)(GLdouble x, GLdouble y, GLdouble z);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glScaled");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y,z);
    return 0;
}
case 250: {
    GLfloat x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLfloat y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    GLfloat z=0;memcpy(&z,&dg_wire_message->args[2],sizeof(z));
    typedef void (*Proc)(GLfloat x, GLfloat y, GLfloat z);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glScalef");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y,z);
    return 0;
}
case 251: {
    GLint x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLint y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[2],sizeof(width));
    GLsizei height=0;memcpy(&height,&dg_wire_message->args[3],sizeof(height));
    typedef void (*Proc)(GLint x, GLint y, GLsizei width, GLsizei height);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glScissor");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y,width,height);
    return 0;
}
case 252: return DGHostRegisterRenderBuffer(context,dg_wire_message,reply,0);
case 253: {
    GLenum mode=0;memcpy(&mode,&dg_wire_message->args[0],sizeof(mode));
    typedef void (*Proc)(GLenum mode);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glShadeModel");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(mode);
    return 0;
}
case 254: {
    GLenum func=0;memcpy(&func,&dg_wire_message->args[0],sizeof(func));
    GLint ref=0;memcpy(&ref,&dg_wire_message->args[1],sizeof(ref));
    GLuint mask=0;memcpy(&mask,&dg_wire_message->args[2],sizeof(mask));
    typedef void (*Proc)(GLenum func, GLint ref, GLuint mask);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glStencilFunc");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(func,ref,mask);
    return 0;
}
case 255: {
    GLuint mask=0;memcpy(&mask,&dg_wire_message->args[0],sizeof(mask));
    typedef void (*Proc)(GLuint mask);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glStencilMask");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(mask);
    return 0;
}
case 256: {
    GLenum fail=0;memcpy(&fail,&dg_wire_message->args[0],sizeof(fail));
    GLenum zfail=0;memcpy(&zfail,&dg_wire_message->args[1],sizeof(zfail));
    GLenum zpass=0;memcpy(&zpass,&dg_wire_message->args[2],sizeof(zpass));
    typedef void (*Proc)(GLenum fail, GLenum zfail, GLenum zpass);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glStencilOp");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(fail,zfail,zpass);
    return 0;
}
case 257: {
    GLdouble s=0;memcpy(&s,&dg_wire_message->args[0],sizeof(s));
    typedef void (*Proc)(GLdouble s);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord1d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(s);
    return 0;
}
case 258: {
    const GLdouble * v=NULL;
    v=(const GLdouble *)DGHostPointer(dg_wire_message,0,(1*sizeof(GLdouble)));
    if(!v) return -1;
    typedef void (*Proc)(const GLdouble *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord1dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 259: {
    GLfloat s=0;memcpy(&s,&dg_wire_message->args[0],sizeof(s));
    typedef void (*Proc)(GLfloat s);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord1f");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(s);
    return 0;
}
case 260: {
    const GLfloat * v=NULL;
    v=(const GLfloat *)DGHostPointer(dg_wire_message,0,(1*sizeof(GLfloat)));
    if(!v) return -1;
    typedef void (*Proc)(const GLfloat *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord1fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 261: {
    GLint s=0;memcpy(&s,&dg_wire_message->args[0],sizeof(s));
    typedef void (*Proc)(GLint s);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord1i");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(s);
    return 0;
}
case 262: {
    const GLint * v=NULL;
    v=(const GLint *)DGHostPointer(dg_wire_message,0,(1*sizeof(GLint)));
    if(!v) return -1;
    typedef void (*Proc)(const GLint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord1iv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 263: {
    GLshort s=0;memcpy(&s,&dg_wire_message->args[0],sizeof(s));
    typedef void (*Proc)(GLshort s);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord1s");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(s);
    return 0;
}
case 264: {
    const GLshort * v=NULL;
    v=(const GLshort *)DGHostPointer(dg_wire_message,0,(1*sizeof(GLshort)));
    if(!v) return -1;
    typedef void (*Proc)(const GLshort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord1sv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 265: {
    GLdouble s=0;memcpy(&s,&dg_wire_message->args[0],sizeof(s));
    GLdouble t=0;memcpy(&t,&dg_wire_message->args[1],sizeof(t));
    typedef void (*Proc)(GLdouble s, GLdouble t);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord2d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(s,t);
    return 0;
}
case 266: {
    const GLdouble * v=NULL;
    v=(const GLdouble *)DGHostPointer(dg_wire_message,0,(2*sizeof(GLdouble)));
    if(!v) return -1;
    typedef void (*Proc)(const GLdouble *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord2dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 267: {
    GLfloat s=0;memcpy(&s,&dg_wire_message->args[0],sizeof(s));
    GLfloat t=0;memcpy(&t,&dg_wire_message->args[1],sizeof(t));
    typedef void (*Proc)(GLfloat s, GLfloat t);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord2f");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(s,t);
    return 0;
}
case 268: {
    const GLfloat * v=NULL;
    v=(const GLfloat *)DGHostPointer(dg_wire_message,0,(2*sizeof(GLfloat)));
    if(!v) return -1;
    typedef void (*Proc)(const GLfloat *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord2fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 269: {
    GLint s=0;memcpy(&s,&dg_wire_message->args[0],sizeof(s));
    GLint t=0;memcpy(&t,&dg_wire_message->args[1],sizeof(t));
    typedef void (*Proc)(GLint s, GLint t);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord2i");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(s,t);
    return 0;
}
case 270: {
    const GLint * v=NULL;
    v=(const GLint *)DGHostPointer(dg_wire_message,0,(2*sizeof(GLint)));
    if(!v) return -1;
    typedef void (*Proc)(const GLint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord2iv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 271: {
    GLshort s=0;memcpy(&s,&dg_wire_message->args[0],sizeof(s));
    GLshort t=0;memcpy(&t,&dg_wire_message->args[1],sizeof(t));
    typedef void (*Proc)(GLshort s, GLshort t);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord2s");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(s,t);
    return 0;
}
case 272: {
    const GLshort * v=NULL;
    v=(const GLshort *)DGHostPointer(dg_wire_message,0,(2*sizeof(GLshort)));
    if(!v) return -1;
    typedef void (*Proc)(const GLshort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord2sv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 273: {
    GLdouble s=0;memcpy(&s,&dg_wire_message->args[0],sizeof(s));
    GLdouble t=0;memcpy(&t,&dg_wire_message->args[1],sizeof(t));
    GLdouble r=0;memcpy(&r,&dg_wire_message->args[2],sizeof(r));
    typedef void (*Proc)(GLdouble s, GLdouble t, GLdouble r);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord3d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(s,t,r);
    return 0;
}
case 274: {
    const GLdouble * v=NULL;
    v=(const GLdouble *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLdouble)));
    if(!v) return -1;
    typedef void (*Proc)(const GLdouble *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord3dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 275: {
    GLfloat s=0;memcpy(&s,&dg_wire_message->args[0],sizeof(s));
    GLfloat t=0;memcpy(&t,&dg_wire_message->args[1],sizeof(t));
    GLfloat r=0;memcpy(&r,&dg_wire_message->args[2],sizeof(r));
    typedef void (*Proc)(GLfloat s, GLfloat t, GLfloat r);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord3f");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(s,t,r);
    return 0;
}
case 276: {
    const GLfloat * v=NULL;
    v=(const GLfloat *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLfloat)));
    if(!v) return -1;
    typedef void (*Proc)(const GLfloat *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord3fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 277: {
    GLint s=0;memcpy(&s,&dg_wire_message->args[0],sizeof(s));
    GLint t=0;memcpy(&t,&dg_wire_message->args[1],sizeof(t));
    GLint r=0;memcpy(&r,&dg_wire_message->args[2],sizeof(r));
    typedef void (*Proc)(GLint s, GLint t, GLint r);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord3i");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(s,t,r);
    return 0;
}
case 278: {
    const GLint * v=NULL;
    v=(const GLint *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLint)));
    if(!v) return -1;
    typedef void (*Proc)(const GLint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord3iv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 279: {
    GLshort s=0;memcpy(&s,&dg_wire_message->args[0],sizeof(s));
    GLshort t=0;memcpy(&t,&dg_wire_message->args[1],sizeof(t));
    GLshort r=0;memcpy(&r,&dg_wire_message->args[2],sizeof(r));
    typedef void (*Proc)(GLshort s, GLshort t, GLshort r);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord3s");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(s,t,r);
    return 0;
}
case 280: {
    const GLshort * v=NULL;
    v=(const GLshort *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLshort)));
    if(!v) return -1;
    typedef void (*Proc)(const GLshort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord3sv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 281: {
    GLdouble s=0;memcpy(&s,&dg_wire_message->args[0],sizeof(s));
    GLdouble t=0;memcpy(&t,&dg_wire_message->args[1],sizeof(t));
    GLdouble r=0;memcpy(&r,&dg_wire_message->args[2],sizeof(r));
    GLdouble q=0;memcpy(&q,&dg_wire_message->args[3],sizeof(q));
    typedef void (*Proc)(GLdouble s, GLdouble t, GLdouble r, GLdouble q);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord4d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(s,t,r,q);
    return 0;
}
case 282: {
    const GLdouble * v=NULL;
    v=(const GLdouble *)DGHostPointer(dg_wire_message,0,(4*sizeof(GLdouble)));
    if(!v) return -1;
    typedef void (*Proc)(const GLdouble *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord4dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 283: {
    GLfloat s=0;memcpy(&s,&dg_wire_message->args[0],sizeof(s));
    GLfloat t=0;memcpy(&t,&dg_wire_message->args[1],sizeof(t));
    GLfloat r=0;memcpy(&r,&dg_wire_message->args[2],sizeof(r));
    GLfloat q=0;memcpy(&q,&dg_wire_message->args[3],sizeof(q));
    typedef void (*Proc)(GLfloat s, GLfloat t, GLfloat r, GLfloat q);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord4f");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(s,t,r,q);
    return 0;
}
case 284: {
    const GLfloat * v=NULL;
    v=(const GLfloat *)DGHostPointer(dg_wire_message,0,(4*sizeof(GLfloat)));
    if(!v) return -1;
    typedef void (*Proc)(const GLfloat *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord4fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 285: {
    GLint s=0;memcpy(&s,&dg_wire_message->args[0],sizeof(s));
    GLint t=0;memcpy(&t,&dg_wire_message->args[1],sizeof(t));
    GLint r=0;memcpy(&r,&dg_wire_message->args[2],sizeof(r));
    GLint q=0;memcpy(&q,&dg_wire_message->args[3],sizeof(q));
    typedef void (*Proc)(GLint s, GLint t, GLint r, GLint q);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord4i");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(s,t,r,q);
    return 0;
}
case 286: {
    const GLint * v=NULL;
    v=(const GLint *)DGHostPointer(dg_wire_message,0,(4*sizeof(GLint)));
    if(!v) return -1;
    typedef void (*Proc)(const GLint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord4iv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 287: {
    GLshort s=0;memcpy(&s,&dg_wire_message->args[0],sizeof(s));
    GLshort t=0;memcpy(&t,&dg_wire_message->args[1],sizeof(t));
    GLshort r=0;memcpy(&r,&dg_wire_message->args[2],sizeof(r));
    GLshort q=0;memcpy(&q,&dg_wire_message->args[3],sizeof(q));
    typedef void (*Proc)(GLshort s, GLshort t, GLshort r, GLshort q);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord4s");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(s,t,r,q);
    return 0;
}
case 288: {
    const GLshort * v=NULL;
    v=(const GLshort *)DGHostPointer(dg_wire_message,0,(4*sizeof(GLshort)));
    if(!v) return -1;
    typedef void (*Proc)(const GLshort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexCoord4sv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 290: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLfloat param=0;memcpy(&param,&dg_wire_message->args[2],sizeof(param));
    typedef void (*Proc)(GLenum target, GLenum pname, GLfloat param);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexEnvf");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,pname,param);
    return 0;
}
case 291: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    const GLfloat * params=NULL;
    params=(const GLfloat *)DGHostPointer(dg_wire_message,2,((pname==GL_TEXTURE_ENV_COLOR ? 4 : 1)*sizeof(GLfloat)));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLenum pname, const GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexEnvfv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,pname,params);
    return 0;
}
case 292: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint param=0;memcpy(&param,&dg_wire_message->args[2],sizeof(param));
    typedef void (*Proc)(GLenum target, GLenum pname, GLint param);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexEnvi");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,pname,param);
    return 0;
}
case 293: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    const GLint * params=NULL;
    params=(const GLint *)DGHostPointer(dg_wire_message,2,((pname==GL_TEXTURE_ENV_COLOR ? 4 : 1)*sizeof(GLint)));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLenum pname, const GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexEnviv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,pname,params);
    return 0;
}
case 294: {
    GLenum coord=0;memcpy(&coord,&dg_wire_message->args[0],sizeof(coord));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLdouble param=0;memcpy(&param,&dg_wire_message->args[2],sizeof(param));
    typedef void (*Proc)(GLenum coord, GLenum pname, GLdouble param);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexGend");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(coord,pname,param);
    return 0;
}
case 295: {
    GLenum coord=0;memcpy(&coord,&dg_wire_message->args[0],sizeof(coord));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    const GLdouble * params=NULL;
    params=(const GLdouble *)DGHostPointer(dg_wire_message,2,((pname==GL_OBJECT_PLANE || pname==GL_EYE_PLANE ? 4 : 1)*sizeof(GLdouble)));
    if(!params) return -1;
    typedef void (*Proc)(GLenum coord, GLenum pname, const GLdouble *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexGendv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(coord,pname,params);
    return 0;
}
case 296: {
    GLenum coord=0;memcpy(&coord,&dg_wire_message->args[0],sizeof(coord));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLfloat param=0;memcpy(&param,&dg_wire_message->args[2],sizeof(param));
    typedef void (*Proc)(GLenum coord, GLenum pname, GLfloat param);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexGenf");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(coord,pname,param);
    return 0;
}
case 297: {
    GLenum coord=0;memcpy(&coord,&dg_wire_message->args[0],sizeof(coord));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    const GLfloat * params=NULL;
    params=(const GLfloat *)DGHostPointer(dg_wire_message,2,((pname==GL_OBJECT_PLANE || pname==GL_EYE_PLANE ? 4 : 1)*sizeof(GLfloat)));
    if(!params) return -1;
    typedef void (*Proc)(GLenum coord, GLenum pname, const GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexGenfv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(coord,pname,params);
    return 0;
}
case 298: {
    GLenum coord=0;memcpy(&coord,&dg_wire_message->args[0],sizeof(coord));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint param=0;memcpy(&param,&dg_wire_message->args[2],sizeof(param));
    typedef void (*Proc)(GLenum coord, GLenum pname, GLint param);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexGeni");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(coord,pname,param);
    return 0;
}
case 299: {
    GLenum coord=0;memcpy(&coord,&dg_wire_message->args[0],sizeof(coord));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    const GLint * params=NULL;
    params=(const GLint *)DGHostPointer(dg_wire_message,2,((pname==GL_OBJECT_PLANE || pname==GL_EYE_PLANE ? 4 : 1)*sizeof(GLint)));
    if(!params) return -1;
    typedef void (*Proc)(GLenum coord, GLenum pname, const GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexGeniv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(coord,pname,params);
    return 0;
}
case 300: {
    struct DGCompactUnpackScope compact_scope={0};
    if(dg_wire_message->args[15] && (dg_wire_message->args[15]!=2 || !dg_wire_message->args[7]))return -1;
    GLint pixel_buffer=0;if(context->inside_begin) { context->error=GL_INVALID_OPERATION;return 0; }glGetIntegerv(GL_PIXEL_UNPACK_BUFFER_BINDING,&pixel_buffer);if(pixel_buffer) { context->error=GL_INVALID_OPERATION;return 0; }
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLint level=0;memcpy(&level,&dg_wire_message->args[1],sizeof(level));
    GLint internalformat=0;memcpy(&internalformat,&dg_wire_message->args[2],sizeof(internalformat));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[3],sizeof(width));
    GLint border=0;memcpy(&border,&dg_wire_message->args[4],sizeof(border));
    GLenum format=0;memcpy(&format,&dg_wire_message->args[5],sizeof(format));
    GLenum type=0;memcpy(&type,&dg_wire_message->args[6],sizeof(type));
    const GLvoid * pixels=NULL;
    if(!(width>=0 && DGRasterPixelBits(format,type))) {
        if(dg_wire_message->args[7] || dg_wire_message->bytes || dg_wire_message->args[15])return -1;
    }else {
    if(dg_wire_message->args[7])pixels=(const GLvoid *)DGHostPointer(dg_wire_message,7,(DGHostUnpackBytes(context,dg_wire_message,1,width,1,1,format,type)));
    if(dg_wire_message->args[7] && !pixels) return -1;
    }
    typedef void (*Proc)(GLenum target, GLint level, GLint internalformat, GLsizei width, GLint border, GLenum format, GLenum type, const GLvoid *pixels);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexImage1D");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    if(!DGHostCompactUnpackBegin(context,dg_wire_message,&compact_scope))return 0;
    struct DGAutomaticMipmapScope automatic=DGBeginAutomaticMipmap(target,level,context->profile==kCGLOGLPVersion_Legacy,context->inside_begin,context->list_mode,&context->error,0,DGNonzeroMipmapBasePossible(context));
    proc(target,level,internalformat,width,border,format,type,pixels);
    DGHostCompactUnpackEnd(context,&compact_scope);
    DGEndAutomaticMipmap(&automatic,NULL,&context->error);
    return 0;
}
case 301: {
    struct DGCompactUnpackScope compact_scope={0};
    if(dg_wire_message->args[15] && (dg_wire_message->args[15]!=2 || !dg_wire_message->args[8]))return -1;
    GLint pixel_buffer=0;if(context->inside_begin) { context->error=GL_INVALID_OPERATION;return 0; }glGetIntegerv(GL_PIXEL_UNPACK_BUFFER_BINDING,&pixel_buffer);if(pixel_buffer) { context->error=GL_INVALID_OPERATION;return 0; }
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLint level=0;memcpy(&level,&dg_wire_message->args[1],sizeof(level));
    GLint internalformat=0;memcpy(&internalformat,&dg_wire_message->args[2],sizeof(internalformat));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[3],sizeof(width));
    GLsizei height=0;memcpy(&height,&dg_wire_message->args[4],sizeof(height));
    GLint border=0;memcpy(&border,&dg_wire_message->args[5],sizeof(border));
    GLenum format=0;memcpy(&format,&dg_wire_message->args[6],sizeof(format));
    GLenum type=0;memcpy(&type,&dg_wire_message->args[7],sizeof(type));
    const GLvoid * pixels=NULL;
    if(!(width>=0 && height>=0 && DGRasterPixelBits(format,type))) {
        if(dg_wire_message->args[8] || dg_wire_message->bytes || dg_wire_message->args[15])return -1;
    }else {
    if(dg_wire_message->args[8])pixels=(const GLvoid *)DGHostPointer(dg_wire_message,8,(DGHostUnpackBytes(context,dg_wire_message,2,width,height,1,format,type)));
    if(dg_wire_message->args[8] && !pixels) return -1;
    }
    typedef void (*Proc)(GLenum target, GLint level, GLint internalformat, GLsizei width, GLsizei height, GLint border, GLenum format, GLenum type, const GLvoid *pixels);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexImage2D");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLuint redefining_alias=(width>=0 && height>=0 && DGRasterPixelBits(format,type))?DGBeginAliasRedefinition(context,target,level):0;
    if(!DGHostCompactUnpackBegin(context,dg_wire_message,&compact_scope))return 0;
    struct DGAutomaticMipmapScope automatic=DGBeginAutomaticMipmap(target,level,context->profile==kCGLOGLPVersion_Legacy,context->inside_begin,context->list_mode,&context->error,0,DGNonzeroMipmapBasePossible(context));
    proc(target,level,internalformat,width,height,border,format,type,pixels);
    DGEndAliasRedefinition(context,redefining_alias);
    DGHostCompactUnpackEnd(context,&compact_scope);
    DGEndAutomaticMipmap(&automatic,NULL,&context->error);
    DGTraceTexture(context,width,height,format,type,pixels);
    return 0;
}
case 302: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLfloat param=0;memcpy(&param,&dg_wire_message->args[2],sizeof(param));
    typedef void (*Proc)(GLenum target, GLenum pname, GLfloat param);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexParameterf");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    if(context->profile==kCGLOGLPVersion_Legacy && context->alias_group && pname==GL_TEXTURE_BASE_LEVEL && param!=0)context->alias_group->nonzero_mipmap_base_possible=1;
    proc(target,pname,param);
    return 0;
}
case 303: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    const GLfloat * params=NULL;
    params=(const GLfloat *)DGHostPointer(dg_wire_message,2,((pname==GL_TEXTURE_BORDER_COLOR || pname==0x8e46 ? 4 : 1)*sizeof(GLfloat)));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLenum pname, const GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexParameterfv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    if(context->profile==kCGLOGLPVersion_Legacy && context->alias_group && pname==GL_TEXTURE_BASE_LEVEL && (params && params[0]!=0))context->alias_group->nonzero_mipmap_base_possible=1;
    proc(target,pname,params);
    return 0;
}
case 304: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint param=0;memcpy(&param,&dg_wire_message->args[2],sizeof(param));
    typedef void (*Proc)(GLenum target, GLenum pname, GLint param);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexParameteri");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    if(context->profile==kCGLOGLPVersion_Legacy && context->alias_group && pname==GL_TEXTURE_BASE_LEVEL && param!=0)context->alias_group->nonzero_mipmap_base_possible=1;
    proc(target,pname,param);
    return 0;
}
case 305: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    const GLint * params=NULL;
    params=(const GLint *)DGHostPointer(dg_wire_message,2,((pname==GL_TEXTURE_BORDER_COLOR || pname==0x8e46 ? 4 : 1)*sizeof(GLint)));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLenum pname, const GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexParameteriv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    if(context->profile==kCGLOGLPVersion_Legacy && context->alias_group && pname==GL_TEXTURE_BASE_LEVEL && (params && params[0]!=0))context->alias_group->nonzero_mipmap_base_possible=1;
    proc(target,pname,params);
    return 0;
}
case 306: {
    struct DGCompactUnpackScope compact_scope={0};
    if(dg_wire_message->args[15] && (dg_wire_message->args[15]!=2 || !dg_wire_message->args[6]))return -1;
    GLint pixel_buffer=0;if(context->inside_begin) { context->error=GL_INVALID_OPERATION;return 0; }glGetIntegerv(GL_PIXEL_UNPACK_BUFFER_BINDING,&pixel_buffer);if(pixel_buffer) { context->error=GL_INVALID_OPERATION;return 0; }
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLint level=0;memcpy(&level,&dg_wire_message->args[1],sizeof(level));
    GLint xoffset=0;memcpy(&xoffset,&dg_wire_message->args[2],sizeof(xoffset));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[3],sizeof(width));
    GLenum format=0;memcpy(&format,&dg_wire_message->args[4],sizeof(format));
    GLenum type=0;memcpy(&type,&dg_wire_message->args[5],sizeof(type));
    const GLvoid * pixels=NULL;
    if(!(width>=0 && DGRasterPixelBits(format,type))) {
        if(dg_wire_message->args[6] || dg_wire_message->bytes || dg_wire_message->args[15])return -1;
    }else {
    pixels=(const GLvoid *)DGHostPointer(dg_wire_message,6,(DGHostUnpackBytes(context,dg_wire_message,1,width,1,1,format,type)));
    if((width && !pixels) || (dg_wire_message->args[6] && !pixels)) return -1;
    }
    typedef void (*Proc)(GLenum target, GLint level, GLint xoffset, GLsizei width, GLenum format, GLenum type, const GLvoid *pixels);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexSubImage1D");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    if(!DGHostCompactUnpackBegin(context,dg_wire_message,&compact_scope))return 0;
    struct DGAutomaticMipmapScope automatic=DGBeginAutomaticMipmap(target,level,context->profile==kCGLOGLPVersion_Legacy,context->inside_begin,context->list_mode,&context->error,0,DGNonzeroMipmapBasePossible(context));
    proc(target,level,xoffset,width,format,type,pixels);
    DGHostCompactUnpackEnd(context,&compact_scope);
    DGEndAutomaticMipmap(&automatic,NULL,&context->error);
    return 0;
}
case 307: {
    struct DGCompactUnpackScope compact_scope={0};
    if(dg_wire_message->args[15] && (dg_wire_message->args[15]!=2 || !dg_wire_message->args[8]))return -1;
    GLint pixel_buffer=0;if(context->inside_begin) { context->error=GL_INVALID_OPERATION;return 0; }glGetIntegerv(GL_PIXEL_UNPACK_BUFFER_BINDING,&pixel_buffer);if(pixel_buffer) { context->error=GL_INVALID_OPERATION;return 0; }
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLint level=0;memcpy(&level,&dg_wire_message->args[1],sizeof(level));
    GLint xoffset=0;memcpy(&xoffset,&dg_wire_message->args[2],sizeof(xoffset));
    GLint yoffset=0;memcpy(&yoffset,&dg_wire_message->args[3],sizeof(yoffset));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[4],sizeof(width));
    GLsizei height=0;memcpy(&height,&dg_wire_message->args[5],sizeof(height));
    GLenum format=0;memcpy(&format,&dg_wire_message->args[6],sizeof(format));
    GLenum type=0;memcpy(&type,&dg_wire_message->args[7],sizeof(type));
    const GLvoid * pixels=NULL;
    if(!(width>=0 && height>=0 && DGRasterPixelBits(format,type))) {
        if(dg_wire_message->args[8] || dg_wire_message->bytes || dg_wire_message->args[15])return -1;
    }else {
    pixels=(const GLvoid *)DGHostPointer(dg_wire_message,8,(DGHostUnpackBytes(context,dg_wire_message,2,width,height,1,format,type)));
    if(!pixels) return -1;
    }
    typedef void (*Proc)(GLenum target, GLint level, GLint xoffset, GLint yoffset, GLsizei width, GLsizei height, GLenum format, GLenum type, const GLvoid *pixels);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexSubImage2D");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    if((width>=0 && height>=0 && DGRasterPixelBits(format,type)) && !DGPrepareScopedTextureCPUWrite(context,target))return 0;
    if(!DGHostCompactUnpackBegin(context,dg_wire_message,&compact_scope))return 0;
    struct DGAutomaticMipmapScope automatic=DGBeginAutomaticMipmap(target,level,context->profile==kCGLOGLPVersion_Legacy,context->inside_begin,context->list_mode,&context->error,0,DGNonzeroMipmapBasePossible(context));
    proc(target,level,xoffset,yoffset,width,height,format,type,pixels);
    DGHostCompactUnpackEnd(context,&compact_scope);
    DGEndAutomaticMipmap(&automatic,NULL,&context->error);
    DGMarkIOSurfaceTextureWrite(context,target);
    return 0;
}
case 308: {
    GLdouble x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLdouble y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    GLdouble z=0;memcpy(&z,&dg_wire_message->args[2],sizeof(z));
    typedef void (*Proc)(GLdouble x, GLdouble y, GLdouble z);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTranslated");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y,z);
    return 0;
}
case 309: {
    GLfloat x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLfloat y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    GLfloat z=0;memcpy(&z,&dg_wire_message->args[2],sizeof(z));
    typedef void (*Proc)(GLfloat x, GLfloat y, GLfloat z);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTranslatef");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y,z);
    return 0;
}
case 310: {
    GLdouble x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLdouble y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    typedef void (*Proc)(GLdouble x, GLdouble y);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertex2d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y);
    return 0;
}
case 311: {
    const GLdouble * v=NULL;
    v=(const GLdouble *)DGHostPointer(dg_wire_message,0,(2*sizeof(GLdouble)));
    if(!v) return -1;
    typedef void (*Proc)(const GLdouble *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertex2dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 312: {
    GLfloat x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLfloat y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    typedef void (*Proc)(GLfloat x, GLfloat y);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertex2f");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    if(dg_diagnostics && context->immediate_vertex_budget) { --context->immediate_vertex_budget;fprintf(stderr,"direct immediate context=%p program=%d vertex=%g,%g\n",(void *)context,context->traced_immediate_program,(double)x,(double)y); }
    proc(x,y);
    return 0;
}
case 313: {
    const GLfloat * v=NULL;
    v=(const GLfloat *)DGHostPointer(dg_wire_message,0,(2*sizeof(GLfloat)));
    if(!v) return -1;
    typedef void (*Proc)(const GLfloat *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertex2fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 314: {
    GLint x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLint y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    typedef void (*Proc)(GLint x, GLint y);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertex2i");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y);
    return 0;
}
case 315: {
    const GLint * v=NULL;
    v=(const GLint *)DGHostPointer(dg_wire_message,0,(2*sizeof(GLint)));
    if(!v) return -1;
    typedef void (*Proc)(const GLint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertex2iv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 316: {
    GLshort x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLshort y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    typedef void (*Proc)(GLshort x, GLshort y);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertex2s");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y);
    return 0;
}
case 317: {
    const GLshort * v=NULL;
    v=(const GLshort *)DGHostPointer(dg_wire_message,0,(2*sizeof(GLshort)));
    if(!v) return -1;
    typedef void (*Proc)(const GLshort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertex2sv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 318: {
    GLdouble x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLdouble y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    GLdouble z=0;memcpy(&z,&dg_wire_message->args[2],sizeof(z));
    typedef void (*Proc)(GLdouble x, GLdouble y, GLdouble z);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertex3d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y,z);
    return 0;
}
case 319: {
    const GLdouble * v=NULL;
    v=(const GLdouble *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLdouble)));
    if(!v) return -1;
    typedef void (*Proc)(const GLdouble *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertex3dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 320: {
    GLfloat x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLfloat y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    GLfloat z=0;memcpy(&z,&dg_wire_message->args[2],sizeof(z));
    typedef void (*Proc)(GLfloat x, GLfloat y, GLfloat z);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertex3f");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y,z);
    return 0;
}
case 321: {
    const GLfloat * v=NULL;
    v=(const GLfloat *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLfloat)));
    if(!v) return -1;
    typedef void (*Proc)(const GLfloat *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertex3fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 322: {
    GLint x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLint y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    GLint z=0;memcpy(&z,&dg_wire_message->args[2],sizeof(z));
    typedef void (*Proc)(GLint x, GLint y, GLint z);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertex3i");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y,z);
    return 0;
}
case 323: {
    const GLint * v=NULL;
    v=(const GLint *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLint)));
    if(!v) return -1;
    typedef void (*Proc)(const GLint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertex3iv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 324: {
    GLshort x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLshort y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    GLshort z=0;memcpy(&z,&dg_wire_message->args[2],sizeof(z));
    typedef void (*Proc)(GLshort x, GLshort y, GLshort z);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertex3s");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y,z);
    return 0;
}
case 325: {
    const GLshort * v=NULL;
    v=(const GLshort *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLshort)));
    if(!v) return -1;
    typedef void (*Proc)(const GLshort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertex3sv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 326: {
    GLdouble x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLdouble y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    GLdouble z=0;memcpy(&z,&dg_wire_message->args[2],sizeof(z));
    GLdouble w=0;memcpy(&w,&dg_wire_message->args[3],sizeof(w));
    typedef void (*Proc)(GLdouble x, GLdouble y, GLdouble z, GLdouble w);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertex4d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y,z,w);
    return 0;
}
case 327: {
    const GLdouble * v=NULL;
    v=(const GLdouble *)DGHostPointer(dg_wire_message,0,(4*sizeof(GLdouble)));
    if(!v) return -1;
    typedef void (*Proc)(const GLdouble *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertex4dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 328: {
    GLfloat x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLfloat y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    GLfloat z=0;memcpy(&z,&dg_wire_message->args[2],sizeof(z));
    GLfloat w=0;memcpy(&w,&dg_wire_message->args[3],sizeof(w));
    typedef void (*Proc)(GLfloat x, GLfloat y, GLfloat z, GLfloat w);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertex4f");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y,z,w);
    return 0;
}
case 329: {
    const GLfloat * v=NULL;
    v=(const GLfloat *)DGHostPointer(dg_wire_message,0,(4*sizeof(GLfloat)));
    if(!v) return -1;
    typedef void (*Proc)(const GLfloat *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertex4fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 330: {
    GLint x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLint y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    GLint z=0;memcpy(&z,&dg_wire_message->args[2],sizeof(z));
    GLint w=0;memcpy(&w,&dg_wire_message->args[3],sizeof(w));
    typedef void (*Proc)(GLint x, GLint y, GLint z, GLint w);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertex4i");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y,z,w);
    return 0;
}
case 331: {
    const GLint * v=NULL;
    v=(const GLint *)DGHostPointer(dg_wire_message,0,(4*sizeof(GLint)));
    if(!v) return -1;
    typedef void (*Proc)(const GLint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertex4iv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 332: {
    GLshort x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLshort y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    GLshort z=0;memcpy(&z,&dg_wire_message->args[2],sizeof(z));
    GLshort w=0;memcpy(&w,&dg_wire_message->args[3],sizeof(w));
    typedef void (*Proc)(GLshort x, GLshort y, GLshort z, GLshort w);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertex4s");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y,z,w);
    return 0;
}
case 333: {
    const GLshort * v=NULL;
    v=(const GLshort *)DGHostPointer(dg_wire_message,0,(4*sizeof(GLshort)));
    if(!v) return -1;
    typedef void (*Proc)(const GLshort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertex4sv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 335: {
    GLint x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLint y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[2],sizeof(width));
    GLsizei height=0;memcpy(&height,&dg_wire_message->args[3],sizeof(height));
    typedef void (*Proc)(GLint x, GLint y, GLsizei width, GLsizei height);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glViewport");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y,width,height);
    return 0;
}
case 336: {
    GLenum sfactorRGB=0;memcpy(&sfactorRGB,&dg_wire_message->args[0],sizeof(sfactorRGB));
    GLenum dfactorRGB=0;memcpy(&dfactorRGB,&dg_wire_message->args[1],sizeof(dfactorRGB));
    GLenum sfactorAlpha=0;memcpy(&sfactorAlpha,&dg_wire_message->args[2],sizeof(sfactorAlpha));
    GLenum dfactorAlpha=0;memcpy(&dfactorAlpha,&dg_wire_message->args[3],sizeof(dfactorAlpha));
    typedef void (*Proc)(GLenum sfactorRGB, GLenum dfactorRGB, GLenum sfactorAlpha, GLenum dfactorAlpha);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glBlendFuncSeparate");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(sfactorRGB,dfactorRGB,sfactorAlpha,dfactorAlpha);
    return 0;
}
case 337: {
    GLclampf red=0;memcpy(&red,&dg_wire_message->args[0],sizeof(red));
    GLclampf green=0;memcpy(&green,&dg_wire_message->args[1],sizeof(green));
    GLclampf blue=0;memcpy(&blue,&dg_wire_message->args[2],sizeof(blue));
    GLclampf alpha=0;memcpy(&alpha,&dg_wire_message->args[3],sizeof(alpha));
    typedef void (*Proc)(GLclampf red, GLclampf green, GLclampf blue, GLclampf alpha);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glBlendColor");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(red,green,blue,alpha);
    return 0;
}
case 338: {
    GLenum mode=0;memcpy(&mode,&dg_wire_message->args[0],sizeof(mode));
    typedef void (*Proc)(GLenum mode);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glBlendEquation");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(mode);
    return 0;
}
case 339: {
    GLint first=0;memcpy(&first,&dg_wire_message->args[0],sizeof(first));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    typedef void (*Proc)(GLint first, GLsizei count);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glLockArraysEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(first,count);
    return 0;
}
case 340: {
    typedef void (*Proc)(void);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUnlockArraysEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc();
    return 0;
}
case 341: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    typedef void (*Proc)(GLenum target);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glClientActiveTexture");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target);
    return 0;
}
case 342: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    typedef void (*Proc)(GLenum target);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glActiveTexture");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target);
    return 0;
}
case 343: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLdouble s=0;memcpy(&s,&dg_wire_message->args[1],sizeof(s));
    typedef void (*Proc)(GLenum target, GLdouble s);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord1d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,s);
    return 0;
}
case 344: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    const GLdouble * v=NULL;
    v=(const GLdouble *)DGHostPointer(dg_wire_message,1,(1*sizeof(GLdouble)));
    if(!v) return -1;
    typedef void (*Proc)(GLenum target, const GLdouble *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord1dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,v);
    return 0;
}
case 345: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLfloat s=0;memcpy(&s,&dg_wire_message->args[1],sizeof(s));
    typedef void (*Proc)(GLenum target, GLfloat s);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord1f");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,s);
    return 0;
}
case 346: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    const GLfloat * v=NULL;
    v=(const GLfloat *)DGHostPointer(dg_wire_message,1,(1*sizeof(GLfloat)));
    if(!v) return -1;
    typedef void (*Proc)(GLenum target, const GLfloat *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord1fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,v);
    return 0;
}
case 347: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLint s=0;memcpy(&s,&dg_wire_message->args[1],sizeof(s));
    typedef void (*Proc)(GLenum target, GLint s);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord1i");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,s);
    return 0;
}
case 348: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    const GLint * v=NULL;
    v=(const GLint *)DGHostPointer(dg_wire_message,1,(1*sizeof(GLint)));
    if(!v) return -1;
    typedef void (*Proc)(GLenum target, const GLint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord1iv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,v);
    return 0;
}
case 349: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLshort s=0;memcpy(&s,&dg_wire_message->args[1],sizeof(s));
    typedef void (*Proc)(GLenum target, GLshort s);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord1s");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,s);
    return 0;
}
case 350: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    const GLshort * v=NULL;
    v=(const GLshort *)DGHostPointer(dg_wire_message,1,(1*sizeof(GLshort)));
    if(!v) return -1;
    typedef void (*Proc)(GLenum target, const GLshort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord1sv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,v);
    return 0;
}
case 351: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLdouble s=0;memcpy(&s,&dg_wire_message->args[1],sizeof(s));
    GLdouble t=0;memcpy(&t,&dg_wire_message->args[2],sizeof(t));
    typedef void (*Proc)(GLenum target, GLdouble s, GLdouble t);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord2d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,s,t);
    return 0;
}
case 352: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    const GLdouble * v=NULL;
    v=(const GLdouble *)DGHostPointer(dg_wire_message,1,(2*sizeof(GLdouble)));
    if(!v) return -1;
    typedef void (*Proc)(GLenum target, const GLdouble *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord2dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,v);
    return 0;
}
case 353: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLfloat s=0;memcpy(&s,&dg_wire_message->args[1],sizeof(s));
    GLfloat t=0;memcpy(&t,&dg_wire_message->args[2],sizeof(t));
    typedef void (*Proc)(GLenum target, GLfloat s, GLfloat t);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord2f");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,s,t);
    return 0;
}
case 354: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    const GLfloat * v=NULL;
    v=(const GLfloat *)DGHostPointer(dg_wire_message,1,(2*sizeof(GLfloat)));
    if(!v) return -1;
    typedef void (*Proc)(GLenum target, const GLfloat *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord2fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,v);
    return 0;
}
case 355: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLint s=0;memcpy(&s,&dg_wire_message->args[1],sizeof(s));
    GLint t=0;memcpy(&t,&dg_wire_message->args[2],sizeof(t));
    typedef void (*Proc)(GLenum target, GLint s, GLint t);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord2i");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,s,t);
    return 0;
}
case 356: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    const GLint * v=NULL;
    v=(const GLint *)DGHostPointer(dg_wire_message,1,(2*sizeof(GLint)));
    if(!v) return -1;
    typedef void (*Proc)(GLenum target, const GLint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord2iv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,v);
    return 0;
}
case 357: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLshort s=0;memcpy(&s,&dg_wire_message->args[1],sizeof(s));
    GLshort t=0;memcpy(&t,&dg_wire_message->args[2],sizeof(t));
    typedef void (*Proc)(GLenum target, GLshort s, GLshort t);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord2s");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,s,t);
    return 0;
}
case 358: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    const GLshort * v=NULL;
    v=(const GLshort *)DGHostPointer(dg_wire_message,1,(2*sizeof(GLshort)));
    if(!v) return -1;
    typedef void (*Proc)(GLenum target, const GLshort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord2sv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,v);
    return 0;
}
case 359: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLdouble s=0;memcpy(&s,&dg_wire_message->args[1],sizeof(s));
    GLdouble t=0;memcpy(&t,&dg_wire_message->args[2],sizeof(t));
    GLdouble r=0;memcpy(&r,&dg_wire_message->args[3],sizeof(r));
    typedef void (*Proc)(GLenum target, GLdouble s, GLdouble t, GLdouble r);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord3d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,s,t,r);
    return 0;
}
case 360: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    const GLdouble * v=NULL;
    v=(const GLdouble *)DGHostPointer(dg_wire_message,1,(3*sizeof(GLdouble)));
    if(!v) return -1;
    typedef void (*Proc)(GLenum target, const GLdouble *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord3dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,v);
    return 0;
}
case 361: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLfloat s=0;memcpy(&s,&dg_wire_message->args[1],sizeof(s));
    GLfloat t=0;memcpy(&t,&dg_wire_message->args[2],sizeof(t));
    GLfloat r=0;memcpy(&r,&dg_wire_message->args[3],sizeof(r));
    typedef void (*Proc)(GLenum target, GLfloat s, GLfloat t, GLfloat r);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord3f");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,s,t,r);
    return 0;
}
case 362: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    const GLfloat * v=NULL;
    v=(const GLfloat *)DGHostPointer(dg_wire_message,1,(3*sizeof(GLfloat)));
    if(!v) return -1;
    typedef void (*Proc)(GLenum target, const GLfloat *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord3fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,v);
    return 0;
}
case 363: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLint s=0;memcpy(&s,&dg_wire_message->args[1],sizeof(s));
    GLint t=0;memcpy(&t,&dg_wire_message->args[2],sizeof(t));
    GLint r=0;memcpy(&r,&dg_wire_message->args[3],sizeof(r));
    typedef void (*Proc)(GLenum target, GLint s, GLint t, GLint r);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord3i");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,s,t,r);
    return 0;
}
case 364: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    const GLint * v=NULL;
    v=(const GLint *)DGHostPointer(dg_wire_message,1,(3*sizeof(GLint)));
    if(!v) return -1;
    typedef void (*Proc)(GLenum target, const GLint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord3iv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,v);
    return 0;
}
case 365: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLshort s=0;memcpy(&s,&dg_wire_message->args[1],sizeof(s));
    GLshort t=0;memcpy(&t,&dg_wire_message->args[2],sizeof(t));
    GLshort r=0;memcpy(&r,&dg_wire_message->args[3],sizeof(r));
    typedef void (*Proc)(GLenum target, GLshort s, GLshort t, GLshort r);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord3s");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,s,t,r);
    return 0;
}
case 366: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    const GLshort * v=NULL;
    v=(const GLshort *)DGHostPointer(dg_wire_message,1,(3*sizeof(GLshort)));
    if(!v) return -1;
    typedef void (*Proc)(GLenum target, const GLshort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord3sv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,v);
    return 0;
}
case 367: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLdouble s=0;memcpy(&s,&dg_wire_message->args[1],sizeof(s));
    GLdouble t=0;memcpy(&t,&dg_wire_message->args[2],sizeof(t));
    GLdouble r=0;memcpy(&r,&dg_wire_message->args[3],sizeof(r));
    GLdouble q=0;memcpy(&q,&dg_wire_message->args[4],sizeof(q));
    typedef void (*Proc)(GLenum target, GLdouble s, GLdouble t, GLdouble r, GLdouble q);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord4d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,s,t,r,q);
    return 0;
}
case 368: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    const GLdouble * v=NULL;
    v=(const GLdouble *)DGHostPointer(dg_wire_message,1,(4*sizeof(GLdouble)));
    if(!v) return -1;
    typedef void (*Proc)(GLenum target, const GLdouble *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord4dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,v);
    return 0;
}
case 369: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLfloat s=0;memcpy(&s,&dg_wire_message->args[1],sizeof(s));
    GLfloat t=0;memcpy(&t,&dg_wire_message->args[2],sizeof(t));
    GLfloat r=0;memcpy(&r,&dg_wire_message->args[3],sizeof(r));
    GLfloat q=0;memcpy(&q,&dg_wire_message->args[4],sizeof(q));
    typedef void (*Proc)(GLenum target, GLfloat s, GLfloat t, GLfloat r, GLfloat q);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord4f");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,s,t,r,q);
    return 0;
}
case 370: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    const GLfloat * v=NULL;
    v=(const GLfloat *)DGHostPointer(dg_wire_message,1,(4*sizeof(GLfloat)));
    if(!v) return -1;
    typedef void (*Proc)(GLenum target, const GLfloat *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord4fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,v);
    return 0;
}
case 371: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLint s=0;memcpy(&s,&dg_wire_message->args[1],sizeof(s));
    GLint t=0;memcpy(&t,&dg_wire_message->args[2],sizeof(t));
    GLint r=0;memcpy(&r,&dg_wire_message->args[3],sizeof(r));
    GLint q=0;memcpy(&q,&dg_wire_message->args[4],sizeof(q));
    typedef void (*Proc)(GLenum target, GLint s, GLint t, GLint r, GLint q);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord4i");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,s,t,r,q);
    return 0;
}
case 372: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    const GLint * v=NULL;
    v=(const GLint *)DGHostPointer(dg_wire_message,1,(4*sizeof(GLint)));
    if(!v) return -1;
    typedef void (*Proc)(GLenum target, const GLint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord4iv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,v);
    return 0;
}
case 373: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLshort s=0;memcpy(&s,&dg_wire_message->args[1],sizeof(s));
    GLshort t=0;memcpy(&t,&dg_wire_message->args[2],sizeof(t));
    GLshort r=0;memcpy(&r,&dg_wire_message->args[3],sizeof(r));
    GLshort q=0;memcpy(&q,&dg_wire_message->args[4],sizeof(q));
    typedef void (*Proc)(GLenum target, GLshort s, GLshort t, GLshort r, GLshort q);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord4s");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,s,t,r,q);
    return 0;
}
case 374: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    const GLshort * v=NULL;
    v=(const GLshort *)DGHostPointer(dg_wire_message,1,(4*sizeof(GLshort)));
    if(!v) return -1;
    typedef void (*Proc)(GLenum target, const GLshort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultiTexCoord4sv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,v);
    return 0;
}
case 375: {
    const GLdouble * m=NULL;
    m=(const GLdouble *)DGHostPointer(dg_wire_message,0,(16*sizeof(GLdouble)));
    if(!m) return -1;
    typedef void (*Proc)(const GLdouble *m);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glLoadTransposeMatrixd");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(m);
    return 0;
}
case 376: {
    const GLfloat * m=NULL;
    m=(const GLfloat *)DGHostPointer(dg_wire_message,0,(16*sizeof(GLfloat)));
    if(!m) return -1;
    typedef void (*Proc)(const GLfloat *m);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glLoadTransposeMatrixf");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(m);
    return 0;
}
case 377: {
    const GLdouble * m=NULL;
    m=(const GLdouble *)DGHostPointer(dg_wire_message,0,(16*sizeof(GLdouble)));
    if(!m) return -1;
    typedef void (*Proc)(const GLdouble *m);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultTransposeMatrixd");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(m);
    return 0;
}
case 378: {
    const GLfloat * m=NULL;
    m=(const GLfloat *)DGHostPointer(dg_wire_message,0,(16*sizeof(GLfloat)));
    if(!m) return -1;
    typedef void (*Proc)(const GLfloat *m);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMultTransposeMatrixf");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(m);
    return 0;
}
case 379: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLint level=0;memcpy(&level,&dg_wire_message->args[1],sizeof(level));
    GLenum internalformat=0;memcpy(&internalformat,&dg_wire_message->args[2],sizeof(internalformat));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[3],sizeof(width));
    GLsizei height=0;memcpy(&height,&dg_wire_message->args[4],sizeof(height));
    GLsizei depth=0;memcpy(&depth,&dg_wire_message->args[5],sizeof(depth));
    GLint border=0;memcpy(&border,&dg_wire_message->args[6],sizeof(border));
    GLsizei imageSize=0;memcpy(&imageSize,&dg_wire_message->args[7],sizeof(imageSize));
    const GLvoid * data=NULL;
    int compressed_input=DGHostCompressedInput(context,dg_wire_message,target,imageSize,8,&data);
    if(compressed_input<=0)return compressed_input;
    typedef void (*Proc)(GLenum target, GLint level, GLenum internalformat, GLsizei width, GLsizei height, GLsizei depth, GLint border, GLsizei imageSize, const GLvoid *data);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glCompressedTexImage3D");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,level,internalformat,width,height,depth,border,imageSize,data);
    return 0;
}
case 380: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLint level=0;memcpy(&level,&dg_wire_message->args[1],sizeof(level));
    GLenum internalformat=0;memcpy(&internalformat,&dg_wire_message->args[2],sizeof(internalformat));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[3],sizeof(width));
    GLsizei height=0;memcpy(&height,&dg_wire_message->args[4],sizeof(height));
    GLint border=0;memcpy(&border,&dg_wire_message->args[5],sizeof(border));
    GLsizei imageSize=0;memcpy(&imageSize,&dg_wire_message->args[6],sizeof(imageSize));
    const GLvoid * data=NULL;
    int compressed_input=DGHostCompressedInput(context,dg_wire_message,target,imageSize,7,&data);
    if(compressed_input<=0)return compressed_input;
    typedef void (*Proc)(GLenum target, GLint level, GLenum internalformat, GLsizei width, GLsizei height, GLint border, GLsizei imageSize, const GLvoid *data);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glCompressedTexImage2D");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLuint redefining_alias=DGBeginAliasRedefinition(context,target,level);
    struct DGAutomaticMipmapScope automatic=DGBeginAutomaticMipmap(target,level,context->profile==kCGLOGLPVersion_Legacy,context->inside_begin,context->list_mode,&context->error,0,DGNonzeroMipmapBasePossible(context));
    proc(target,level,internalformat,width,height,border,imageSize,data);
    DGEndAliasRedefinition(context,redefining_alias);
    DGEndAutomaticMipmap(&automatic,NULL,&context->error);
    return 0;
}
case 381: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLint level=0;memcpy(&level,&dg_wire_message->args[1],sizeof(level));
    GLenum internalformat=0;memcpy(&internalformat,&dg_wire_message->args[2],sizeof(internalformat));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[3],sizeof(width));
    GLint border=0;memcpy(&border,&dg_wire_message->args[4],sizeof(border));
    GLsizei imageSize=0;memcpy(&imageSize,&dg_wire_message->args[5],sizeof(imageSize));
    const GLvoid * data=NULL;
    int compressed_input=DGHostCompressedInput(context,dg_wire_message,target,imageSize,6,&data);
    if(compressed_input<=0)return compressed_input;
    typedef void (*Proc)(GLenum target, GLint level, GLenum internalformat, GLsizei width, GLint border, GLsizei imageSize, const GLvoid *data);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glCompressedTexImage1D");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,level,internalformat,width,border,imageSize,data);
    return 0;
}
case 382: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLint level=0;memcpy(&level,&dg_wire_message->args[1],sizeof(level));
    GLint xoffset=0;memcpy(&xoffset,&dg_wire_message->args[2],sizeof(xoffset));
    GLint yoffset=0;memcpy(&yoffset,&dg_wire_message->args[3],sizeof(yoffset));
    GLint zoffset=0;memcpy(&zoffset,&dg_wire_message->args[4],sizeof(zoffset));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[5],sizeof(width));
    GLsizei height=0;memcpy(&height,&dg_wire_message->args[6],sizeof(height));
    GLsizei depth=0;memcpy(&depth,&dg_wire_message->args[7],sizeof(depth));
    GLenum format=0;memcpy(&format,&dg_wire_message->args[8],sizeof(format));
    GLsizei imageSize=0;memcpy(&imageSize,&dg_wire_message->args[9],sizeof(imageSize));
    const GLvoid * data=NULL;
    int compressed_input=DGHostCompressedInput(context,dg_wire_message,target,imageSize,10,&data);
    if(compressed_input<=0)return compressed_input;
    typedef void (*Proc)(GLenum target, GLint level, GLint xoffset, GLint yoffset, GLint zoffset, GLsizei width, GLsizei height, GLsizei depth, GLenum format, GLsizei imageSize, const GLvoid *data);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glCompressedTexSubImage3D");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,level,xoffset,yoffset,zoffset,width,height,depth,format,imageSize,data);
    return 0;
}
case 383: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLint level=0;memcpy(&level,&dg_wire_message->args[1],sizeof(level));
    GLint xoffset=0;memcpy(&xoffset,&dg_wire_message->args[2],sizeof(xoffset));
    GLint yoffset=0;memcpy(&yoffset,&dg_wire_message->args[3],sizeof(yoffset));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[4],sizeof(width));
    GLsizei height=0;memcpy(&height,&dg_wire_message->args[5],sizeof(height));
    GLenum format=0;memcpy(&format,&dg_wire_message->args[6],sizeof(format));
    GLsizei imageSize=0;memcpy(&imageSize,&dg_wire_message->args[7],sizeof(imageSize));
    const GLvoid * data=NULL;
    int compressed_input=DGHostCompressedInput(context,dg_wire_message,target,imageSize,8,&data);
    if(compressed_input<=0)return compressed_input;
    typedef void (*Proc)(GLenum target, GLint level, GLint xoffset, GLint yoffset, GLsizei width, GLsizei height, GLenum format, GLsizei imageSize, const GLvoid *data);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glCompressedTexSubImage2D");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    if(!DGPrepareScopedTextureCPUWrite(context,target))return 0;
    struct DGAutomaticMipmapScope automatic=DGBeginAutomaticMipmap(target,level,context->profile==kCGLOGLPVersion_Legacy,context->inside_begin,context->list_mode,&context->error,0,DGNonzeroMipmapBasePossible(context));
    proc(target,level,xoffset,yoffset,width,height,format,imageSize,data);
    DGEndAutomaticMipmap(&automatic,NULL,&context->error);
    DGMarkIOSurfaceTextureWrite(context,target);
    return 0;
}
case 384: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLint level=0;memcpy(&level,&dg_wire_message->args[1],sizeof(level));
    GLint xoffset=0;memcpy(&xoffset,&dg_wire_message->args[2],sizeof(xoffset));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[3],sizeof(width));
    GLenum format=0;memcpy(&format,&dg_wire_message->args[4],sizeof(format));
    GLsizei imageSize=0;memcpy(&imageSize,&dg_wire_message->args[5],sizeof(imageSize));
    const GLvoid * data=NULL;
    int compressed_input=DGHostCompressedInput(context,dg_wire_message,target,imageSize,6,&data);
    if(compressed_input<=0)return compressed_input;
    typedef void (*Proc)(GLenum target, GLint level, GLint xoffset, GLsizei width, GLenum format, GLsizei imageSize, const GLvoid *data);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glCompressedTexSubImage1D");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,level,xoffset,width,format,imageSize,data);
    return 0;
}
case 386: {
    GLbyte red=0;memcpy(&red,&dg_wire_message->args[0],sizeof(red));
    GLbyte green=0;memcpy(&green,&dg_wire_message->args[1],sizeof(green));
    GLbyte blue=0;memcpy(&blue,&dg_wire_message->args[2],sizeof(blue));
    typedef void (*Proc)(GLbyte red, GLbyte green, GLbyte blue);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glSecondaryColor3b");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(red,green,blue);
    return 0;
}
case 387: {
    const GLbyte * v=NULL;
    v=(const GLbyte *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLbyte)));
    if(!v) return -1;
    typedef void (*Proc)(const GLbyte *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glSecondaryColor3bv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 388: {
    GLdouble red=0;memcpy(&red,&dg_wire_message->args[0],sizeof(red));
    GLdouble green=0;memcpy(&green,&dg_wire_message->args[1],sizeof(green));
    GLdouble blue=0;memcpy(&blue,&dg_wire_message->args[2],sizeof(blue));
    typedef void (*Proc)(GLdouble red, GLdouble green, GLdouble blue);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glSecondaryColor3d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(red,green,blue);
    return 0;
}
case 389: {
    const GLdouble * v=NULL;
    v=(const GLdouble *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLdouble)));
    if(!v) return -1;
    typedef void (*Proc)(const GLdouble *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glSecondaryColor3dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 390: {
    GLfloat red=0;memcpy(&red,&dg_wire_message->args[0],sizeof(red));
    GLfloat green=0;memcpy(&green,&dg_wire_message->args[1],sizeof(green));
    GLfloat blue=0;memcpy(&blue,&dg_wire_message->args[2],sizeof(blue));
    typedef void (*Proc)(GLfloat red, GLfloat green, GLfloat blue);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glSecondaryColor3f");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(red,green,blue);
    return 0;
}
case 391: {
    const GLfloat * v=NULL;
    v=(const GLfloat *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLfloat)));
    if(!v) return -1;
    typedef void (*Proc)(const GLfloat *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glSecondaryColor3fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 392: {
    GLint red=0;memcpy(&red,&dg_wire_message->args[0],sizeof(red));
    GLint green=0;memcpy(&green,&dg_wire_message->args[1],sizeof(green));
    GLint blue=0;memcpy(&blue,&dg_wire_message->args[2],sizeof(blue));
    typedef void (*Proc)(GLint red, GLint green, GLint blue);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glSecondaryColor3i");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(red,green,blue);
    return 0;
}
case 393: {
    const GLint * v=NULL;
    v=(const GLint *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLint)));
    if(!v) return -1;
    typedef void (*Proc)(const GLint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glSecondaryColor3iv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 394: {
    GLshort red=0;memcpy(&red,&dg_wire_message->args[0],sizeof(red));
    GLshort green=0;memcpy(&green,&dg_wire_message->args[1],sizeof(green));
    GLshort blue=0;memcpy(&blue,&dg_wire_message->args[2],sizeof(blue));
    typedef void (*Proc)(GLshort red, GLshort green, GLshort blue);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glSecondaryColor3s");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(red,green,blue);
    return 0;
}
case 395: {
    const GLshort * v=NULL;
    v=(const GLshort *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLshort)));
    if(!v) return -1;
    typedef void (*Proc)(const GLshort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glSecondaryColor3sv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 396: {
    GLubyte red=0;memcpy(&red,&dg_wire_message->args[0],sizeof(red));
    GLubyte green=0;memcpy(&green,&dg_wire_message->args[1],sizeof(green));
    GLubyte blue=0;memcpy(&blue,&dg_wire_message->args[2],sizeof(blue));
    typedef void (*Proc)(GLubyte red, GLubyte green, GLubyte blue);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glSecondaryColor3ub");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(red,green,blue);
    return 0;
}
case 397: {
    const GLubyte * v=NULL;
    v=(const GLubyte *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLubyte)));
    if(!v) return -1;
    typedef void (*Proc)(const GLubyte *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glSecondaryColor3ubv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 398: {
    GLuint red=0;memcpy(&red,&dg_wire_message->args[0],sizeof(red));
    GLuint green=0;memcpy(&green,&dg_wire_message->args[1],sizeof(green));
    GLuint blue=0;memcpy(&blue,&dg_wire_message->args[2],sizeof(blue));
    typedef void (*Proc)(GLuint red, GLuint green, GLuint blue);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glSecondaryColor3ui");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(red,green,blue);
    return 0;
}
case 399: {
    const GLuint * v=NULL;
    v=(const GLuint *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLuint)));
    if(!v) return -1;
    typedef void (*Proc)(const GLuint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glSecondaryColor3uiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 400: {
    GLushort red=0;memcpy(&red,&dg_wire_message->args[0],sizeof(red));
    GLushort green=0;memcpy(&green,&dg_wire_message->args[1],sizeof(green));
    GLushort blue=0;memcpy(&blue,&dg_wire_message->args[2],sizeof(blue));
    typedef void (*Proc)(GLushort red, GLushort green, GLushort blue);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glSecondaryColor3us");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(red,green,blue);
    return 0;
}
case 401: {
    const GLushort * v=NULL;
    v=(const GLushort *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLushort)));
    if(!v) return -1;
    typedef void (*Proc)(const GLushort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glSecondaryColor3usv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 406: {
    void *pixels[2]={0};struct DGImagingPixelScope scope={0};
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum internalformat=0;memcpy(&internalformat,&dg_wire_message->args[1],sizeof(internalformat));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[2],sizeof(width));
    GLenum format=0;memcpy(&format,&dg_wire_message->args[3],sizeof(format));
    GLenum type=0;memcpy(&type,&dg_wire_message->args[4],sizeof(type));
    typedef void (*Proc)(GLenum target, GLenum internalformat, GLsizei width, GLenum format, GLenum type, const GLvoid *table);
    static Proc proc;if(!proc)proc=(Proc)dlsym(RTLD_DEFAULT,"glColorTable");
    if(!proc){if(!context->error)context->error=GL_INVALID_OPERATION;return 0;}
    int admitted=DGHostImagingTransfer(context,dg_wire_message,DG_IMAGING_TABLE,target,width,1,0,format,type,0,(const int[2]){5,-1},pixels,&scope);
    if(admitted<=0)return admitted;
    proc(target,internalformat,width,format,type,pixels[0]);
    DGHostImagingEnd(context,&scope);
    return 0;
}
case 407: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    const GLfloat * params=NULL;
    if(context->inside_begin || context->profile!=kCGLOGLPVersion_Legacy) { if(!context->error)context->error=GL_INVALID_OPERATION;return 0; }
    if(!DGImagingParameterCount(DG_COLOR_TABLE_SET,pname)) { if(!context->error)context->error=GL_INVALID_ENUM;return 0; }
    params=(const GLfloat *)DGHostPointer(dg_wire_message,2,(DGImagingParameterCount(DG_COLOR_TABLE_SET,pname)*sizeof(GLfloat)));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLenum pname, const GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColorTableParameterfv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,pname,params);
    return 0;
}
case 408: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    const GLint * params=NULL;
    if(context->inside_begin || context->profile!=kCGLOGLPVersion_Legacy) { if(!context->error)context->error=GL_INVALID_OPERATION;return 0; }
    if(!DGImagingParameterCount(DG_COLOR_TABLE_SET,pname)) { if(!context->error)context->error=GL_INVALID_ENUM;return 0; }
    params=(const GLint *)DGHostPointer(dg_wire_message,2,(DGImagingParameterCount(DG_COLOR_TABLE_SET,pname)*sizeof(GLint)));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLenum pname, const GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColorTableParameteriv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,pname,params);
    return 0;
}
case 409: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum internalformat=0;memcpy(&internalformat,&dg_wire_message->args[1],sizeof(internalformat));
    GLint x=0;memcpy(&x,&dg_wire_message->args[2],sizeof(x));
    GLint y=0;memcpy(&y,&dg_wire_message->args[3],sizeof(y));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[4],sizeof(width));
    typedef void (*Proc)(GLenum target, GLenum internalformat, GLint x, GLint y, GLsizei width);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glCopyColorTable");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,internalformat,x,y,width);
    return 0;
}
case 410: {
    void *pixels[2]={0};struct DGImagingPixelScope scope={0};
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum format=0;memcpy(&format,&dg_wire_message->args[1],sizeof(format));
    GLenum type=0;memcpy(&type,&dg_wire_message->args[2],sizeof(type));
    typedef void (*Proc)(GLenum target, GLenum format, GLenum type, GLvoid *table);
    static Proc proc;if(!proc)proc=(Proc)dlsym(RTLD_DEFAULT,"glGetColorTable");
    if(!proc){if(!context->error)context->error=GL_INVALID_OPERATION;return 0;}
    int admitted=DGHostImagingTransfer(context,dg_wire_message,DG_IMAGING_GET_TABLE,target,0,1,0,format,type,1,(const int[2]){3,-1},pixels,&scope);
    if(admitted<=0)return admitted;
    proc(target,format,type,pixels[0]);
    DGHostImagingEnd(context,&scope);
    if(dg_wire_message->args[15]==1)DGPBOWritten(context);
    return 0;
}
case 411: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLfloat * params=NULL;
    if(context->inside_begin || context->profile!=kCGLOGLPVersion_Legacy) { if(!context->error)context->error=GL_INVALID_OPERATION;return 0; }
    if(!DGImagingParameterCount(DG_COLOR_TABLE_GET,pname)) { if(!context->error)context->error=GL_INVALID_ENUM;return 0; }
    params=(GLfloat *)DGHostPointer(dg_wire_message,2,((DGImagingParameterCount(DG_COLOR_TABLE_GET,pname)*sizeof(GLfloat)) ? (DGImagingParameterCount(DG_COLOR_TABLE_GET,pname)*sizeof(GLfloat)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLenum pname, GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetColorTableParameterfv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,pname,params);
    return 0;
}
case 412: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint * params=NULL;
    if(context->inside_begin || context->profile!=kCGLOGLPVersion_Legacy) { if(!context->error)context->error=GL_INVALID_OPERATION;return 0; }
    if(!DGImagingParameterCount(DG_COLOR_TABLE_GET,pname)) { if(!context->error)context->error=GL_INVALID_ENUM;return 0; }
    params=(GLint *)DGHostPointer(dg_wire_message,2,((DGImagingParameterCount(DG_COLOR_TABLE_GET,pname)*sizeof(GLint)) ? (DGImagingParameterCount(DG_COLOR_TABLE_GET,pname)*sizeof(GLint)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLenum pname, GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetColorTableParameteriv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,pname,params);
    return 0;
}
case 413: {
    void *pixels[2]={0};struct DGImagingPixelScope scope={0};
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLsizei start=0;memcpy(&start,&dg_wire_message->args[1],sizeof(start));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    GLenum format=0;memcpy(&format,&dg_wire_message->args[3],sizeof(format));
    GLenum type=0;memcpy(&type,&dg_wire_message->args[4],sizeof(type));
    typedef void (*Proc)(GLenum target, GLsizei start, GLsizei count, GLenum format, GLenum type, const GLvoid *data);
    static Proc proc;if(!proc)proc=(Proc)dlsym(RTLD_DEFAULT,"glColorSubTable");
    if(!proc){if(!context->error)context->error=GL_INVALID_OPERATION;return 0;}
    int admitted=DGHostImagingTransfer(context,dg_wire_message,DG_IMAGING_SUBTABLE,target,count,1,start,format,type,0,(const int[2]){5,-1},pixels,&scope);
    if(admitted<=0)return admitted;
    proc(target,start,count,format,type,pixels[0]);
    DGHostImagingEnd(context,&scope);
    return 0;
}
case 414: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLsizei start=0;memcpy(&start,&dg_wire_message->args[1],sizeof(start));
    GLint x=0;memcpy(&x,&dg_wire_message->args[2],sizeof(x));
    GLint y=0;memcpy(&y,&dg_wire_message->args[3],sizeof(y));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[4],sizeof(width));
    typedef void (*Proc)(GLenum target, GLsizei start, GLint x, GLint y, GLsizei width);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glCopyColorSubTable");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,start,x,y,width);
    return 0;
}
case 415: {
    void *pixels[2]={0};struct DGImagingPixelScope scope={0};
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum internalformat=0;memcpy(&internalformat,&dg_wire_message->args[1],sizeof(internalformat));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[2],sizeof(width));
    GLenum format=0;memcpy(&format,&dg_wire_message->args[3],sizeof(format));
    GLenum type=0;memcpy(&type,&dg_wire_message->args[4],sizeof(type));
    typedef void (*Proc)(GLenum target, GLenum internalformat, GLsizei width, GLenum format, GLenum type, const GLvoid *image);
    static Proc proc;if(!proc)proc=(Proc)dlsym(RTLD_DEFAULT,"glConvolutionFilter1D");
    if(!proc){if(!context->error)context->error=GL_INVALID_OPERATION;return 0;}
    int admitted=DGHostImagingTransfer(context,dg_wire_message,DG_IMAGING_FILTER1D,target,width,1,0,format,type,0,(const int[2]){5,-1},pixels,&scope);
    if(admitted<=0)return admitted;
    proc(target,internalformat,width,format,type,pixels[0]);
    DGHostImagingEnd(context,&scope);
    return 0;
}
case 416: {
    void *pixels[2]={0};struct DGImagingPixelScope scope={0};
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum internalformat=0;memcpy(&internalformat,&dg_wire_message->args[1],sizeof(internalformat));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[2],sizeof(width));
    GLsizei height=0;memcpy(&height,&dg_wire_message->args[3],sizeof(height));
    GLenum format=0;memcpy(&format,&dg_wire_message->args[4],sizeof(format));
    GLenum type=0;memcpy(&type,&dg_wire_message->args[5],sizeof(type));
    typedef void (*Proc)(GLenum target, GLenum internalformat, GLsizei width, GLsizei height, GLenum format, GLenum type, const GLvoid *image);
    static Proc proc;if(!proc)proc=(Proc)dlsym(RTLD_DEFAULT,"glConvolutionFilter2D");
    if(!proc){if(!context->error)context->error=GL_INVALID_OPERATION;return 0;}
    int admitted=DGHostImagingTransfer(context,dg_wire_message,DG_IMAGING_FILTER2D,target,width,height,0,format,type,0,(const int[2]){6,-1},pixels,&scope);
    if(admitted<=0)return admitted;
    proc(target,internalformat,width,height,format,type,pixels[0]);
    DGHostImagingEnd(context,&scope);
    return 0;
}
case 417: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLfloat params=0;memcpy(&params,&dg_wire_message->args[2],sizeof(params));
    typedef void (*Proc)(GLenum target, GLenum pname, GLfloat params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glConvolutionParameterf");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,pname,params);
    return 0;
}
case 418: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    const GLfloat * params=NULL;
    if(context->inside_begin || context->profile!=kCGLOGLPVersion_Legacy) { if(!context->error)context->error=GL_INVALID_OPERATION;return 0; }
    if(!DGImagingParameterCount(DG_CONVOLUTION_SET,pname)) { if(!context->error)context->error=GL_INVALID_ENUM;return 0; }
    params=(const GLfloat *)DGHostPointer(dg_wire_message,2,(DGImagingParameterCount(DG_CONVOLUTION_SET,pname)*sizeof(GLfloat)));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLenum pname, const GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glConvolutionParameterfv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,pname,params);
    return 0;
}
case 419: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint params=0;memcpy(&params,&dg_wire_message->args[2],sizeof(params));
    typedef void (*Proc)(GLenum target, GLenum pname, GLint params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glConvolutionParameteri");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,pname,params);
    return 0;
}
case 420: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    const GLint * params=NULL;
    if(context->inside_begin || context->profile!=kCGLOGLPVersion_Legacy) { if(!context->error)context->error=GL_INVALID_OPERATION;return 0; }
    if(!DGImagingParameterCount(DG_CONVOLUTION_SET,pname)) { if(!context->error)context->error=GL_INVALID_ENUM;return 0; }
    params=(const GLint *)DGHostPointer(dg_wire_message,2,(DGImagingParameterCount(DG_CONVOLUTION_SET,pname)*sizeof(GLint)));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLenum pname, const GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glConvolutionParameteriv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,pname,params);
    return 0;
}
case 421: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum internalformat=0;memcpy(&internalformat,&dg_wire_message->args[1],sizeof(internalformat));
    GLint x=0;memcpy(&x,&dg_wire_message->args[2],sizeof(x));
    GLint y=0;memcpy(&y,&dg_wire_message->args[3],sizeof(y));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[4],sizeof(width));
    typedef void (*Proc)(GLenum target, GLenum internalformat, GLint x, GLint y, GLsizei width);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glCopyConvolutionFilter1D");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,internalformat,x,y,width);
    return 0;
}
case 422: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum internalformat=0;memcpy(&internalformat,&dg_wire_message->args[1],sizeof(internalformat));
    GLint x=0;memcpy(&x,&dg_wire_message->args[2],sizeof(x));
    GLint y=0;memcpy(&y,&dg_wire_message->args[3],sizeof(y));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[4],sizeof(width));
    GLsizei height=0;memcpy(&height,&dg_wire_message->args[5],sizeof(height));
    typedef void (*Proc)(GLenum target, GLenum internalformat, GLint x, GLint y, GLsizei width, GLsizei height);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glCopyConvolutionFilter2D");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,internalformat,x,y,width,height);
    return 0;
}
case 423: {
    void *pixels[2]={0};struct DGImagingPixelScope scope={0};
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum format=0;memcpy(&format,&dg_wire_message->args[1],sizeof(format));
    GLenum type=0;memcpy(&type,&dg_wire_message->args[2],sizeof(type));
    typedef void (*Proc)(GLenum target, GLenum format, GLenum type, GLvoid *image);
    static Proc proc;if(!proc)proc=(Proc)dlsym(RTLD_DEFAULT,"glGetConvolutionFilter");
    if(!proc){if(!context->error)context->error=GL_INVALID_OPERATION;return 0;}
    int admitted=DGHostImagingTransfer(context,dg_wire_message,DG_IMAGING_GET_FILTER,target,0,1,0,format,type,1,(const int[2]){3,-1},pixels,&scope);
    if(admitted<=0)return admitted;
    proc(target,format,type,pixels[0]);
    DGHostImagingEnd(context,&scope);
    if(dg_wire_message->args[15]==1)DGPBOWritten(context);
    return 0;
}
case 424: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLfloat * params=NULL;
    if(context->inside_begin || context->profile!=kCGLOGLPVersion_Legacy) { if(!context->error)context->error=GL_INVALID_OPERATION;return 0; }
    if(!DGImagingParameterCount(DG_CONVOLUTION_GET,pname)) { if(!context->error)context->error=GL_INVALID_ENUM;return 0; }
    params=(GLfloat *)DGHostPointer(dg_wire_message,2,((DGImagingParameterCount(DG_CONVOLUTION_GET,pname)*sizeof(GLfloat)) ? (DGImagingParameterCount(DG_CONVOLUTION_GET,pname)*sizeof(GLfloat)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLenum pname, GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetConvolutionParameterfv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,pname,params);
    return 0;
}
case 425: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint * params=NULL;
    if(context->inside_begin || context->profile!=kCGLOGLPVersion_Legacy) { if(!context->error)context->error=GL_INVALID_OPERATION;return 0; }
    if(!DGImagingParameterCount(DG_CONVOLUTION_GET,pname)) { if(!context->error)context->error=GL_INVALID_ENUM;return 0; }
    params=(GLint *)DGHostPointer(dg_wire_message,2,((DGImagingParameterCount(DG_CONVOLUTION_GET,pname)*sizeof(GLint)) ? (DGImagingParameterCount(DG_CONVOLUTION_GET,pname)*sizeof(GLint)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLenum pname, GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetConvolutionParameteriv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,pname,params);
    return 0;
}
case 426: {
    void *pixels[2]={0};struct DGImagingPixelScope scope={0};
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum format=0;memcpy(&format,&dg_wire_message->args[1],sizeof(format));
    GLenum type=0;memcpy(&type,&dg_wire_message->args[2],sizeof(type));
    typedef void (*Proc)(GLenum target, GLenum format, GLenum type, GLvoid *row, GLvoid *column, GLvoid *span);
    static Proc proc;if(!proc)proc=(Proc)dlsym(RTLD_DEFAULT,"glGetSeparableFilter");
    if(!proc){if(!context->error)context->error=GL_INVALID_OPERATION;return 0;}
    int admitted=DGHostImagingTransfer(context,dg_wire_message,DG_IMAGING_GET_SEPARABLE,target,0,1,0,format,type,1,(const int[2]){3,4},pixels,&scope);
    if(admitted<=0)return admitted;
    proc(target,format,type,pixels[0],pixels[1],NULL);
    DGHostImagingEnd(context,&scope);
    if(dg_wire_message->args[15]==1)DGPBOWritten(context);
    return 0;
}
case 427: {
    void *pixels[2]={0};struct DGImagingPixelScope scope={0};
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum internalformat=0;memcpy(&internalformat,&dg_wire_message->args[1],sizeof(internalformat));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[2],sizeof(width));
    GLsizei height=0;memcpy(&height,&dg_wire_message->args[3],sizeof(height));
    GLenum format=0;memcpy(&format,&dg_wire_message->args[4],sizeof(format));
    GLenum type=0;memcpy(&type,&dg_wire_message->args[5],sizeof(type));
    typedef void (*Proc)(GLenum target, GLenum internalformat, GLsizei width, GLsizei height, GLenum format, GLenum type, const GLvoid *row, const GLvoid *column);
    static Proc proc;if(!proc)proc=(Proc)dlsym(RTLD_DEFAULT,"glSeparableFilter2D");
    if(!proc){if(!context->error)context->error=GL_INVALID_OPERATION;return 0;}
    int admitted=DGHostImagingTransfer(context,dg_wire_message,DG_IMAGING_SEPARABLE,target,width,height,0,format,type,0,(const int[2]){6,7},pixels,&scope);
    if(admitted<=0)return admitted;
    proc(target,internalformat,width,height,format,type,pixels[0],pixels[1]);
    DGHostImagingEnd(context,&scope);
    return 0;
}
case 428: {
    void *pixels[2]={0};struct DGImagingPixelScope scope={0};
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLboolean reset=0;memcpy(&reset,&dg_wire_message->args[1],sizeof(reset));
    GLenum format=0;memcpy(&format,&dg_wire_message->args[2],sizeof(format));
    GLenum type=0;memcpy(&type,&dg_wire_message->args[3],sizeof(type));
    typedef void (*Proc)(GLenum target, GLboolean reset, GLenum format, GLenum type, GLvoid *values);
    static Proc proc;if(!proc)proc=(Proc)dlsym(RTLD_DEFAULT,"glGetHistogram");
    if(!proc){if(!context->error)context->error=GL_INVALID_OPERATION;return 0;}
    int admitted=DGHostImagingTransfer(context,dg_wire_message,DG_IMAGING_GET_HISTOGRAM,target,0,1,0,format,type,1,(const int[2]){4,-1},pixels,&scope);
    if(admitted<=0)return admitted;
    proc(target,reset,format,type,pixels[0]);
    DGHostImagingEnd(context,&scope);
    if(dg_wire_message->args[15]==1)DGPBOWritten(context);
    return 0;
}
case 429: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLfloat * params=NULL;
    if(context->inside_begin || context->profile!=kCGLOGLPVersion_Legacy) { if(!context->error)context->error=GL_INVALID_OPERATION;return 0; }
    if(!DGImagingParameterCount(DG_HISTOGRAM_GET,pname)) { if(!context->error)context->error=GL_INVALID_ENUM;return 0; }
    params=(GLfloat *)DGHostPointer(dg_wire_message,2,((DGImagingParameterCount(DG_HISTOGRAM_GET,pname)*sizeof(GLfloat)) ? (DGImagingParameterCount(DG_HISTOGRAM_GET,pname)*sizeof(GLfloat)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLenum pname, GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetHistogramParameterfv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,pname,params);
    return 0;
}
case 430: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint * params=NULL;
    if(context->inside_begin || context->profile!=kCGLOGLPVersion_Legacy) { if(!context->error)context->error=GL_INVALID_OPERATION;return 0; }
    if(!DGImagingParameterCount(DG_HISTOGRAM_GET,pname)) { if(!context->error)context->error=GL_INVALID_ENUM;return 0; }
    params=(GLint *)DGHostPointer(dg_wire_message,2,((DGImagingParameterCount(DG_HISTOGRAM_GET,pname)*sizeof(GLint)) ? (DGImagingParameterCount(DG_HISTOGRAM_GET,pname)*sizeof(GLint)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLenum pname, GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetHistogramParameteriv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,pname,params);
    return 0;
}
case 431: {
    void *pixels[2]={0};struct DGImagingPixelScope scope={0};
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLboolean reset=0;memcpy(&reset,&dg_wire_message->args[1],sizeof(reset));
    GLenum format=0;memcpy(&format,&dg_wire_message->args[2],sizeof(format));
    GLenum type=0;memcpy(&type,&dg_wire_message->args[3],sizeof(type));
    typedef void (*Proc)(GLenum target, GLboolean reset, GLenum format, GLenum type, GLvoid *values);
    static Proc proc;if(!proc)proc=(Proc)dlsym(RTLD_DEFAULT,"glGetMinmax");
    if(!proc){if(!context->error)context->error=GL_INVALID_OPERATION;return 0;}
    int admitted=DGHostImagingTransfer(context,dg_wire_message,DG_IMAGING_GET_MINMAX,target,0,1,0,format,type,1,(const int[2]){4,-1},pixels,&scope);
    if(admitted<=0)return admitted;
    proc(target,reset,format,type,pixels[0]);
    DGHostImagingEnd(context,&scope);
    if(dg_wire_message->args[15]==1)DGPBOWritten(context);
    return 0;
}
case 432: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLfloat * params=NULL;
    if(context->inside_begin || context->profile!=kCGLOGLPVersion_Legacy) { if(!context->error)context->error=GL_INVALID_OPERATION;return 0; }
    if(!DGImagingParameterCount(DG_MINMAX_GET,pname)) { if(!context->error)context->error=GL_INVALID_ENUM;return 0; }
    params=(GLfloat *)DGHostPointer(dg_wire_message,2,((DGImagingParameterCount(DG_MINMAX_GET,pname)*sizeof(GLfloat)) ? (DGImagingParameterCount(DG_MINMAX_GET,pname)*sizeof(GLfloat)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLenum pname, GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetMinmaxParameterfv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,pname,params);
    return 0;
}
case 433: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint * params=NULL;
    if(context->inside_begin || context->profile!=kCGLOGLPVersion_Legacy) { if(!context->error)context->error=GL_INVALID_OPERATION;return 0; }
    if(!DGImagingParameterCount(DG_MINMAX_GET,pname)) { if(!context->error)context->error=GL_INVALID_ENUM;return 0; }
    params=(GLint *)DGHostPointer(dg_wire_message,2,((DGImagingParameterCount(DG_MINMAX_GET,pname)*sizeof(GLint)) ? (DGImagingParameterCount(DG_MINMAX_GET,pname)*sizeof(GLint)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLenum pname, GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetMinmaxParameteriv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,pname,params);
    return 0;
}
case 434: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[1],sizeof(width));
    GLenum internalformat=0;memcpy(&internalformat,&dg_wire_message->args[2],sizeof(internalformat));
    GLboolean sink=0;memcpy(&sink,&dg_wire_message->args[3],sizeof(sink));
    typedef void (*Proc)(GLenum target, GLsizei width, GLenum internalformat, GLboolean sink);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glHistogram");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,width,internalformat,sink);
    return 0;
}
case 435: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum internalformat=0;memcpy(&internalformat,&dg_wire_message->args[1],sizeof(internalformat));
    GLboolean sink=0;memcpy(&sink,&dg_wire_message->args[2],sizeof(sink));
    typedef void (*Proc)(GLenum target, GLenum internalformat, GLboolean sink);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMinmax");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,internalformat,sink);
    return 0;
}
case 436: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    typedef void (*Proc)(GLenum target);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glResetHistogram");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target);
    return 0;
}
case 437: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    typedef void (*Proc)(GLenum target);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glResetMinmax");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target);
    return 0;
}
case 438: {
    struct DGCompactUnpackScope compact_scope={0};
    if(dg_wire_message->args[15] && (dg_wire_message->args[15]!=2 || !dg_wire_message->args[9]))return -1;
    GLint pixel_buffer=0;if(context->inside_begin) { context->error=GL_INVALID_OPERATION;return 0; }glGetIntegerv(GL_PIXEL_UNPACK_BUFFER_BINDING,&pixel_buffer);if(pixel_buffer) { context->error=GL_INVALID_OPERATION;return 0; }
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLint level=0;memcpy(&level,&dg_wire_message->args[1],sizeof(level));
    GLint internalFormat=0;memcpy(&internalFormat,&dg_wire_message->args[2],sizeof(internalFormat));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[3],sizeof(width));
    GLsizei height=0;memcpy(&height,&dg_wire_message->args[4],sizeof(height));
    GLsizei depth=0;memcpy(&depth,&dg_wire_message->args[5],sizeof(depth));
    GLint border=0;memcpy(&border,&dg_wire_message->args[6],sizeof(border));
    GLenum format=0;memcpy(&format,&dg_wire_message->args[7],sizeof(format));
    GLenum type=0;memcpy(&type,&dg_wire_message->args[8],sizeof(type));
    const GLvoid * pixels=NULL;
    if(!(width>=0 && height>=0 && depth>=0 && DGRasterPixelBits(format,type))) {
        if(dg_wire_message->args[9] || dg_wire_message->bytes || dg_wire_message->args[15])return -1;
    }else {
    if(dg_wire_message->args[9])pixels=(const GLvoid *)DGHostPointer(dg_wire_message,9,(DGHostUnpackBytes(context,dg_wire_message,3,width,height,depth,format,type)));
    if(dg_wire_message->args[9] && !pixels) return -1;
    }
    if(!DGHostCompactUnpackBegin(context,dg_wire_message,&compact_scope))return 0;
    struct DGAutomaticMipmapScope automatic=DGBeginAutomaticMipmap(target,level,context->profile==kCGLOGLPVersion_Legacy,context->inside_begin,context->list_mode,&context->error,0,DGNonzeroMipmapBasePossible(context));
    DGHostTexture3D(context,0,target,level,internalFormat,0,0,0,width,height,depth,border,format,type,pixels,0);
    DGHostCompactUnpackEnd(context,&compact_scope);
    DGEndAutomaticMipmap(&automatic,NULL,&context->error);
    return 0;
}
case 439: {
    struct DGCompactUnpackScope compact_scope={0};
    if(dg_wire_message->args[15] && (dg_wire_message->args[15]!=2 || !dg_wire_message->args[10]))return -1;
    GLint pixel_buffer=0;if(context->inside_begin) { context->error=GL_INVALID_OPERATION;return 0; }glGetIntegerv(GL_PIXEL_UNPACK_BUFFER_BINDING,&pixel_buffer);if(pixel_buffer) { context->error=GL_INVALID_OPERATION;return 0; }
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLint level=0;memcpy(&level,&dg_wire_message->args[1],sizeof(level));
    GLint xoffset=0;memcpy(&xoffset,&dg_wire_message->args[2],sizeof(xoffset));
    GLint yoffset=0;memcpy(&yoffset,&dg_wire_message->args[3],sizeof(yoffset));
    GLint zoffset=0;memcpy(&zoffset,&dg_wire_message->args[4],sizeof(zoffset));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[5],sizeof(width));
    GLsizei height=0;memcpy(&height,&dg_wire_message->args[6],sizeof(height));
    GLsizei depth=0;memcpy(&depth,&dg_wire_message->args[7],sizeof(depth));
    GLenum format=0;memcpy(&format,&dg_wire_message->args[8],sizeof(format));
    GLenum type=0;memcpy(&type,&dg_wire_message->args[9],sizeof(type));
    const GLvoid * pixels=NULL;
    if(!(width>=0 && height>=0 && depth>=0 && DGRasterPixelBits(format,type))) {
        if(dg_wire_message->args[10] || dg_wire_message->bytes || dg_wire_message->args[15])return -1;
    }else {
    pixels=(const GLvoid *)DGHostPointer(dg_wire_message,10,(DGHostUnpackBytes(context,dg_wire_message,3,width,height,depth,format,type)));
    if((width && height && depth && !pixels) || (dg_wire_message->args[10] && !pixels)) return -1;
    }
    if(!DGHostCompactUnpackBegin(context,dg_wire_message,&compact_scope))return 0;
    struct DGAutomaticMipmapScope automatic=DGBeginAutomaticMipmap(target,level,context->profile==kCGLOGLPVersion_Legacy,context->inside_begin,context->list_mode,&context->error,0,DGNonzeroMipmapBasePossible(context));
    DGHostTexture3D(context,1,target,level,0,xoffset,yoffset,zoffset,width,height,depth,0,format,type,pixels,0);
    DGHostCompactUnpackEnd(context,&compact_scope);
    DGEndAutomaticMipmap(&automatic,NULL,&context->error);
    return 0;
}
case 440: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLint level=0;memcpy(&level,&dg_wire_message->args[1],sizeof(level));
    GLint xoffset=0;memcpy(&xoffset,&dg_wire_message->args[2],sizeof(xoffset));
    GLint yoffset=0;memcpy(&yoffset,&dg_wire_message->args[3],sizeof(yoffset));
    GLint zoffset=0;memcpy(&zoffset,&dg_wire_message->args[4],sizeof(zoffset));
    GLint x=0;memcpy(&x,&dg_wire_message->args[5],sizeof(x));
    GLint y=0;memcpy(&y,&dg_wire_message->args[6],sizeof(y));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[7],sizeof(width));
    GLsizei height=0;memcpy(&height,&dg_wire_message->args[8],sizeof(height));
    typedef void (*Proc)(GLenum target, GLint level, GLint xoffset, GLint yoffset, GLint zoffset, GLint x, GLint y, GLsizei width, GLsizei height);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glCopyTexSubImage3D");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    struct DGAutomaticMipmapScope automatic=DGBeginAutomaticMipmap(target,level,context->profile==kCGLOGLPVersion_Legacy,context->inside_begin,context->list_mode,&context->error,1,DGNonzeroMipmapBasePossible(context));
    proc(target,level,xoffset,yoffset,zoffset,x,y,width,height);
    DGEndAutomaticMipmap(&automatic,NULL,&context->error);
    return 0;
}
case 441: return DGHostUniformIndices(context,dg_wire_message);
case 442: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLsizei uniformCount=0;memcpy(&uniformCount,&dg_wire_message->args[1],sizeof(uniformCount));
    const GLuint* uniformIndices=NULL;
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[3],sizeof(pname));
    GLint* params=NULL;
    uniformIndices=(const GLuint*)DGHostPointer(dg_wire_message,2,((DGQueryArrayBytes(uniformCount,sizeof(GLuint))) ? (DGQueryArrayBytes(uniformCount,sizeof(GLuint))) : 1));
    if(!uniformIndices) return -1;
    params=(GLint*)DGHostPointer(dg_wire_message,4,((DGQueryArrayBytes(uniformCount,sizeof(GLint))) ? (DGQueryArrayBytes(uniformCount,sizeof(GLint))) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLuint program, GLsizei uniformCount, const GLuint* uniformIndices, GLenum pname, GLint* params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetActiveUniformsiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,uniformCount,uniformIndices,pname,params);
    return 0;
}
case 443: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLuint uniformIndex=0;memcpy(&uniformIndex,&dg_wire_message->args[1],sizeof(uniformIndex));
    GLsizei bufSize=0;memcpy(&bufSize,&dg_wire_message->args[2],sizeof(bufSize));
    GLsizei* length=NULL;
    GLchar* uniformName=NULL;
    length=(GLsizei*)DGHostPointer(dg_wire_message,3,((sizeof(GLsizei)) ? (sizeof(GLsizei)) : 1));
    if(dg_wire_message->args[3] && !length) return -1;
    uniformName=(GLchar*)DGHostPointer(dg_wire_message,4,((DGQueryArrayBytes(bufSize,1)) ? (DGQueryArrayBytes(bufSize,1)) : 1));
    if((bufSize>0 && !uniformName) || (dg_wire_message->args[4] && !uniformName)) return -1;
    typedef void (*Proc)(GLuint program, GLuint uniformIndex, GLsizei bufSize, GLsizei* length, GLchar* uniformName);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetActiveUniformName");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,uniformIndex,bufSize,length,uniformName);
    return 0;
}
case 444: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    const GLchar* uniformBlockName=DGHostString(dg_wire_message,1);if(!uniformBlockName) return -1;
    typedef GLuint (*Proc)(GLuint program, const GLchar* uniformBlockName);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetUniformBlockIndex");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLuint result=proc(program,uniformBlockName);
    reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 445: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLuint uniformBlockIndex=0;memcpy(&uniformBlockIndex,&dg_wire_message->args[1],sizeof(uniformBlockIndex));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[2],sizeof(pname));
    if(dg_wire_message->args[14]>DG_MAX_BYTES/sizeof(GLint))return -1;
    GLint block_count=(GLint)dg_wire_message->args[14];
    if(pname!=0x8a43 && block_count!=1)return -1;
    if(pname==0x8a43 && !DGHostUniformBlockCapacity(context,program,uniformBlockIndex,block_count))return 0;
    GLint* params=NULL;
    params=(GLint*)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(block_count,sizeof(GLint))) ? (DGQueryArrayBytes(block_count,sizeof(GLint))) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLuint program, GLuint uniformBlockIndex, GLenum pname, GLint* params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetActiveUniformBlockiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,uniformBlockIndex,pname,params);
    return 0;
}
case 446: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLuint uniformBlockIndex=0;memcpy(&uniformBlockIndex,&dg_wire_message->args[1],sizeof(uniformBlockIndex));
    GLsizei bufSize=0;memcpy(&bufSize,&dg_wire_message->args[2],sizeof(bufSize));
    GLsizei* length=NULL;
    GLchar* uniformBlockName=NULL;
    length=(GLsizei*)DGHostPointer(dg_wire_message,3,((sizeof(GLsizei)) ? (sizeof(GLsizei)) : 1));
    if(dg_wire_message->args[3] && !length) return -1;
    uniformBlockName=(GLchar*)DGHostPointer(dg_wire_message,4,((DGQueryArrayBytes(bufSize,1)) ? (DGQueryArrayBytes(bufSize,1)) : 1));
    if((bufSize>0 && !uniformBlockName) || (dg_wire_message->args[4] && !uniformBlockName)) return -1;
    typedef void (*Proc)(GLuint program, GLuint uniformBlockIndex, GLsizei bufSize, GLsizei* length, GLchar* uniformBlockName);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetActiveUniformBlockName");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,uniformBlockIndex,bufSize,length,uniformBlockName);
    return 0;
}
case 447: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLuint uniformBlockIndex=0;memcpy(&uniformBlockIndex,&dg_wire_message->args[1],sizeof(uniformBlockIndex));
    GLuint uniformBlockBinding=0;memcpy(&uniformBlockBinding,&dg_wire_message->args[2],sizeof(uniformBlockBinding));
    typedef void (*Proc)(GLuint program, GLuint uniformBlockIndex, GLuint uniformBlockBinding);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniformBlockBinding");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,uniformBlockIndex,uniformBlockBinding);
    return 0;
}
case 448: {
    GLenum stage=0;memcpy(&stage,&dg_wire_message->args[0],sizeof(stage));
    GLenum portion=0;memcpy(&portion,&dg_wire_message->args[1],sizeof(portion));
    GLenum variable=0;memcpy(&variable,&dg_wire_message->args[2],sizeof(variable));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[3],sizeof(pname));
    GLfloat * params=NULL;
    params=(GLfloat *)DGHostPointer(dg_wire_message,4,((1*sizeof(GLfloat)) ? (1*sizeof(GLfloat)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum stage, GLenum portion, GLenum variable, GLenum pname, GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetCombinerInputParameterfvNV");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(stage,portion,variable,pname,params);
    return 0;
}
case 449: {
    GLenum stage=0;memcpy(&stage,&dg_wire_message->args[0],sizeof(stage));
    GLenum portion=0;memcpy(&portion,&dg_wire_message->args[1],sizeof(portion));
    GLenum variable=0;memcpy(&variable,&dg_wire_message->args[2],sizeof(variable));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[3],sizeof(pname));
    GLint * params=NULL;
    params=(GLint *)DGHostPointer(dg_wire_message,4,((1*sizeof(GLint)) ? (1*sizeof(GLint)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum stage, GLenum portion, GLenum variable, GLenum pname, GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetCombinerInputParameterivNV");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(stage,portion,variable,pname,params);
    return 0;
}
case 450: {
    GLenum stage=0;memcpy(&stage,&dg_wire_message->args[0],sizeof(stage));
    GLenum portion=0;memcpy(&portion,&dg_wire_message->args[1],sizeof(portion));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[2],sizeof(pname));
    GLfloat * params=NULL;
    params=(GLfloat *)DGHostPointer(dg_wire_message,3,((1*sizeof(GLfloat)) ? (1*sizeof(GLfloat)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum stage, GLenum portion, GLenum pname, GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetCombinerOutputParameterfvNV");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(stage,portion,pname,params);
    return 0;
}
case 451: {
    GLenum stage=0;memcpy(&stage,&dg_wire_message->args[0],sizeof(stage));
    GLenum portion=0;memcpy(&portion,&dg_wire_message->args[1],sizeof(portion));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[2],sizeof(pname));
    GLint * params=NULL;
    params=(GLint *)DGHostPointer(dg_wire_message,3,((1*sizeof(GLint)) ? (1*sizeof(GLint)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum stage, GLenum portion, GLenum pname, GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetCombinerOutputParameterivNV");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(stage,portion,pname,params);
    return 0;
}
case 452: {
    GLenum variable=0;memcpy(&variable,&dg_wire_message->args[0],sizeof(variable));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLfloat * params=NULL;
    params=(GLfloat *)DGHostPointer(dg_wire_message,2,((1*sizeof(GLfloat)) ? (1*sizeof(GLfloat)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum variable, GLenum pname, GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetFinalCombinerInputParameterfvNV");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(variable,pname,params);
    return 0;
}
case 453: {
    GLenum variable=0;memcpy(&variable,&dg_wire_message->args[0],sizeof(variable));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint * params=NULL;
    params=(GLint *)DGHostPointer(dg_wire_message,2,((1*sizeof(GLint)) ? (1*sizeof(GLint)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum variable, GLenum pname, GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetFinalCombinerInputParameterivNV");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(variable,pname,params);
    return 0;
}
case 454: {
    GLenum stage=0;memcpy(&stage,&dg_wire_message->args[0],sizeof(stage));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    const GLfloat * params=NULL;
    params=(const GLfloat *)DGHostPointer(dg_wire_message,2,(4*sizeof(GLfloat)));
    if(!params) return -1;
    typedef void (*Proc)(GLenum stage, GLenum pname, const GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glCombinerStageParameterfvNV");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(stage,pname,params);
    return 0;
}
case 455: {
    GLenum stage=0;memcpy(&stage,&dg_wire_message->args[0],sizeof(stage));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLfloat * params=NULL;
    params=(GLfloat *)DGHostPointer(dg_wire_message,2,((4*sizeof(GLfloat)) ? (4*sizeof(GLfloat)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum stage, GLenum pname, GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetCombinerStageParameterfvNV");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(stage,pname,params);
    return 0;
}
case 458: {
    GLenum equationRGB=0;memcpy(&equationRGB,&dg_wire_message->args[0],sizeof(equationRGB));
    GLenum equationAlpha=0;memcpy(&equationAlpha,&dg_wire_message->args[1],sizeof(equationAlpha));
    typedef void (*Proc)(GLenum equationRGB, GLenum equationAlpha);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glBlendEquationSeparateEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(equationRGB,equationAlpha);
    return 0;
}
case 459: {
    GLclampf value=0;memcpy(&value,&dg_wire_message->args[0],sizeof(value));
    GLboolean invert=0;memcpy(&invert,&dg_wire_message->args[1],sizeof(invert));
    typedef void (*Proc)(GLclampf value, GLboolean invert);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glSampleCoverage");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(value,invert);
    return 0;
}
case 460: {
    GLenum mode=0;memcpy(&mode,&dg_wire_message->args[0],sizeof(mode));
    typedef void (*Proc)(GLenum mode);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glSamplePass");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(mode);
    return 0;
}
case 461: {
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[0],sizeof(pname));
    GLint param=0;memcpy(&param,&dg_wire_message->args[1],sizeof(param));
    typedef void (*Proc)(GLenum pname, GLint param);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPNTrianglesiATI");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pname,param);
    return 0;
}
case 462: {
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[0],sizeof(pname));
    GLfloat param=0;memcpy(&param,&dg_wire_message->args[1],sizeof(param));
    typedef void (*Proc)(GLenum pname, GLfloat param);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPNTrianglesfATI");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pname,param);
    return 0;
}
case 463: {
    GLsizei n=0;memcpy(&n,&dg_wire_message->args[0],sizeof(n));
    GLuint * fences=NULL;
    fences=(GLuint *)DGHostPointer(dg_wire_message,1,((DGQueryArrayBytes(n,sizeof(GLuint))) ? (DGQueryArrayBytes(n,sizeof(GLuint))) : 1));
    if(!fences) return -1;
    typedef void (*Proc)(GLsizei n, GLuint *fences);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGenFencesAPPLE");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(n,fences);
    for(GLsizei i=0;i<n;++i) DGFence(context,fences[i],1);
    return 0;
}
case 464: {
    GLsizei n=0;memcpy(&n,&dg_wire_message->args[0],sizeof(n));
    const GLuint * fences=NULL;
    fences=(const GLuint *)DGHostPointer(dg_wire_message,1,(DGArrayBytes(n,sizeof(GLuint))));
    if(!fences) return -1;
    typedef void (*Proc)(GLsizei n, const GLuint *fences);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glDeleteFencesAPPLE");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(n,fences);
    for(GLsizei i=0;i<n;++i) DGForgetFence(context,fences[i]);
    return 0;
}
case 465: {
    GLuint fence=0;memcpy(&fence,&dg_wire_message->args[0],sizeof(fence));
    typedef void (*Proc)(GLuint fence);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glSetFenceAPPLE");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(fence);
    struct DGFenceName *f=DGFence(context,fence,0);if(f) f->set=1;
    return 0;
}
case 466: {
    GLuint fence=0;memcpy(&fence,&dg_wire_message->args[0],sizeof(fence));
    typedef GLboolean (*Proc)(GLuint fence);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glIsFenceAPPLE");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLboolean result=proc(fence);
    reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 467: {
    GLuint fence=0;memcpy(&fence,&dg_wire_message->args[0],sizeof(fence));
    struct DGFenceName *f=DGFence(context,fence,0);
    if(f && !f->set) { reply->result=GL_TRUE;return 0; }
    typedef GLboolean (*Proc)(GLuint fence);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTestFenceAPPLE");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLboolean result=proc(fence);
    reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 468: {
    GLuint fence=0;memcpy(&fence,&dg_wire_message->args[0],sizeof(fence));
    struct DGFenceName *f=DGFence(context,fence,0);
    if(f && !f->set) { reply->result=GL_TRUE;return 0; }
    typedef void (*Proc)(GLuint fence);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glFinishFenceAPPLE");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(fence);
    return 0;
}
case 469: {
    GLenum object=0;memcpy(&object,&dg_wire_message->args[0],sizeof(object));
    GLuint name=0;memcpy(&name,&dg_wire_message->args[1],sizeof(name));
    typedef GLboolean (*Proc)(GLenum object, GLuint name);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTestObjectAPPLE");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLboolean result=proc(object,name);
    reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 470: {
    GLenum object=0;memcpy(&object,&dg_wire_message->args[0],sizeof(object));
    GLuint name=0;memcpy(&name,&dg_wire_message->args[1],sizeof(name));
    typedef void (*Proc)(GLenum object, GLuint name);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glFinishObjectAPPLE");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(object,name);
    return 0;
}
case 471: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint program=0;memcpy(&program,&dg_wire_message->args[1],sizeof(program));
    typedef void (*Proc)(GLenum target, GLuint program);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glBindProgramARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,program);
    return 0;
}
case 472: {
    GLsizei n=0;memcpy(&n,&dg_wire_message->args[0],sizeof(n));
    const GLuint * programs=NULL;
    programs=(const GLuint *)DGHostPointer(dg_wire_message,1,(DGArrayBytes(n,sizeof(GLuint))));
    if((n && !programs) || (dg_wire_message->args[1] && !programs)) return -1;
    typedef void (*Proc)(GLsizei n, const GLuint *programs);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glDeleteProgramsARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(n,programs);
    return 0;
}
case 473: {
    GLsizei n=0;memcpy(&n,&dg_wire_message->args[0],sizeof(n));
    GLuint * programs=NULL;
    programs=(GLuint *)DGHostPointer(dg_wire_message,1,((DGQueryArrayBytes(n,sizeof(GLuint))) ? (DGQueryArrayBytes(n,sizeof(GLuint))) : 1));
    if((n && !programs) || (dg_wire_message->args[1] && !programs)) return -1;
    typedef void (*Proc)(GLsizei n, GLuint *programs);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGenProgramsARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(n,programs);
    return 0;
}
case 474: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    typedef GLboolean (*Proc)(GLuint program);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glIsProgramARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLboolean result=proc(program);
    reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 475: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLshort x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    typedef void (*Proc)(GLuint index, GLshort x);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib1sARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,x);
    return 0;
}
case 476: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLfloat x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    typedef void (*Proc)(GLuint index, GLfloat x);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib1fARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,x);
    return 0;
}
case 477: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLdouble x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    typedef void (*Proc)(GLuint index, GLdouble x);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib1dARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,x);
    return 0;
}
case 478: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLshort x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    GLshort y=0;memcpy(&y,&dg_wire_message->args[2],sizeof(y));
    typedef void (*Proc)(GLuint index, GLshort x, GLshort y);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib2sARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,x,y);
    return 0;
}
case 479: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLfloat x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    GLfloat y=0;memcpy(&y,&dg_wire_message->args[2],sizeof(y));
    typedef void (*Proc)(GLuint index, GLfloat x, GLfloat y);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib2fARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,x,y);
    return 0;
}
case 480: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLdouble x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    GLdouble y=0;memcpy(&y,&dg_wire_message->args[2],sizeof(y));
    typedef void (*Proc)(GLuint index, GLdouble x, GLdouble y);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib2dARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,x,y);
    return 0;
}
case 481: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLshort x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    GLshort y=0;memcpy(&y,&dg_wire_message->args[2],sizeof(y));
    GLshort z=0;memcpy(&z,&dg_wire_message->args[3],sizeof(z));
    typedef void (*Proc)(GLuint index, GLshort x, GLshort y, GLshort z);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib3sARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,x,y,z);
    return 0;
}
case 482: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLfloat x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    GLfloat y=0;memcpy(&y,&dg_wire_message->args[2],sizeof(y));
    GLfloat z=0;memcpy(&z,&dg_wire_message->args[3],sizeof(z));
    typedef void (*Proc)(GLuint index, GLfloat x, GLfloat y, GLfloat z);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib3fARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,x,y,z);
    return 0;
}
case 483: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLdouble x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    GLdouble y=0;memcpy(&y,&dg_wire_message->args[2],sizeof(y));
    GLdouble z=0;memcpy(&z,&dg_wire_message->args[3],sizeof(z));
    typedef void (*Proc)(GLuint index, GLdouble x, GLdouble y, GLdouble z);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib3dARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,x,y,z);
    return 0;
}
case 484: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLshort x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    GLshort y=0;memcpy(&y,&dg_wire_message->args[2],sizeof(y));
    GLshort z=0;memcpy(&z,&dg_wire_message->args[3],sizeof(z));
    GLshort w=0;memcpy(&w,&dg_wire_message->args[4],sizeof(w));
    typedef void (*Proc)(GLuint index, GLshort x, GLshort y, GLshort z, GLshort w);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib4sARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,x,y,z,w);
    return 0;
}
case 485: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLfloat x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    GLfloat y=0;memcpy(&y,&dg_wire_message->args[2],sizeof(y));
    GLfloat z=0;memcpy(&z,&dg_wire_message->args[3],sizeof(z));
    GLfloat w=0;memcpy(&w,&dg_wire_message->args[4],sizeof(w));
    typedef void (*Proc)(GLuint index, GLfloat x, GLfloat y, GLfloat z, GLfloat w);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib4fARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,x,y,z,w);
    return 0;
}
case 486: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLdouble x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    GLdouble y=0;memcpy(&y,&dg_wire_message->args[2],sizeof(y));
    GLdouble z=0;memcpy(&z,&dg_wire_message->args[3],sizeof(z));
    GLdouble w=0;memcpy(&w,&dg_wire_message->args[4],sizeof(w));
    typedef void (*Proc)(GLuint index, GLdouble x, GLdouble y, GLdouble z, GLdouble w);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib4dARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,x,y,z,w);
    return 0;
}
case 487: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLubyte x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    GLubyte y=0;memcpy(&y,&dg_wire_message->args[2],sizeof(y));
    GLubyte z=0;memcpy(&z,&dg_wire_message->args[3],sizeof(z));
    GLubyte w=0;memcpy(&w,&dg_wire_message->args[4],sizeof(w));
    typedef void (*Proc)(GLuint index, GLubyte x, GLubyte y, GLubyte z, GLubyte w);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib4NubARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,x,y,z,w);
    return 0;
}
case 488: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLshort * v=NULL;
    v=(const GLshort *)DGHostPointer(dg_wire_message,1,(1*sizeof(GLshort)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLshort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib1svARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 489: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLfloat * v=NULL;
    v=(const GLfloat *)DGHostPointer(dg_wire_message,1,(1*sizeof(GLfloat)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLfloat *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib1fvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 490: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLdouble * v=NULL;
    v=(const GLdouble *)DGHostPointer(dg_wire_message,1,(1*sizeof(GLdouble)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLdouble *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib1dvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 491: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLshort * v=NULL;
    v=(const GLshort *)DGHostPointer(dg_wire_message,1,(2*sizeof(GLshort)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLshort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib2svARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 492: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLfloat * v=NULL;
    v=(const GLfloat *)DGHostPointer(dg_wire_message,1,(2*sizeof(GLfloat)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLfloat *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib2fvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 493: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLdouble * v=NULL;
    v=(const GLdouble *)DGHostPointer(dg_wire_message,1,(2*sizeof(GLdouble)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLdouble *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib2dvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 494: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLshort * v=NULL;
    v=(const GLshort *)DGHostPointer(dg_wire_message,1,(3*sizeof(GLshort)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLshort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib3svARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 495: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLfloat * v=NULL;
    v=(const GLfloat *)DGHostPointer(dg_wire_message,1,(3*sizeof(GLfloat)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLfloat *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib3fvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 496: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLdouble * v=NULL;
    v=(const GLdouble *)DGHostPointer(dg_wire_message,1,(3*sizeof(GLdouble)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLdouble *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib3dvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 497: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLbyte * v=NULL;
    v=(const GLbyte *)DGHostPointer(dg_wire_message,1,(4*sizeof(GLbyte)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLbyte *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib4bvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 498: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLshort * v=NULL;
    v=(const GLshort *)DGHostPointer(dg_wire_message,1,(4*sizeof(GLshort)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLshort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib4svARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 499: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLint * v=NULL;
    v=(const GLint *)DGHostPointer(dg_wire_message,1,(4*sizeof(GLint)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib4ivARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 500: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLubyte * v=NULL;
    v=(const GLubyte *)DGHostPointer(dg_wire_message,1,(4*sizeof(GLubyte)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLubyte *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib4ubvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 501: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLushort * v=NULL;
    v=(const GLushort *)DGHostPointer(dg_wire_message,1,(4*sizeof(GLushort)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLushort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib4usvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 502: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLuint * v=NULL;
    v=(const GLuint *)DGHostPointer(dg_wire_message,1,(4*sizeof(GLuint)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLuint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib4uivARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 503: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLfloat * v=NULL;
    v=(const GLfloat *)DGHostPointer(dg_wire_message,1,(4*sizeof(GLfloat)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLfloat *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib4fvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 504: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLdouble * v=NULL;
    v=(const GLdouble *)DGHostPointer(dg_wire_message,1,(4*sizeof(GLdouble)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLdouble *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib4dvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 505: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLbyte * v=NULL;
    v=(const GLbyte *)DGHostPointer(dg_wire_message,1,(4*sizeof(GLbyte)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLbyte *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib4NbvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 506: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLshort * v=NULL;
    v=(const GLshort *)DGHostPointer(dg_wire_message,1,(4*sizeof(GLshort)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLshort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib4NsvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 507: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLint * v=NULL;
    v=(const GLint *)DGHostPointer(dg_wire_message,1,(4*sizeof(GLint)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib4NivARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 508: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLubyte * v=NULL;
    v=(const GLubyte *)DGHostPointer(dg_wire_message,1,(4*sizeof(GLubyte)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLubyte *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib4NubvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 509: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLushort * v=NULL;
    v=(const GLushort *)DGHostPointer(dg_wire_message,1,(4*sizeof(GLushort)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLushort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib4NusvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 510: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLuint * v=NULL;
    v=(const GLuint *)DGHostPointer(dg_wire_message,1,(4*sizeof(GLuint)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLuint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttrib4NuivARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 514: {
    if(DGAppleEvaluatorQuery((GLenum)dg_wire_message->args[1]))return DGHostAppleEvaluatorQuery(context,dg_wire_message,reply,2);
    if(dg_wire_message->flags&DG_OUTPUT_ONLY)return -1;
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLdouble * params=NULL;
    params=(GLdouble *)DGHostPointer(dg_wire_message,2,((DGVertexAttribCount(pname) ? DGVertexAttribCount(pname)*sizeof(GLdouble) : SIZE_MAX) ? (DGVertexAttribCount(pname) ? DGVertexAttribCount(pname)*sizeof(GLdouble) : SIZE_MAX) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLuint index, GLenum pname, GLdouble *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetVertexAttribdvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,pname,params);
    return 0;
}
case 515: {
    if(DGAppleEvaluatorQuery((GLenum)dg_wire_message->args[1]))return DGHostAppleEvaluatorQuery(context,dg_wire_message,reply,1);
    if(dg_wire_message->flags&DG_OUTPUT_ONLY)return -1;
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLfloat * params=NULL;
    params=(GLfloat *)DGHostPointer(dg_wire_message,2,((DGVertexAttribCount(pname) ? DGVertexAttribCount(pname)*sizeof(GLfloat) : SIZE_MAX) ? (DGVertexAttribCount(pname) ? DGVertexAttribCount(pname)*sizeof(GLfloat) : SIZE_MAX) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLuint index, GLenum pname, GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetVertexAttribfvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,pname,params);
    return 0;
}
case 516: {
    if(DGAppleEvaluatorQuery((GLenum)dg_wire_message->args[1]))return DGHostAppleEvaluatorQuery(context,dg_wire_message,reply,0);
    if(dg_wire_message->flags&DG_OUTPUT_ONLY)return -1;
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint * params=NULL;
    params=(GLint *)DGHostPointer(dg_wire_message,2,((DGVertexAttribCount(pname) ? DGVertexAttribCount(pname)*sizeof(GLint) : SIZE_MAX) ? (DGVertexAttribCount(pname) ? DGVertexAttribCount(pname)*sizeof(GLint) : SIZE_MAX) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLuint index, GLenum pname, GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetVertexAttribivARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,pname,params);
    return 0;
}
case 518: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    GLdouble x=0;memcpy(&x,&dg_wire_message->args[2],sizeof(x));
    GLdouble y=0;memcpy(&y,&dg_wire_message->args[3],sizeof(y));
    GLdouble z=0;memcpy(&z,&dg_wire_message->args[4],sizeof(z));
    GLdouble w=0;memcpy(&w,&dg_wire_message->args[5],sizeof(w));
    typedef void (*Proc)(GLenum target, GLuint index, GLdouble x, GLdouble y, GLdouble z, GLdouble w);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramEnvParameter4dARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,index,x,y,z,w);
    return 0;
}
case 519: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    const GLdouble * params=NULL;
    params=(const GLdouble *)DGHostPointer(dg_wire_message,2,(4*sizeof(GLdouble)));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLuint index, const GLdouble *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramEnvParameter4dvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,index,params);
    return 0;
}
case 520: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    GLfloat x=0;memcpy(&x,&dg_wire_message->args[2],sizeof(x));
    GLfloat y=0;memcpy(&y,&dg_wire_message->args[3],sizeof(y));
    GLfloat z=0;memcpy(&z,&dg_wire_message->args[4],sizeof(z));
    GLfloat w=0;memcpy(&w,&dg_wire_message->args[5],sizeof(w));
    typedef void (*Proc)(GLenum target, GLuint index, GLfloat x, GLfloat y, GLfloat z, GLfloat w);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramEnvParameter4fARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,index,x,y,z,w);
    return 0;
}
case 521: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    const GLfloat * params=NULL;
    params=(const GLfloat *)DGHostPointer(dg_wire_message,2,(4*sizeof(GLfloat)));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLuint index, const GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramEnvParameter4fvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,index,params);
    return 0;
}
case 522: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    GLdouble x=0;memcpy(&x,&dg_wire_message->args[2],sizeof(x));
    GLdouble y=0;memcpy(&y,&dg_wire_message->args[3],sizeof(y));
    GLdouble z=0;memcpy(&z,&dg_wire_message->args[4],sizeof(z));
    GLdouble w=0;memcpy(&w,&dg_wire_message->args[5],sizeof(w));
    typedef void (*Proc)(GLenum target, GLuint index, GLdouble x, GLdouble y, GLdouble z, GLdouble w);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramLocalParameter4dARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,index,x,y,z,w);
    return 0;
}
case 523: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    const GLdouble * params=NULL;
    params=(const GLdouble *)DGHostPointer(dg_wire_message,2,(4*sizeof(GLdouble)));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLuint index, const GLdouble *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramLocalParameter4dvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,index,params);
    return 0;
}
case 524: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    GLfloat x=0;memcpy(&x,&dg_wire_message->args[2],sizeof(x));
    GLfloat y=0;memcpy(&y,&dg_wire_message->args[3],sizeof(y));
    GLfloat z=0;memcpy(&z,&dg_wire_message->args[4],sizeof(z));
    GLfloat w=0;memcpy(&w,&dg_wire_message->args[5],sizeof(w));
    typedef void (*Proc)(GLenum target, GLuint index, GLfloat x, GLfloat y, GLfloat z, GLfloat w);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramLocalParameter4fARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,index,x,y,z,w);
    return 0;
}
case 525: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    const GLfloat * params=NULL;
    params=(const GLfloat *)DGHostPointer(dg_wire_message,2,(4*sizeof(GLfloat)));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLuint index, const GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramLocalParameter4fvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,index,params);
    return 0;
}
case 526: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    GLdouble * params=NULL;
    params=(GLdouble *)DGHostPointer(dg_wire_message,2,((4*sizeof(GLdouble)) ? (4*sizeof(GLdouble)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLuint index, GLdouble *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetProgramEnvParameterdvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,index,params);
    return 0;
}
case 527: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    GLfloat * params=NULL;
    params=(GLfloat *)DGHostPointer(dg_wire_message,2,((4*sizeof(GLfloat)) ? (4*sizeof(GLfloat)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLuint index, GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetProgramEnvParameterfvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,index,params);
    return 0;
}
case 528: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    GLdouble * params=NULL;
    params=(GLdouble *)DGHostPointer(dg_wire_message,2,((4*sizeof(GLdouble)) ? (4*sizeof(GLdouble)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLuint index, GLdouble *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetProgramLocalParameterdvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,index,params);
    return 0;
}
case 529: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    GLfloat * params=NULL;
    params=(GLfloat *)DGHostPointer(dg_wire_message,2,((4*sizeof(GLfloat)) ? (4*sizeof(GLfloat)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLuint index, GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetProgramLocalParameterfvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,index,params);
    return 0;
}
case 530: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum format=0;memcpy(&format,&dg_wire_message->args[1],sizeof(format));
    GLsizei len=0;memcpy(&len,&dg_wire_message->args[2],sizeof(len));
    const GLvoid* string=NULL;
    string=(const GLvoid*)DGHostPointer(dg_wire_message,3,(DGArrayBytes(len,1)));
    if((len && !string) || (dg_wire_message->args[3] && !string)) return -1;
    typedef void (*Proc)(GLenum target, GLenum format, GLsizei len, const GLvoid* string);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramStringARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    static const unsigned char empty_program=0;if(!len)string=&empty_program;
    DGHostARBProgramString(context,target,format,len,string);
    return 0;
}
case 532: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint * params=NULL;
    params=(GLint *)DGHostPointer(dg_wire_message,2,((sizeof(GLint)) ? (sizeof(GLint)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLenum pname, GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetProgramivARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    DGHostGetARBProgramiv(context,target,pname,params);
    return 0;
}
case 533: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    typedef void (*Proc)(GLuint index, GLenum pname);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glEnableVertexAttribAPPLE");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,pname);
    return 0;
}
case 534: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    typedef void (*Proc)(GLuint index, GLenum pname);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glDisableVertexAttribAPPLE");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,pname);
    return 0;
}
case 535: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    typedef GLboolean (*Proc)(GLuint index, GLenum pname);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glIsVertexAttribEnabledAPPLE");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLboolean result=proc(index,pname);
    reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 536: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLuint size=0;memcpy(&size,&dg_wire_message->args[1],sizeof(size));
    GLdouble u1=0;memcpy(&u1,&dg_wire_message->args[2],sizeof(u1));
    GLdouble u2=0;memcpy(&u2,&dg_wire_message->args[3],sizeof(u2));
    GLint stride=0;memcpy(&stride,&dg_wire_message->args[4],sizeof(stride));
    GLint order=0;memcpy(&order,&dg_wire_message->args[5],sizeof(order));
    const GLdouble * points=NULL;
    int admitted=DGHostEvaluatorInput(context,dg_wire_message,reply,index,size,stride,order,0,1,u1!=u2,sizeof(GLdouble),1,6,1);
    if(admitted<=0)return admitted;
    points=(const GLdouble *)(dg_wire_message+1);
    typedef void (*Proc)(GLuint index, GLuint size, GLdouble u1, GLdouble u2, GLint stride, GLint order, const GLdouble *points);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMapVertexAttrib1dAPPLE");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,size,u1,u2,stride,order,points);
    return 0;
}
case 537: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLuint size=0;memcpy(&size,&dg_wire_message->args[1],sizeof(size));
    GLfloat u1=0;memcpy(&u1,&dg_wire_message->args[2],sizeof(u1));
    GLfloat u2=0;memcpy(&u2,&dg_wire_message->args[3],sizeof(u2));
    GLint stride=0;memcpy(&stride,&dg_wire_message->args[4],sizeof(stride));
    GLint order=0;memcpy(&order,&dg_wire_message->args[5],sizeof(order));
    const GLfloat * points=NULL;
    int admitted=DGHostEvaluatorInput(context,dg_wire_message,reply,index,size,stride,order,0,1,u1!=u2,sizeof(GLfloat),1,6,1);
    if(admitted<=0)return admitted;
    points=(const GLfloat *)(dg_wire_message+1);
    typedef void (*Proc)(GLuint index, GLuint size, GLfloat u1, GLfloat u2, GLint stride, GLint order, const GLfloat *points);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMapVertexAttrib1fAPPLE");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,size,u1,u2,stride,order,points);
    return 0;
}
case 538: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLuint size=0;memcpy(&size,&dg_wire_message->args[1],sizeof(size));
    GLdouble u1=0;memcpy(&u1,&dg_wire_message->args[2],sizeof(u1));
    GLdouble u2=0;memcpy(&u2,&dg_wire_message->args[3],sizeof(u2));
    GLint ustride=0;memcpy(&ustride,&dg_wire_message->args[4],sizeof(ustride));
    GLint uorder=0;memcpy(&uorder,&dg_wire_message->args[5],sizeof(uorder));
    GLdouble v1=0;memcpy(&v1,&dg_wire_message->args[6],sizeof(v1));
    GLdouble v2=0;memcpy(&v2,&dg_wire_message->args[7],sizeof(v2));
    GLint vstride=0;memcpy(&vstride,&dg_wire_message->args[8],sizeof(vstride));
    GLint vorder=0;memcpy(&vorder,&dg_wire_message->args[9],sizeof(vorder));
    const GLdouble * points=NULL;
    int admitted=DGHostEvaluatorInput(context,dg_wire_message,reply,index,size,ustride,uorder,vstride,vorder,u1!=u2 && v1!=v2,sizeof(GLdouble),2,10,1);
    if(admitted<=0)return admitted;
    points=(const GLdouble *)(dg_wire_message+1);
    typedef void (*Proc)(GLuint index, GLuint size, GLdouble u1, GLdouble u2, GLint ustride, GLint uorder, GLdouble v1, GLdouble v2, GLint vstride, GLint vorder, const GLdouble *points);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMapVertexAttrib2dAPPLE");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,size,u1,u2,ustride,uorder,v1,v2,vstride,vorder,points);
    return 0;
}
case 539: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLuint size=0;memcpy(&size,&dg_wire_message->args[1],sizeof(size));
    GLfloat u1=0;memcpy(&u1,&dg_wire_message->args[2],sizeof(u1));
    GLfloat u2=0;memcpy(&u2,&dg_wire_message->args[3],sizeof(u2));
    GLint ustride=0;memcpy(&ustride,&dg_wire_message->args[4],sizeof(ustride));
    GLint uorder=0;memcpy(&uorder,&dg_wire_message->args[5],sizeof(uorder));
    GLfloat v1=0;memcpy(&v1,&dg_wire_message->args[6],sizeof(v1));
    GLfloat v2=0;memcpy(&v2,&dg_wire_message->args[7],sizeof(v2));
    GLint vstride=0;memcpy(&vstride,&dg_wire_message->args[8],sizeof(vstride));
    GLint vorder=0;memcpy(&vorder,&dg_wire_message->args[9],sizeof(vorder));
    const GLfloat * points=NULL;
    int admitted=DGHostEvaluatorInput(context,dg_wire_message,reply,index,size,ustride,uorder,vstride,vorder,u1!=u2 && v1!=v2,sizeof(GLfloat),2,10,1);
    if(admitted<=0)return admitted;
    points=(const GLfloat *)(dg_wire_message+1);
    typedef void (*Proc)(GLuint index, GLuint size, GLfloat u1, GLfloat u2, GLint ustride, GLint uorder, GLfloat v1, GLfloat v2, GLint vstride, GLint vorder, const GLfloat *points);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMapVertexAttrib2fAPPLE");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,size,u1,u2,ustride,uorder,v1,v2,vstride,vorder,points);
    return 0;
}
case 540: {
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[0],sizeof(pname));
    GLfloat param=0;memcpy(&param,&dg_wire_message->args[1],sizeof(param));
    typedef void (*Proc)(GLenum pname, GLfloat param);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPointParameterf");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pname,param);
    return 0;
}
case 541: {
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[0],sizeof(pname));
    const GLfloat * params=NULL;
    params=(const GLfloat *)DGHostPointer(dg_wire_message,1,((pname==GL_POINT_DISTANCE_ATTENUATION ? 3 : 1)*sizeof(GLfloat)));
    if(!params) return -1;
    typedef void (*Proc)(GLenum pname, const GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPointParameterfv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pname,params);
    return 0;
}
case 542: {
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[0],sizeof(pname));
    GLint param=0;memcpy(&param,&dg_wire_message->args[1],sizeof(param));
    typedef void (*Proc)(GLenum pname, GLint param);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPointParameteri");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pname,param);
    return 0;
}
case 543: {
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[0],sizeof(pname));
    const GLint * params=NULL;
    params=(const GLint *)DGHostPointer(dg_wire_message,1,((pname==GL_POINT_DISTANCE_ATTENUATION ? 3 : 1)*sizeof(GLint)));
    if(!params) return -1;
    typedef void (*Proc)(GLenum pname, const GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPointParameteriv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pname,params);
    return 0;
}
case 544: {
    GLfloat coord=0;memcpy(&coord,&dg_wire_message->args[0],sizeof(coord));
    typedef void (*Proc)(GLfloat coord);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glFogCoordf");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(coord);
    return 0;
}
case 545: {
    const GLfloat * coord=NULL;
    coord=(const GLfloat *)DGHostPointer(dg_wire_message,0,(sizeof(GLfloat)));
    if(!coord) return -1;
    typedef void (*Proc)(const GLfloat *coord);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glFogCoordfv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(coord);
    return 0;
}
case 546: {
    GLdouble coord=0;memcpy(&coord,&dg_wire_message->args[0],sizeof(coord));
    typedef void (*Proc)(GLdouble coord);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glFogCoordd");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(coord);
    return 0;
}
case 547: {
    const GLdouble * coord=NULL;
    coord=(const GLdouble *)DGHostPointer(dg_wire_message,0,(sizeof(GLdouble)));
    if(!coord) return -1;
    typedef void (*Proc)(const GLdouble *coord);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glFogCoorddv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(coord);
    return 0;
}
case 550: {
    GLuint id=0;memcpy(&id,&dg_wire_message->args[0],sizeof(id));
    DGBindHostVertexArray(context,id);
    return 0;
}
case 551: {
    GLsizei n=0;memcpy(&n,&dg_wire_message->args[0],sizeof(n));
    const GLuint * ids=NULL;
    ids=(const GLuint *)DGHostPointer(dg_wire_message,1,(DGArrayBytes(n,sizeof(GLuint))));
    if(!ids) return -1;
    DGDeleteHostVertexArrays(context,n,ids);
    return 0;
}
case 552: {
    GLsizei n=0;memcpy(&n,&dg_wire_message->args[0],sizeof(n));
    GLuint * ids=NULL;
    ids=(GLuint *)DGHostPointer(dg_wire_message,1,((DGQueryArrayBytes(n,sizeof(GLuint))) ? (DGQueryArrayBytes(n,sizeof(GLuint))) : 1));
    if(!ids) return -1;
    DGGenHostVertexArrays(context,n,ids);
    return 0;
}
case 553: {
    GLuint id=0;memcpy(&id,&dg_wire_message->args[0],sizeof(id));
    reply->result=DGIsHostVertexArray(context,id);
    return 0;
}
case 557: {
    if((GLint)(uint32_t)dg_wire_message->args[0]<0 || dg_wire_message->args[0]>DG_VERTEX_WEIGHT_MAX)return -1;
    GLint size=0;memcpy(&size,&dg_wire_message->args[0],sizeof(size));
    const GLbyte * weights=NULL;
    weights=(const GLbyte *)DGHostPointer(dg_wire_message,1,((DGQueryArrayBytes(size,sizeof(GLbyte))) ? (DGQueryArrayBytes(size,sizeof(GLbyte))) : 1));
    if(!weights) return -1;
    typedef void (*Proc)(GLint size, const GLbyte *weights);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glWeightbvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(size,weights);
    return 0;
}
case 558: {
    if((GLint)(uint32_t)dg_wire_message->args[0]<0 || dg_wire_message->args[0]>DG_VERTEX_WEIGHT_MAX)return -1;
    GLint size=0;memcpy(&size,&dg_wire_message->args[0],sizeof(size));
    const GLshort * weights=NULL;
    weights=(const GLshort *)DGHostPointer(dg_wire_message,1,((DGQueryArrayBytes(size,sizeof(GLshort))) ? (DGQueryArrayBytes(size,sizeof(GLshort))) : 1));
    if(!weights) return -1;
    typedef void (*Proc)(GLint size, const GLshort *weights);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glWeightsvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(size,weights);
    return 0;
}
case 559: {
    if((GLint)(uint32_t)dg_wire_message->args[0]<0 || dg_wire_message->args[0]>DG_VERTEX_WEIGHT_MAX)return -1;
    GLint size=0;memcpy(&size,&dg_wire_message->args[0],sizeof(size));
    const GLint * weights=NULL;
    weights=(const GLint *)DGHostPointer(dg_wire_message,1,((DGQueryArrayBytes(size,sizeof(GLint))) ? (DGQueryArrayBytes(size,sizeof(GLint))) : 1));
    if(!weights) return -1;
    typedef void (*Proc)(GLint size, const GLint *weights);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glWeightivARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(size,weights);
    return 0;
}
case 560: {
    if((GLint)(uint32_t)dg_wire_message->args[0]<0 || dg_wire_message->args[0]>DG_VERTEX_WEIGHT_MAX)return -1;
    GLint size=0;memcpy(&size,&dg_wire_message->args[0],sizeof(size));
    const GLfloat * weights=NULL;
    weights=(const GLfloat *)DGHostPointer(dg_wire_message,1,((DGQueryArrayBytes(size,sizeof(GLfloat))) ? (DGQueryArrayBytes(size,sizeof(GLfloat))) : 1));
    if(!weights) return -1;
    typedef void (*Proc)(GLint size, const GLfloat *weights);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glWeightfvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(size,weights);
    return 0;
}
case 561: {
    if((GLint)(uint32_t)dg_wire_message->args[0]<0 || dg_wire_message->args[0]>DG_VERTEX_WEIGHT_MAX)return -1;
    GLint size=0;memcpy(&size,&dg_wire_message->args[0],sizeof(size));
    const GLdouble * weights=NULL;
    weights=(const GLdouble *)DGHostPointer(dg_wire_message,1,((DGQueryArrayBytes(size,sizeof(GLdouble))) ? (DGQueryArrayBytes(size,sizeof(GLdouble))) : 1));
    if(!weights) return -1;
    typedef void (*Proc)(GLint size, const GLdouble *weights);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glWeightdvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(size,weights);
    return 0;
}
case 562: {
    if((GLint)(uint32_t)dg_wire_message->args[0]<0 || dg_wire_message->args[0]>DG_VERTEX_WEIGHT_MAX)return -1;
    GLint size=0;memcpy(&size,&dg_wire_message->args[0],sizeof(size));
    const GLubyte * weights=NULL;
    weights=(const GLubyte *)DGHostPointer(dg_wire_message,1,((DGQueryArrayBytes(size,sizeof(GLubyte))) ? (DGQueryArrayBytes(size,sizeof(GLubyte))) : 1));
    if(!weights) return -1;
    typedef void (*Proc)(GLint size, const GLubyte *weights);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glWeightubvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(size,weights);
    return 0;
}
case 563: {
    if((GLint)(uint32_t)dg_wire_message->args[0]<0 || dg_wire_message->args[0]>DG_VERTEX_WEIGHT_MAX)return -1;
    GLint size=0;memcpy(&size,&dg_wire_message->args[0],sizeof(size));
    const GLushort * weights=NULL;
    weights=(const GLushort *)DGHostPointer(dg_wire_message,1,((DGQueryArrayBytes(size,sizeof(GLushort))) ? (DGQueryArrayBytes(size,sizeof(GLushort))) : 1));
    if(!weights) return -1;
    typedef void (*Proc)(GLint size, const GLushort *weights);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glWeightusvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(size,weights);
    return 0;
}
case 564: {
    if((GLint)(uint32_t)dg_wire_message->args[0]<0 || dg_wire_message->args[0]>DG_VERTEX_WEIGHT_MAX)return -1;
    GLint size=0;memcpy(&size,&dg_wire_message->args[0],sizeof(size));
    const GLuint * weights=NULL;
    weights=(const GLuint *)DGHostPointer(dg_wire_message,1,((DGQueryArrayBytes(size,sizeof(GLuint))) ? (DGQueryArrayBytes(size,sizeof(GLuint))) : 1));
    if(!weights) return -1;
    typedef void (*Proc)(GLint size, const GLuint *weights);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glWeightuivARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(size,weights);
    return 0;
}
case 566: {
    GLint count=0;memcpy(&count,&dg_wire_message->args[0],sizeof(count));
    typedef void (*Proc)(GLint count);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexBlendARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(count);
    return 0;
}
case 569: {
    GLdouble x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLdouble y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    typedef void (*Proc)(GLdouble x, GLdouble y);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glWindowPos2d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y);
    return 0;
}
case 570: {
    const GLdouble * v=NULL;
    v=(const GLdouble *)DGHostPointer(dg_wire_message,0,(2*sizeof(GLdouble)));
    if(!v) return -1;
    typedef void (*Proc)(const GLdouble *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glWindowPos2dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 571: {
    GLfloat x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLfloat y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    typedef void (*Proc)(GLfloat x, GLfloat y);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glWindowPos2f");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y);
    return 0;
}
case 572: {
    const GLfloat * v=NULL;
    v=(const GLfloat *)DGHostPointer(dg_wire_message,0,(2*sizeof(GLfloat)));
    if(!v) return -1;
    typedef void (*Proc)(const GLfloat *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glWindowPos2fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 573: {
    GLint x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLint y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    typedef void (*Proc)(GLint x, GLint y);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glWindowPos2i");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y);
    return 0;
}
case 574: {
    const GLint * v=NULL;
    v=(const GLint *)DGHostPointer(dg_wire_message,0,(2*sizeof(GLint)));
    if(!v) return -1;
    typedef void (*Proc)(const GLint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glWindowPos2iv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 575: {
    GLshort x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLshort y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    typedef void (*Proc)(GLshort x, GLshort y);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glWindowPos2s");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y);
    return 0;
}
case 576: {
    const GLshort * v=NULL;
    v=(const GLshort *)DGHostPointer(dg_wire_message,0,(2*sizeof(GLshort)));
    if(!v) return -1;
    typedef void (*Proc)(const GLshort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glWindowPos2sv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 577: {
    GLdouble x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLdouble y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    GLdouble z=0;memcpy(&z,&dg_wire_message->args[2],sizeof(z));
    typedef void (*Proc)(GLdouble x, GLdouble y, GLdouble z);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glWindowPos3d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y,z);
    return 0;
}
case 578: {
    const GLdouble * v=NULL;
    v=(const GLdouble *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLdouble)));
    if(!v) return -1;
    typedef void (*Proc)(const GLdouble *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glWindowPos3dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 579: {
    GLfloat x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLfloat y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    GLfloat z=0;memcpy(&z,&dg_wire_message->args[2],sizeof(z));
    typedef void (*Proc)(GLfloat x, GLfloat y, GLfloat z);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glWindowPos3f");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y,z);
    return 0;
}
case 580: {
    const GLfloat * v=NULL;
    v=(const GLfloat *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLfloat)));
    if(!v) return -1;
    typedef void (*Proc)(const GLfloat *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glWindowPos3fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 581: {
    GLint x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLint y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    GLint z=0;memcpy(&z,&dg_wire_message->args[2],sizeof(z));
    typedef void (*Proc)(GLint x, GLint y, GLint z);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glWindowPos3i");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y,z);
    return 0;
}
case 582: {
    const GLint * v=NULL;
    v=(const GLint *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLint)));
    if(!v) return -1;
    typedef void (*Proc)(const GLint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glWindowPos3iv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 583: {
    GLshort x=0;memcpy(&x,&dg_wire_message->args[0],sizeof(x));
    GLshort y=0;memcpy(&y,&dg_wire_message->args[1],sizeof(y));
    GLshort z=0;memcpy(&z,&dg_wire_message->args[2],sizeof(z));
    typedef void (*Proc)(GLshort x, GLshort y, GLshort z);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glWindowPos3s");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(x,y,z);
    return 0;
}
case 584: {
    const GLshort * v=NULL;
    v=(const GLshort *)DGHostPointer(dg_wire_message,0,(3*sizeof(GLshort)));
    if(!v) return -1;
    typedef void (*Proc)(const GLshort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glWindowPos3sv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(v);
    return 0;
}
case 585: {
    GLenum face=0;memcpy(&face,&dg_wire_message->args[0],sizeof(face));
    typedef void (*Proc)(GLenum face);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glActiveStencilFaceEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(face);
    return 0;
}
case 586: {
    GLenum face=0;memcpy(&face,&dg_wire_message->args[0],sizeof(face));
    GLenum sfail=0;memcpy(&sfail,&dg_wire_message->args[1],sizeof(sfail));
    GLenum dpfail=0;memcpy(&dpfail,&dg_wire_message->args[2],sizeof(dpfail));
    GLenum dppass=0;memcpy(&dppass,&dg_wire_message->args[3],sizeof(dppass));
    typedef void (*Proc)(GLenum face, GLenum sfail, GLenum dpfail, GLenum dppass);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glStencilOpSeparateATI");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(face,sfail,dpfail,dppass);
    return 0;
}
case 587: {
    GLenum frontfunc=0;memcpy(&frontfunc,&dg_wire_message->args[0],sizeof(frontfunc));
    GLenum backfunc=0;memcpy(&backfunc,&dg_wire_message->args[1],sizeof(backfunc));
    GLint ref=0;memcpy(&ref,&dg_wire_message->args[2],sizeof(ref));
    GLuint mask=0;memcpy(&mask,&dg_wire_message->args[3],sizeof(mask));
    typedef void (*Proc)(GLenum frontfunc, GLenum backfunc, GLint ref, GLuint mask);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glStencilFuncSeparateATI");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(frontfunc,backfunc,ref,mask);
    return 0;
}
case 588: {
    typedef void (*Proc)(void);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glFlushRenderAPPLE");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc();
    return 0;
}
case 589: {
    typedef void (*Proc)(void);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glFinishRenderAPPLE");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc();
    return 0;
}
case 590: {
    typedef void (*Proc)(void);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glSwapAPPLE");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc();
    return 0;
}
case 591: {
    GLhandleARB obj=0;memcpy(&obj,&dg_wire_message->args[0],sizeof(obj));
    GLuint name=(GLuint)(uintptr_t)obj;if(glIsShader(name)) glDeleteShader(name);else if(glIsProgram(name)) { DGForgetUniformShapes(context,name);glDeleteProgram(name); }else context->error=GL_INVALID_VALUE;
    return 0;
}
case 592: {
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[0],sizeof(pname));
    GLint name=0;if(pname==GL_PROGRAM_OBJECT_ARB) glGetIntegerv(GL_CURRENT_PROGRAM,&name);else context->error=GL_INVALID_ENUM;reply->result=(uint32_t)name;
    return 0;
}
case 593: {
    GLhandleARB containerObj=0;memcpy(&containerObj,&dg_wire_message->args[0],sizeof(containerObj));
    GLhandleARB attachedObj=0;memcpy(&attachedObj,&dg_wire_message->args[1],sizeof(attachedObj));
    glDetachShader((GLuint)(uintptr_t)containerObj,(GLuint)(uintptr_t)attachedObj);
    return 0;
}
case 594: {
    GLenum shaderType=0;memcpy(&shaderType,&dg_wire_message->args[0],sizeof(shaderType));
    GLhandleARB result=(GLhandleARB)(uintptr_t)glCreateShader(shaderType);reply->result=(uintptr_t)result;
    return 0;
}
case 595: return DGHostShaderSource(context,dg_wire_message,reply);
case 596: {
    GLhandleARB shaderObj=0;memcpy(&shaderObj,&dg_wire_message->args[0],sizeof(shaderObj));
    glCompileShader((GLuint)(uintptr_t)shaderObj);
    return 0;
}
case 597: {
    GLhandleARB result=(GLhandleARB)(uintptr_t)glCreateProgram();reply->result=(uintptr_t)result;
    return 0;
}
case 598: {
    GLhandleARB containerObj=0;memcpy(&containerObj,&dg_wire_message->args[0],sizeof(containerObj));
    GLhandleARB obj=0;memcpy(&obj,&dg_wire_message->args[1],sizeof(obj));
    glAttachShader((GLuint)(uintptr_t)containerObj,(GLuint)(uintptr_t)obj);
    return 0;
}
case 599: {
    GLhandleARB programObj=0;memcpy(&programObj,&dg_wire_message->args[0],sizeof(programObj));
    DGForgetUniformShapes(context,(GLuint)(uintptr_t)programObj);DGHostLinkProgram(context,(GLuint)(uintptr_t)programObj);
    return 0;
}
case 600: {
    GLhandleARB programObj=0;memcpy(&programObj,&dg_wire_message->args[0],sizeof(programObj));
    glUseProgram((GLuint)(uintptr_t)programObj);
    return 0;
}
case 601: {
    GLhandleARB programObj=0;memcpy(&programObj,&dg_wire_message->args[0],sizeof(programObj));
    glValidateProgram((GLuint)(uintptr_t)programObj);
    return 0;
}
case 602: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLfloat v0=0;memcpy(&v0,&dg_wire_message->args[1],sizeof(v0));
    typedef void (*Proc)(GLint location, GLfloat v0);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform1fARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,v0);
    return 0;
}
case 603: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLfloat v0=0;memcpy(&v0,&dg_wire_message->args[1],sizeof(v0));
    GLfloat v1=0;memcpy(&v1,&dg_wire_message->args[2],sizeof(v1));
    typedef void (*Proc)(GLint location, GLfloat v0, GLfloat v1);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform2fARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,v0,v1);
    return 0;
}
case 604: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLfloat v0=0;memcpy(&v0,&dg_wire_message->args[1],sizeof(v0));
    GLfloat v1=0;memcpy(&v1,&dg_wire_message->args[2],sizeof(v1));
    GLfloat v2=0;memcpy(&v2,&dg_wire_message->args[3],sizeof(v2));
    typedef void (*Proc)(GLint location, GLfloat v0, GLfloat v1, GLfloat v2);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform3fARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,v0,v1,v2);
    return 0;
}
case 605: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLfloat v0=0;memcpy(&v0,&dg_wire_message->args[1],sizeof(v0));
    GLfloat v1=0;memcpy(&v1,&dg_wire_message->args[2],sizeof(v1));
    GLfloat v2=0;memcpy(&v2,&dg_wire_message->args[3],sizeof(v2));
    GLfloat v3=0;memcpy(&v3,&dg_wire_message->args[4],sizeof(v3));
    typedef void (*Proc)(GLint location, GLfloat v0, GLfloat v1, GLfloat v2, GLfloat v3);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform4fARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,v0,v1,v2,v3);
    return 0;
}
case 606: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLint v0=0;memcpy(&v0,&dg_wire_message->args[1],sizeof(v0));
    typedef void (*Proc)(GLint location, GLint v0);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform1iARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,v0);
    return 0;
}
case 607: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLint v0=0;memcpy(&v0,&dg_wire_message->args[1],sizeof(v0));
    GLint v1=0;memcpy(&v1,&dg_wire_message->args[2],sizeof(v1));
    typedef void (*Proc)(GLint location, GLint v0, GLint v1);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform2iARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,v0,v1);
    return 0;
}
case 608: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLint v0=0;memcpy(&v0,&dg_wire_message->args[1],sizeof(v0));
    GLint v1=0;memcpy(&v1,&dg_wire_message->args[2],sizeof(v1));
    GLint v2=0;memcpy(&v2,&dg_wire_message->args[3],sizeof(v2));
    typedef void (*Proc)(GLint location, GLint v0, GLint v1, GLint v2);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform3iARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,v0,v1,v2);
    return 0;
}
case 609: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLint v0=0;memcpy(&v0,&dg_wire_message->args[1],sizeof(v0));
    GLint v1=0;memcpy(&v1,&dg_wire_message->args[2],sizeof(v1));
    GLint v2=0;memcpy(&v2,&dg_wire_message->args[3],sizeof(v2));
    GLint v3=0;memcpy(&v3,&dg_wire_message->args[4],sizeof(v3));
    typedef void (*Proc)(GLint location, GLint v0, GLint v1, GLint v2, GLint v3);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform4iARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,v0,v1,v2,v3);
    return 0;
}
case 610: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    const GLfloat * value=NULL;
    value=(const GLfloat *)DGHostPointer(dg_wire_message,2,(DGArrayBytes(count,1*sizeof(GLfloat))));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, const GLfloat *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform1fvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,value);
    return 0;
}
case 611: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    const GLfloat * value=NULL;
    value=(const GLfloat *)DGHostPointer(dg_wire_message,2,(DGArrayBytes(count,2*sizeof(GLfloat))));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, const GLfloat *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform2fvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,value);
    return 0;
}
case 612: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    const GLfloat * value=NULL;
    value=(const GLfloat *)DGHostPointer(dg_wire_message,2,(DGArrayBytes(count,3*sizeof(GLfloat))));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, const GLfloat *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform3fvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,value);
    return 0;
}
case 613: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    const GLfloat * value=NULL;
    value=(const GLfloat *)DGHostPointer(dg_wire_message,2,(DGArrayBytes(count,4*sizeof(GLfloat))));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, const GLfloat *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform4fvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,value);
    return 0;
}
case 614: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    const GLint * value=NULL;
    value=(const GLint *)DGHostPointer(dg_wire_message,2,(DGArrayBytes(count,1*sizeof(GLint))));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, const GLint *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform1ivARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,value);
    return 0;
}
case 615: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    const GLint * value=NULL;
    value=(const GLint *)DGHostPointer(dg_wire_message,2,(DGArrayBytes(count,2*sizeof(GLint))));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, const GLint *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform2ivARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,value);
    return 0;
}
case 616: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    const GLint * value=NULL;
    value=(const GLint *)DGHostPointer(dg_wire_message,2,(DGArrayBytes(count,3*sizeof(GLint))));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, const GLint *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform3ivARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,value);
    return 0;
}
case 617: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    const GLint * value=NULL;
    value=(const GLint *)DGHostPointer(dg_wire_message,2,(DGArrayBytes(count,4*sizeof(GLint))));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, const GLint *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform4ivARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,value);
    return 0;
}
case 618: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[2],sizeof(transpose));
    const GLfloat * value=NULL;
    value=(const GLfloat *)DGHostPointer(dg_wire_message,3,(DGArrayBytes(count,4*sizeof(GLfloat))));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniformMatrix2fvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,transpose,value);
    return 0;
}
case 619: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[2],sizeof(transpose));
    const GLfloat * value=NULL;
    value=(const GLfloat *)DGHostPointer(dg_wire_message,3,(DGArrayBytes(count,9*sizeof(GLfloat))));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniformMatrix3fvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,transpose,value);
    return 0;
}
case 620: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[2],sizeof(transpose));
    const GLfloat * value=NULL;
    value=(const GLfloat *)DGHostPointer(dg_wire_message,3,(DGArrayBytes(count,16*sizeof(GLfloat))));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniformMatrix4fvARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,transpose,value);
    return 0;
}
case 621: {
    GLhandleARB obj=0;memcpy(&obj,&dg_wire_message->args[0],sizeof(obj));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLfloat * params=NULL;
    params=(GLfloat *)DGHostPointer(dg_wire_message,2,((sizeof(GLfloat)) ? (sizeof(GLfloat)) : 1));
    if(!params) return -1;
    glGetObjectParameterfvARB(obj,pname,params);
    return 0;
}
case 622: {
    GLhandleARB obj=0;memcpy(&obj,&dg_wire_message->args[0],sizeof(obj));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint * params=NULL;
    params=(GLint *)DGHostPointer(dg_wire_message,2,((sizeof(GLint)) ? (sizeof(GLint)) : 1));
    if(!params) return -1;
    glGetObjectParameterivARB(obj,pname,params);
    return 0;
}
case 623: {
    GLhandleARB obj=0;memcpy(&obj,&dg_wire_message->args[0],sizeof(obj));
    GLsizei maxLength=0;memcpy(&maxLength,&dg_wire_message->args[1],sizeof(maxLength));
    GLsizei * length=NULL;
    GLcharARB * infoLog=NULL;
    length=(GLsizei *)DGHostPointer(dg_wire_message,2,((sizeof(GLsizei)) ? (sizeof(GLsizei)) : 1));
    if(dg_wire_message->args[2] && !length) return -1;
    infoLog=(GLcharARB *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(maxLength,1)) ? (DGQueryArrayBytes(maxLength,1)) : 1));
    if(!infoLog) return -1;
    glGetInfoLogARB(obj,maxLength,length,infoLog);
    return 0;
}
case 625: {
    GLhandleARB programObj=0;memcpy(&programObj,&dg_wire_message->args[0],sizeof(programObj));
    const GLcharARB * name=DGHostString(dg_wire_message,1);if(!name) return -1;
    DGHostUniformLocation(context,(GLuint)(uintptr_t)programObj,name,reply);
    return 0;
}
case 626: {
    GLhandleARB programObj=0;memcpy(&programObj,&dg_wire_message->args[0],sizeof(programObj));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    GLsizei maxLength=0;memcpy(&maxLength,&dg_wire_message->args[2],sizeof(maxLength));
    GLsizei * length=NULL;
    GLint * size=NULL;
    GLenum * type=NULL;
    GLcharARB * name=NULL;
    length=(GLsizei *)DGHostPointer(dg_wire_message,3,((sizeof(GLsizei)) ? (sizeof(GLsizei)) : 1));
    if(dg_wire_message->args[3] && !length) return -1;
    size=(GLint *)DGHostPointer(dg_wire_message,4,((sizeof(GLint)) ? (sizeof(GLint)) : 1));
    if(!size) return -1;
    type=(GLenum *)DGHostPointer(dg_wire_message,5,((sizeof(GLenum)) ? (sizeof(GLenum)) : 1));
    if(!type) return -1;
    name=(GLcharARB *)DGHostPointer(dg_wire_message,6,((DGQueryArrayBytes(maxLength,1)) ? (DGQueryArrayBytes(maxLength,1)) : 1));
    if(!name) return -1;
    glGetActiveUniformARB(programObj,index,maxLength,length,size,type,name);
    return 0;
}
case 629: {
    GLhandleARB obj=0;memcpy(&obj,&dg_wire_message->args[0],sizeof(obj));
    GLsizei maxLength=0;memcpy(&maxLength,&dg_wire_message->args[1],sizeof(maxLength));
    GLsizei * length=NULL;
    GLcharARB * source=NULL;
    length=(GLsizei *)DGHostPointer(dg_wire_message,2,((sizeof(GLsizei)) ? (sizeof(GLsizei)) : 1));
    if(dg_wire_message->args[2] && !length) return -1;
    source=(GLcharARB *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(maxLength,1)) ? (DGQueryArrayBytes(maxLength,1)) : 1));
    if(!source) return -1;
    glGetShaderSourceARB(obj,maxLength,length,source);
    return 0;
}
case 630: {
    GLhandleARB programObj=0;memcpy(&programObj,&dg_wire_message->args[0],sizeof(programObj));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    const GLcharARB * name=DGHostString(dg_wire_message,2);if(!name) return -1;
    glBindAttribLocation((GLuint)(uintptr_t)programObj,index,name);
    return 0;
}
case 631: {
    GLhandleARB programObj=0;memcpy(&programObj,&dg_wire_message->args[0],sizeof(programObj));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    GLsizei maxLength=0;memcpy(&maxLength,&dg_wire_message->args[2],sizeof(maxLength));
    GLsizei * length=NULL;
    GLint * size=NULL;
    GLenum * type=NULL;
    GLcharARB * name=NULL;
    length=(GLsizei *)DGHostPointer(dg_wire_message,3,((sizeof(GLsizei)) ? (sizeof(GLsizei)) : 1));
    if(dg_wire_message->args[3] && !length) return -1;
    size=(GLint *)DGHostPointer(dg_wire_message,4,((sizeof(GLint)) ? (sizeof(GLint)) : 1));
    if(!size) return -1;
    type=(GLenum *)DGHostPointer(dg_wire_message,5,((sizeof(GLenum)) ? (sizeof(GLenum)) : 1));
    if(!type) return -1;
    name=(GLcharARB *)DGHostPointer(dg_wire_message,6,((DGQueryArrayBytes(maxLength,1)) ? (DGQueryArrayBytes(maxLength,1)) : 1));
    if(!name) return -1;
    glGetActiveAttribARB(programObj,index,maxLength,length,size,type,name);
    return 0;
}
case 632: {
    GLhandleARB programObj=0;memcpy(&programObj,&dg_wire_message->args[0],sizeof(programObj));
    const GLcharARB * name=DGHostString(dg_wire_message,1);if(!name) return -1;
    GLint result=glGetAttribLocation((GLuint)(uintptr_t)programObj,name);reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 633: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum clamp=0;memcpy(&clamp,&dg_wire_message->args[1],sizeof(clamp));
    typedef void (*Proc)(GLenum target, GLenum clamp);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glClampColorARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,clamp);
    return 0;
}
case 634: {
    GLsizei n=0;memcpy(&n,&dg_wire_message->args[0],sizeof(n));
    GLuint * ids=NULL;
    ids=(GLuint *)DGHostPointer(dg_wire_message,1,((DGQueryArrayBytes(n,sizeof(GLuint))) ? (DGQueryArrayBytes(n,sizeof(GLuint))) : 1));
    if(!ids) return -1;
    typedef void (*Proc)(GLsizei n, GLuint *ids);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGenQueries");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(n,ids);
    return 0;
}
case 635: {
    GLsizei n=0;memcpy(&n,&dg_wire_message->args[0],sizeof(n));
    const GLuint * ids=NULL;
    ids=(const GLuint *)DGHostPointer(dg_wire_message,1,((DGQueryArrayBytes(n,sizeof(GLuint))) ? (DGQueryArrayBytes(n,sizeof(GLuint))) : 1));
    if(!ids) return -1;
    typedef void (*Proc)(GLsizei n, const GLuint *ids);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glDeleteQueries");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(n,ids);
    return 0;
}
case 636: {
    GLuint id=0;memcpy(&id,&dg_wire_message->args[0],sizeof(id));
    typedef GLboolean (*Proc)(GLuint id);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glIsQuery");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLboolean result=proc(id);
    reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 637: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint id=0;memcpy(&id,&dg_wire_message->args[1],sizeof(id));
    typedef void (*Proc)(GLenum target, GLuint id);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glBeginQuery");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,id);
    return 0;
}
case 638: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    typedef void (*Proc)(GLenum target);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glEndQuery");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target);
    return 0;
}
case 639: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint * params=NULL;
    params=(GLint *)DGHostPointer(dg_wire_message,2,((sizeof(GLint)) ? (sizeof(GLint)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLenum pname, GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetQueryiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,pname,params);
    return 0;
}
case 640: {
    GLuint id=0;memcpy(&id,&dg_wire_message->args[0],sizeof(id));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint * params=NULL;
    params=(GLint *)DGHostPointer(dg_wire_message,2,((sizeof(GLint)) ? (sizeof(GLint)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLuint id, GLenum pname, GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetQueryObjectiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(id,pname,params);
    return 0;
}
case 641: {
    GLuint id=0;memcpy(&id,&dg_wire_message->args[0],sizeof(id));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLuint * params=NULL;
    params=(GLuint *)DGHostPointer(dg_wire_message,2,((sizeof(GLuint)) ? (sizeof(GLuint)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLuint id, GLenum pname, GLuint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetQueryObjectuiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(id,pname,params);
    return 0;
}
case 642: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint buffer=0;memcpy(&buffer,&dg_wire_message->args[1],sizeof(buffer));
    typedef void (*Proc)(GLenum target, GLuint buffer);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glBindBuffer");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,buffer);
    return 0;
}
case 643: {
    GLsizei n=0;memcpy(&n,&dg_wire_message->args[0],sizeof(n));
    const GLuint * buffers=NULL;
    buffers=(const GLuint *)DGHostPointer(dg_wire_message,1,(DGArrayBytes(n,sizeof(GLuint))));
    if(!buffers) return -1;
    typedef void (*Proc)(GLsizei n, const GLuint *buffers);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glDeleteBuffers");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(n,buffers);
    return 0;
}
case 644: {
    GLsizei n=0;memcpy(&n,&dg_wire_message->args[0],sizeof(n));
    GLuint * buffers=NULL;
    buffers=(GLuint *)DGHostPointer(dg_wire_message,1,((DGQueryArrayBytes(n,sizeof(GLuint))) ? (DGQueryArrayBytes(n,sizeof(GLuint))) : 1));
    if(!buffers) return -1;
    typedef void (*Proc)(GLsizei n, GLuint *buffers);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGenBuffers");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(n,buffers);
    return 0;
}
case 645: {
    GLuint buffer=0;memcpy(&buffer,&dg_wire_message->args[0],sizeof(buffer));
    typedef GLboolean (*Proc)(GLuint buffer);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glIsBuffer");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLboolean result=proc(buffer);
    reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 646: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLsizeiptrARB size=(GLsizeiptrARB)(int64_t)dg_wire_message->args[1];
    const GLvoid * data=NULL;
    GLenum usage=0;memcpy(&usage,&dg_wire_message->args[3],sizeof(usage));
    data=(const GLvoid *)DGHostPointer(dg_wire_message,2,(DGArrayBytes(size,1)));
    if(dg_wire_message->args[2] && !data) return -1;
    typedef void (*Proc)(GLenum target, GLsizeiptrARB size, const GLvoid *data, GLenum usage);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glBufferData");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,size,data,usage);
    DGPBOWritten(context);
    return 0;
}
case 647: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLintptrARB offset=(GLintptrARB)(int64_t)dg_wire_message->args[1];
    GLsizeiptrARB size=(GLsizeiptrARB)(int64_t)dg_wire_message->args[2];
    const GLvoid * data=NULL;
    data=(const GLvoid *)DGHostPointer(dg_wire_message,3,(DGArrayBytes(size,1)));
    if((size && !data) || (dg_wire_message->args[3] && !data)) return -1;
    typedef void (*Proc)(GLenum target, GLintptrARB offset, GLsizeiptrARB size, const GLvoid *data);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glBufferSubData");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,offset,size,data);
    DGPBOWritten(context);
    return 0;
}
case 653: {
    GLclampd zmin=0;memcpy(&zmin,&dg_wire_message->args[0],sizeof(zmin));
    GLclampd zmax=0;memcpy(&zmax,&dg_wire_message->args[1],sizeof(zmax));
    typedef void (*Proc)(GLclampd zmin, GLclampd zmax);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glDepthBoundsEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(zmin,zmax);
    return 0;
}
case 654: {
    GLsizei n=0;memcpy(&n,&dg_wire_message->args[0],sizeof(n));
    const GLenum * bufs=NULL;
    bufs=(const GLenum *)DGHostPointer(dg_wire_message,1,((DGQueryArrayBytes(n,sizeof(GLenum))) ? (DGQueryArrayBytes(n,sizeof(GLenum))) : 1));
    if(!bufs) return -1;
    DGSetDrawBuffers(context,n,bufs);
    return 0;
}
case 655: {
    GLuint shader=0;memcpy(&shader,&dg_wire_message->args[0],sizeof(shader));
    typedef GLboolean (*Proc)(GLuint shader);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glIsShader");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLboolean result=proc(shader);
    reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 656: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    typedef GLboolean (*Proc)(GLuint program);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glIsProgram");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLboolean result=proc(program);
    reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 657: {
    GLuint shader=0;memcpy(&shader,&dg_wire_message->args[0],sizeof(shader));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint * params=NULL;
    if(!DGParameterCount(pname) && dg_wire_message->bytes==1 && dg_wire_message->args[2]==1) { if(!context->error)context->error=context->inside_begin?GL_INVALID_OPERATION:GL_INVALID_ENUM;return 0; }
    params=(GLint *)DGHostPointer(dg_wire_message,2,((sizeof(GLint)) ? (sizeof(GLint)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLuint shader, GLenum pname, GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetShaderiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(shader,pname,params);
    return 0;
}
case 658: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint * params=NULL;
    if(!DGParameterCount(pname) && dg_wire_message->bytes==1 && dg_wire_message->args[2]==1) { if(!context->error)context->error=context->inside_begin?GL_INVALID_OPERATION:GL_INVALID_ENUM;return 0; }
    params=(GLint *)DGHostPointer(dg_wire_message,2,(((pname==0x8267 ? 3 : 1)*sizeof(GLint)) ? ((pname==0x8267 ? 3 : 1)*sizeof(GLint)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLuint program, GLenum pname, GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetProgramiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,pname,params);
    return 0;
}
case 659: {
    GLuint shader=0;memcpy(&shader,&dg_wire_message->args[0],sizeof(shader));
    GLsizei bufSize=0;memcpy(&bufSize,&dg_wire_message->args[1],sizeof(bufSize));
    GLsizei * length=NULL;
    GLchar * infoLog=NULL;
    length=(GLsizei *)DGHostPointer(dg_wire_message,2,((sizeof(GLsizei)) ? (sizeof(GLsizei)) : 1));
    if(dg_wire_message->args[2] && !length) return -1;
    infoLog=(GLchar *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(bufSize,1)) ? (DGQueryArrayBytes(bufSize,1)) : 1));
    if(!infoLog) return -1;
    typedef void (*Proc)(GLuint shader, GLsizei bufSize, GLsizei *length, GLchar *infoLog);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetShaderInfoLog");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(shader,bufSize,length,infoLog);
    return 0;
}
case 660: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLsizei bufSize=0;memcpy(&bufSize,&dg_wire_message->args[1],sizeof(bufSize));
    GLsizei * length=NULL;
    GLchar * infoLog=NULL;
    length=(GLsizei *)DGHostPointer(dg_wire_message,2,((sizeof(GLsizei)) ? (sizeof(GLsizei)) : 1));
    if(dg_wire_message->args[2] && !length) return -1;
    infoLog=(GLchar *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(bufSize,1)) ? (DGQueryArrayBytes(bufSize,1)) : 1));
    if(!infoLog) return -1;
    typedef void (*Proc)(GLuint program, GLsizei bufSize, GLsizei *length, GLchar *infoLog);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetProgramInfoLog");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,bufSize,length,infoLog);
    return 0;
}
case 661: {
    GLenum face=0;memcpy(&face,&dg_wire_message->args[0],sizeof(face));
    GLenum func=0;memcpy(&func,&dg_wire_message->args[1],sizeof(func));
    GLint ref=0;memcpy(&ref,&dg_wire_message->args[2],sizeof(ref));
    GLuint mask=0;memcpy(&mask,&dg_wire_message->args[3],sizeof(mask));
    typedef void (*Proc)(GLenum face, GLenum func, GLint ref, GLuint mask);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glStencilFuncSeparate");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(face,func,ref,mask);
    return 0;
}
case 662: {
    GLenum face=0;memcpy(&face,&dg_wire_message->args[0],sizeof(face));
    GLuint mask=0;memcpy(&mask,&dg_wire_message->args[1],sizeof(mask));
    typedef void (*Proc)(GLenum face, GLuint mask);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glStencilMaskSeparate");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(face,mask);
    return 0;
}
case 665: {
    GLuint renderbuffer=0;memcpy(&renderbuffer,&dg_wire_message->args[0],sizeof(renderbuffer));
    typedef GLboolean (*Proc)(GLuint renderbuffer);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glIsRenderbufferEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLboolean result=proc(renderbuffer);
    reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 666: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint renderbuffer=0;memcpy(&renderbuffer,&dg_wire_message->args[1],sizeof(renderbuffer));
    typedef void (*Proc)(GLenum target, GLuint renderbuffer);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glBindRenderbufferEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,renderbuffer);
    return 0;
}
case 667: {
    GLsizei n=0;memcpy(&n,&dg_wire_message->args[0],sizeof(n));
    const GLuint * renderbuffers=NULL;
    renderbuffers=(const GLuint *)DGHostPointer(dg_wire_message,1,(DGArrayBytes(n,sizeof(GLuint))));
    if(!renderbuffers) return -1;
    typedef void (*Proc)(GLsizei n, const GLuint *renderbuffers);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glDeleteRenderbuffersEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(n,renderbuffers);
    return 0;
}
case 668: {
    GLsizei n=0;memcpy(&n,&dg_wire_message->args[0],sizeof(n));
    GLuint * renderbuffers=NULL;
    renderbuffers=(GLuint *)DGHostPointer(dg_wire_message,1,((DGQueryArrayBytes(n,sizeof(GLuint))) ? (DGQueryArrayBytes(n,sizeof(GLuint))) : 1));
    if(!renderbuffers) return -1;
    typedef void (*Proc)(GLsizei n, GLuint *renderbuffers);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGenRenderbuffersEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(n,renderbuffers);
    return 0;
}
case 669: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum internalformat=0;memcpy(&internalformat,&dg_wire_message->args[1],sizeof(internalformat));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[2],sizeof(width));
    GLsizei height=0;memcpy(&height,&dg_wire_message->args[3],sizeof(height));
    typedef void (*Proc)(GLenum target, GLenum internalformat, GLsizei width, GLsizei height);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRenderbufferStorageEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,internalformat,width,height);
    return 0;
}
case 670: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint * params=NULL;
    if(!DGParameterCount(pname) && dg_wire_message->bytes==1 && dg_wire_message->args[2]==1) { if(!context->error)context->error=context->inside_begin?GL_INVALID_OPERATION:GL_INVALID_ENUM;return 0; }
    params=(GLint *)DGHostPointer(dg_wire_message,2,((sizeof(GLint)) ? (sizeof(GLint)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLenum pname, GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetRenderbufferParameterivEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,pname,params);
    return 0;
}
case 671: {
    GLuint framebuffer=0;memcpy(&framebuffer,&dg_wire_message->args[0],sizeof(framebuffer));
    typedef GLboolean (*Proc)(GLuint framebuffer);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glIsFramebufferEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLboolean result=proc(framebuffer);
    reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 672: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint framebuffer=0;memcpy(&framebuffer,&dg_wire_message->args[1],sizeof(framebuffer));
    glBindFramebufferEXT(target,framebuffer ? framebuffer : context->framebuffer);
    if(target!=GL_READ_FRAMEBUFFER_EXT)context->iosurface_draw_dirty=1;
    return 0;
}
case 673: {
    GLsizei n=0;memcpy(&n,&dg_wire_message->args[0],sizeof(n));
    const GLuint * framebuffers=NULL;
    framebuffers=(const GLuint *)DGHostPointer(dg_wire_message,1,(DGArrayBytes(n,sizeof(GLuint))));
    if(!framebuffers) return -1;
    typedef void (*Proc)(GLsizei n, const GLuint *framebuffers);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glDeleteFramebuffersEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(n,framebuffers);
    context->iosurface_draw_dirty=1;
    return 0;
}
case 674: {
    GLsizei n=0;memcpy(&n,&dg_wire_message->args[0],sizeof(n));
    GLuint * framebuffers=NULL;
    framebuffers=(GLuint *)DGHostPointer(dg_wire_message,1,((DGQueryArrayBytes(n,sizeof(GLuint))) ? (DGQueryArrayBytes(n,sizeof(GLuint))) : 1));
    if(!framebuffers) return -1;
    typedef void (*Proc)(GLsizei n, GLuint *framebuffers);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGenFramebuffersEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(n,framebuffers);
    return 0;
}
case 675: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    typedef GLenum (*Proc)(GLenum target);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glCheckFramebufferStatusEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLenum result=proc(target);
    reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 676: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum attachment=0;memcpy(&attachment,&dg_wire_message->args[1],sizeof(attachment));
    GLenum textarget=0;memcpy(&textarget,&dg_wire_message->args[2],sizeof(textarget));
    GLuint texture=0;memcpy(&texture,&dg_wire_message->args[3],sizeof(texture));
    GLint level=0;memcpy(&level,&dg_wire_message->args[4],sizeof(level));
    typedef void (*Proc)(GLenum target, GLenum attachment, GLenum textarget, GLuint texture, GLint level);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glFramebufferTexture1DEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    if(!context->inside_begin && texture && DGPrivateTextureContains(context->alias_group->private_textures,texture)){context->error=GL_INVALID_OPERATION;return 0;}
    proc(target,attachment,textarget,texture,level);
    context->iosurface_draw_dirty=1;
    return 0;
}
case 677: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum attachment=0;memcpy(&attachment,&dg_wire_message->args[1],sizeof(attachment));
    GLenum textarget=0;memcpy(&textarget,&dg_wire_message->args[2],sizeof(textarget));
    GLuint texture=0;memcpy(&texture,&dg_wire_message->args[3],sizeof(texture));
    GLint level=0;memcpy(&level,&dg_wire_message->args[4],sizeof(level));
    typedef void (*Proc)(GLenum target, GLenum attachment, GLenum textarget, GLuint texture, GLint level);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glFramebufferTexture2DEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    if(!context->inside_begin && texture && DGPrivateTextureContains(context->alias_group->private_textures,texture)){context->error=GL_INVALID_OPERATION;return 0;}
    proc(target,attachment,textarget,texture,level);
    context->iosurface_draw_dirty=1;
    return 0;
}
case 678: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum attachment=0;memcpy(&attachment,&dg_wire_message->args[1],sizeof(attachment));
    GLenum textarget=0;memcpy(&textarget,&dg_wire_message->args[2],sizeof(textarget));
    GLuint texture=0;memcpy(&texture,&dg_wire_message->args[3],sizeof(texture));
    GLint level=0;memcpy(&level,&dg_wire_message->args[4],sizeof(level));
    GLint zoffset=0;memcpy(&zoffset,&dg_wire_message->args[5],sizeof(zoffset));
    typedef void (*Proc)(GLenum target, GLenum attachment, GLenum textarget, GLuint texture, GLint level, GLint zoffset);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glFramebufferTexture3DEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    if(!context->inside_begin && texture && DGPrivateTextureContains(context->alias_group->private_textures,texture)){context->error=GL_INVALID_OPERATION;return 0;}
    proc(target,attachment,textarget,texture,level,zoffset);
    context->iosurface_draw_dirty=1;
    return 0;
}
case 679: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum attachment=0;memcpy(&attachment,&dg_wire_message->args[1],sizeof(attachment));
    GLenum renderbuffertarget=0;memcpy(&renderbuffertarget,&dg_wire_message->args[2],sizeof(renderbuffertarget));
    GLuint renderbuffer=0;memcpy(&renderbuffer,&dg_wire_message->args[3],sizeof(renderbuffer));
    typedef void (*Proc)(GLenum target, GLenum attachment, GLenum renderbuffertarget, GLuint renderbuffer);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glFramebufferRenderbufferEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,attachment,renderbuffertarget,renderbuffer);
    context->iosurface_draw_dirty=1;
    return 0;
}
case 680: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum attachment=0;memcpy(&attachment,&dg_wire_message->args[1],sizeof(attachment));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[2],sizeof(pname));
    GLint * params=NULL;
    if(!DGParameterCount(pname) && dg_wire_message->bytes==1 && dg_wire_message->args[3]==1) { if(!context->error)context->error=context->inside_begin?GL_INVALID_OPERATION:GL_INVALID_ENUM;return 0; }
    params=(GLint *)DGHostPointer(dg_wire_message,3,((sizeof(GLint)) ? (sizeof(GLint)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLenum attachment, GLenum pname, GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetFramebufferAttachmentParameterivEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,attachment,pname,params);
    return 0;
}
case 681: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    DGHostGenerateMipmap(context,target);
    return 0;
}
case 682: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint param=0;memcpy(&param,&dg_wire_message->args[2],sizeof(param));
    typedef void (*Proc)(GLenum target, GLenum pname, GLint param);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glBufferParameteriAPPLE");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,pname,param);
    return 0;
}
case 684: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    const GLfloat * params=NULL;
    params=(const GLfloat *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(count,4*sizeof(GLfloat))) ? (DGQueryArrayBytes(count,4*sizeof(GLfloat))) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLuint index, GLsizei count, const GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramEnvParameters4fvEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,index,count,params);
    return 0;
}
case 685: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    const GLfloat * params=NULL;
    params=(const GLfloat *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(count,4*sizeof(GLfloat))) ? (DGQueryArrayBytes(count,4*sizeof(GLfloat))) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLuint index, GLsizei count, const GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramLocalParameters4fvEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,index,count,params);
    return 0;
}
case 686: {
    GLenum objectType=0;memcpy(&objectType,&dg_wire_message->args[0],sizeof(objectType));
    GLuint name=0;memcpy(&name,&dg_wire_message->args[1],sizeof(name));
    GLenum option=0;memcpy(&option,&dg_wire_message->args[2],sizeof(option));
    if(context->inside_begin || !DGHostPurgeableSupported(context)) { if(!context->error)context->error=GL_INVALID_OPERATION;return 0; }
    if(DGPurgeablePrivateName(context,objectType,name)) { if(!context->error)context->error=GL_INVALID_VALUE;return 0; }
    typedef GLenum (*Proc)(GLenum objectType, GLuint name, GLenum option);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glObjectPurgeableAPPLE");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLenum result=proc(objectType,name,option);
    reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 687: {
    GLenum objectType=0;memcpy(&objectType,&dg_wire_message->args[0],sizeof(objectType));
    GLuint name=0;memcpy(&name,&dg_wire_message->args[1],sizeof(name));
    GLenum option=0;memcpy(&option,&dg_wire_message->args[2],sizeof(option));
    if(context->inside_begin || !DGHostPurgeableSupported(context)) { if(!context->error)context->error=GL_INVALID_OPERATION;return 0; }
    if(DGPurgeablePrivateName(context,objectType,name)) { if(!context->error)context->error=GL_INVALID_VALUE;return 0; }
    typedef GLenum (*Proc)(GLenum objectType, GLuint name, GLenum option);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glObjectUnpurgeableAPPLE");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLenum result=proc(objectType,name,option);
    reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 688: {
    GLenum objectType=0;memcpy(&objectType,&dg_wire_message->args[0],sizeof(objectType));
    GLuint name=0;memcpy(&name,&dg_wire_message->args[1],sizeof(name));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[2],sizeof(pname));
    GLint* params=NULL;
    params=(GLint*)DGHostPointer(dg_wire_message,3,((sizeof(GLint)) ? (sizeof(GLint)) : 1));
    if(!params) return -1;
    if(context->inside_begin || !DGHostPurgeableSupported(context)) { if(!context->error)context->error=GL_INVALID_OPERATION;return 0; }
    if(DGPurgeablePrivateName(context,objectType,name)) { if(!context->error)context->error=GL_INVALID_VALUE;return 0; }
    typedef void (*Proc)(GLenum objectType, GLuint name, GLenum pname, GLint* params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetObjectParameterivAPPLE");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(objectType,name,pname,params);
    return 0;
}
case 689: {
    GLuint program_name=0;memcpy(&program_name,&dg_wire_message->args[0],sizeof(program_name));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint value=0;memcpy(&value,&dg_wire_message->args[2],sizeof(value));
    typedef void (*Proc)(GLuint program_name, GLenum pname, GLint value);
    static Proc core,ext;Proc proc;
    if(pname==0x8258 || pname==0x8257) { if(!core)core=(Proc)dlsym(RTLD_DEFAULT,"glProgramParameteri");proc=core; }
    else { if(!ext)ext=(Proc)dlsym(RTLD_DEFAULT,"glProgramParameteriEXT");proc=ext; }
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program_name,pname,value);
    return 0;
}
case 690: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum attachment=0;memcpy(&attachment,&dg_wire_message->args[1],sizeof(attachment));
    GLuint texture=0;memcpy(&texture,&dg_wire_message->args[2],sizeof(texture));
    GLint level=0;memcpy(&level,&dg_wire_message->args[3],sizeof(level));
    typedef void (*Proc)(GLenum target, GLenum attachment, GLuint texture, GLint level);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glFramebufferTextureEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    if(!context->inside_begin && texture && DGPrivateTextureContains(context->alias_group->private_textures,texture)){context->error=GL_INVALID_OPERATION;return 0;}
    proc(target,attachment,texture,level);
    context->iosurface_draw_dirty=1;
    return 0;
}
case 691: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum attachment=0;memcpy(&attachment,&dg_wire_message->args[1],sizeof(attachment));
    GLuint texture=0;memcpy(&texture,&dg_wire_message->args[2],sizeof(texture));
    GLint level=0;memcpy(&level,&dg_wire_message->args[3],sizeof(level));
    GLint layer=0;memcpy(&layer,&dg_wire_message->args[4],sizeof(layer));
    typedef void (*Proc)(GLenum target, GLenum attachment, GLuint texture, GLint level, GLint layer);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glFramebufferTextureLayerEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    if(!context->inside_begin && texture && DGPrivateTextureContains(context->alias_group->private_textures,texture)){context->error=GL_INVALID_OPERATION;return 0;}
    proc(target,attachment,texture,level,layer);
    context->iosurface_draw_dirty=1;
    return 0;
}
case 692: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum attachment=0;memcpy(&attachment,&dg_wire_message->args[1],sizeof(attachment));
    GLuint texture=0;memcpy(&texture,&dg_wire_message->args[2],sizeof(texture));
    GLint level=0;memcpy(&level,&dg_wire_message->args[3],sizeof(level));
    GLenum face=0;memcpy(&face,&dg_wire_message->args[4],sizeof(face));
    typedef void (*Proc)(GLenum target, GLenum attachment, GLuint texture, GLint level, GLenum face);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glFramebufferTextureFaceEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    if(!context->inside_begin && texture && DGPrivateTextureContains(context->alias_group->private_textures,texture)){context->error=GL_INVALID_OPERATION;return 0;}
    proc(target,attachment,texture,level,face);
    context->iosurface_draw_dirty=1;
    return 0;
}
case 693: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    GLuint buffer=0;memcpy(&buffer,&dg_wire_message->args[2],sizeof(buffer));
    GLintptr offset=(GLintptr)(int64_t)dg_wire_message->args[3];
    GLsizeiptr size=(GLsizeiptr)(int64_t)dg_wire_message->args[4];
    typedef void (*Proc)(GLenum target, GLuint index, GLuint buffer, GLintptr offset, GLsizeiptr size);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glBindBufferRangeEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,index,buffer,offset,size);
    return 0;
}
case 694: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    GLuint buffer=0;memcpy(&buffer,&dg_wire_message->args[2],sizeof(buffer));
    GLintptr offset=(GLintptr)(int64_t)dg_wire_message->args[3];
    typedef void (*Proc)(GLenum target, GLuint index, GLuint buffer, GLintptr offset);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glBindBufferOffsetEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,index,buffer,offset);
    return 0;
}
case 695: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    GLuint buffer=0;memcpy(&buffer,&dg_wire_message->args[2],sizeof(buffer));
    typedef void (*Proc)(GLenum target, GLuint index, GLuint buffer);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glBindBufferBaseEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,index,buffer);
    return 0;
}
case 696: {
    GLenum primitiveMode=0;memcpy(&primitiveMode,&dg_wire_message->args[0],sizeof(primitiveMode));
    typedef void (*Proc)(GLenum primitiveMode);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glBeginTransformFeedbackEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(primitiveMode);
    return 0;
}
case 697: {
    typedef void (*Proc)(void);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glEndTransformFeedbackEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc();
    return 0;
}
case 698: return DGHostFeedbackVaryings(context,dg_wire_message);
case 699: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    GLsizei bufSize=0;memcpy(&bufSize,&dg_wire_message->args[2],sizeof(bufSize));
    GLsizei * length=NULL;
    GLsizei * size=NULL;
    GLenum * type=NULL;
    GLchar * name=NULL;
    length=(GLsizei *)DGHostPointer(dg_wire_message,3,((sizeof(GLsizei)) ? (sizeof(GLsizei)) : 1));
    if(dg_wire_message->args[3] && !length) return -1;
    size=(GLsizei *)DGHostPointer(dg_wire_message,4,((sizeof(GLsizei)) ? (sizeof(GLsizei)) : 1));
    if(!size) return -1;
    type=(GLenum *)DGHostPointer(dg_wire_message,5,((sizeof(GLenum)) ? (sizeof(GLenum)) : 1));
    if(!type) return -1;
    name=(GLchar *)DGHostPointer(dg_wire_message,6,((DGQueryArrayBytes(bufSize,1)) ? (DGQueryArrayBytes(bufSize,1)) : 1));
    if((bufSize>0 && !name) || (dg_wire_message->args[6] && !name)) return -1;
    typedef void (*Proc)(GLuint program, GLuint index, GLsizei bufSize, GLsizei *length, GLsizei *size, GLenum *type, GLchar *name);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetTransformFeedbackVaryingEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,index,bufSize,length,size,type,name);
    return 0;
}
case 700: {
    GLenum param=0;memcpy(&param,&dg_wire_message->args[0],sizeof(param));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    GLint * values=NULL;
    if(!DGIndexedStateCount(param)) return -1;
    values=(GLint *)DGHostPointer(dg_wire_message,2,((DGIndexedStateCount(param)*sizeof(GLint)) ? (DGIndexedStateCount(param)*sizeof(GLint)) : 1));
    if(!values) return -1;
    typedef void (*Proc)(GLenum param, GLuint index, GLint *values);
    static Proc ext,core;Proc proc;
    if((param==GL_SCISSOR_TEST || param==GL_SCISSOR_BOX) && context->profile!=kCGLOGLPVersion_Legacy) { if(!core)core=(Proc)dlsym(RTLD_DEFAULT,"glGetIntegeri_v");proc=core; }
    else { if(!ext)ext=(Proc)dlsym(RTLD_DEFAULT,"glGetIntegerIndexedvEXT");proc=ext; }
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(param,index,values);
    return 0;
}
case 701: {
    GLenum param=0;memcpy(&param,&dg_wire_message->args[0],sizeof(param));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    GLboolean * values=NULL;
    if(!DGIndexedStateCount(param)) return -1;
    values=(GLboolean *)DGHostPointer(dg_wire_message,2,((DGIndexedStateCount(param)*sizeof(GLboolean)) ? (DGIndexedStateCount(param)*sizeof(GLboolean)) : 1));
    if(!values) return -1;
    typedef void (*Proc)(GLenum param, GLuint index, GLboolean *values);
    static Proc ext,core;Proc proc;
    if((param==GL_SCISSOR_TEST || param==GL_SCISSOR_BOX) && context->profile!=kCGLOGLPVersion_Legacy) { if(!core)core=(Proc)dlsym(RTLD_DEFAULT,"glGetBooleani_v");proc=core; }
    else { if(!ext)ext=(Proc)dlsym(RTLD_DEFAULT,"glGetBooleanIndexedvEXT");proc=ext; }
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(param,index,values);
    return 0;
}
case 702: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLuint buffer=0;memcpy(&buffer,&dg_wire_message->args[2],sizeof(buffer));
    typedef void (*Proc)(GLuint program, GLint location, GLuint buffer);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniformBufferEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,buffer);
    return 0;
}
case 703: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    typedef GLint (*Proc)(GLuint program, GLint location);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetUniformBufferSizeEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLint result=proc(program,location);
    reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 704: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    typedef GLintptr (*Proc)(GLuint program, GLint location);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetUniformOffsetEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;reply->result=UINT64_MAX;return 0; }
    GLintptr result=proc(program,location);
    reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 705: {
    GLint r=0;memcpy(&r,&dg_wire_message->args[0],sizeof(r));
    GLint g=0;memcpy(&g,&dg_wire_message->args[1],sizeof(g));
    GLint b=0;memcpy(&b,&dg_wire_message->args[2],sizeof(b));
    GLint a=0;memcpy(&a,&dg_wire_message->args[3],sizeof(a));
    typedef void (*Proc)(GLint r, GLint g, GLint b, GLint a);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glClearColorIiEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(r,g,b,a);
    return 0;
}
case 706: {
    GLuint r=0;memcpy(&r,&dg_wire_message->args[0],sizeof(r));
    GLuint g=0;memcpy(&g,&dg_wire_message->args[1],sizeof(g));
    GLuint b=0;memcpy(&b,&dg_wire_message->args[2],sizeof(b));
    GLuint a=0;memcpy(&a,&dg_wire_message->args[3],sizeof(a));
    typedef void (*Proc)(GLuint r, GLuint g, GLuint b, GLuint a);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glClearColorIuiEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(r,g,b,a);
    return 0;
}
case 707: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint * params=NULL;
    params=(GLint *)DGHostPointer(dg_wire_message,2,((pname==GL_TEXTURE_BORDER_COLOR || pname==0x8e46 ? 4 : 1)*sizeof(GLint)));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLenum pname, GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexParameterIivEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    if(context->profile==kCGLOGLPVersion_Legacy && context->alias_group && pname==GL_TEXTURE_BASE_LEVEL && (params && params[0]!=0))context->alias_group->nonzero_mipmap_base_possible=1;
    proc(target,pname,params);
    return 0;
}
case 708: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLuint * params=NULL;
    params=(GLuint *)DGHostPointer(dg_wire_message,2,((pname==GL_TEXTURE_BORDER_COLOR || pname==0x8e46 ? 4 : 1)*sizeof(GLuint)));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLenum pname, GLuint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexParameterIuivEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    if(context->profile==kCGLOGLPVersion_Legacy && context->alias_group && pname==GL_TEXTURE_BASE_LEVEL && (params && params[0]!=0))context->alias_group->nonzero_mipmap_base_possible=1;
    proc(target,pname,params);
    return 0;
}
case 709: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint * params=NULL;
    params=(GLint *)DGHostPointer(dg_wire_message,2,(((pname==GL_TEXTURE_BORDER_COLOR || pname==0x8e46 ? 4 : 1)*sizeof(GLint)) ? ((pname==GL_TEXTURE_BORDER_COLOR || pname==0x8e46 ? 4 : 1)*sizeof(GLint)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLenum pname, GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetTexParameterIivEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,pname,params);
    return 0;
}
case 710: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLuint * params=NULL;
    params=(GLuint *)DGHostPointer(dg_wire_message,2,(((pname==GL_TEXTURE_BORDER_COLOR || pname==0x8e46 ? 4 : 1)*sizeof(GLuint)) ? ((pname==GL_TEXTURE_BORDER_COLOR || pname==0x8e46 ? 4 : 1)*sizeof(GLuint)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLenum pname, GLuint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetTexParameterIuivEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,pname,params);
    return 0;
}
case 711: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLint x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    typedef void (*Proc)(GLuint index, GLint x);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribI1iEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,x);
    return 0;
}
case 712: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLint x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    GLint y=0;memcpy(&y,&dg_wire_message->args[2],sizeof(y));
    typedef void (*Proc)(GLuint index, GLint x, GLint y);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribI2iEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,x,y);
    return 0;
}
case 713: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLint x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    GLint y=0;memcpy(&y,&dg_wire_message->args[2],sizeof(y));
    GLint z=0;memcpy(&z,&dg_wire_message->args[3],sizeof(z));
    typedef void (*Proc)(GLuint index, GLint x, GLint y, GLint z);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribI3iEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,x,y,z);
    return 0;
}
case 714: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLint x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    GLint y=0;memcpy(&y,&dg_wire_message->args[2],sizeof(y));
    GLint z=0;memcpy(&z,&dg_wire_message->args[3],sizeof(z));
    GLint w=0;memcpy(&w,&dg_wire_message->args[4],sizeof(w));
    typedef void (*Proc)(GLuint index, GLint x, GLint y, GLint z, GLint w);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribI4iEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,x,y,z,w);
    return 0;
}
case 715: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLuint x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    typedef void (*Proc)(GLuint index, GLuint x);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribI1uiEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,x);
    return 0;
}
case 716: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLuint x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    GLuint y=0;memcpy(&y,&dg_wire_message->args[2],sizeof(y));
    typedef void (*Proc)(GLuint index, GLuint x, GLuint y);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribI2uiEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,x,y);
    return 0;
}
case 717: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLuint x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    GLuint y=0;memcpy(&y,&dg_wire_message->args[2],sizeof(y));
    GLuint z=0;memcpy(&z,&dg_wire_message->args[3],sizeof(z));
    typedef void (*Proc)(GLuint index, GLuint x, GLuint y, GLuint z);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribI3uiEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,x,y,z);
    return 0;
}
case 718: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLuint x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    GLuint y=0;memcpy(&y,&dg_wire_message->args[2],sizeof(y));
    GLuint z=0;memcpy(&z,&dg_wire_message->args[3],sizeof(z));
    GLuint w=0;memcpy(&w,&dg_wire_message->args[4],sizeof(w));
    typedef void (*Proc)(GLuint index, GLuint x, GLuint y, GLuint z, GLuint w);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribI4uiEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,x,y,z,w);
    return 0;
}
case 719: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLint * v=NULL;
    v=(const GLint *)DGHostPointer(dg_wire_message,1,(1*sizeof(GLint)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribI1ivEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 720: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLint * v=NULL;
    v=(const GLint *)DGHostPointer(dg_wire_message,1,(2*sizeof(GLint)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribI2ivEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 721: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLint * v=NULL;
    v=(const GLint *)DGHostPointer(dg_wire_message,1,(3*sizeof(GLint)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribI3ivEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 722: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLint * v=NULL;
    v=(const GLint *)DGHostPointer(dg_wire_message,1,(4*sizeof(GLint)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribI4ivEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 723: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLuint * v=NULL;
    v=(const GLuint *)DGHostPointer(dg_wire_message,1,(1*sizeof(GLuint)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLuint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribI1uivEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 724: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLuint * v=NULL;
    v=(const GLuint *)DGHostPointer(dg_wire_message,1,(2*sizeof(GLuint)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLuint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribI2uivEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 725: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLuint * v=NULL;
    v=(const GLuint *)DGHostPointer(dg_wire_message,1,(3*sizeof(GLuint)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLuint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribI3uivEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 726: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLuint * v=NULL;
    v=(const GLuint *)DGHostPointer(dg_wire_message,1,(4*sizeof(GLuint)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLuint *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribI4uivEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 727: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLbyte * v=NULL;
    v=(const GLbyte *)DGHostPointer(dg_wire_message,1,(4*sizeof(GLbyte)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLbyte *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribI4bvEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 728: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLshort * v=NULL;
    v=(const GLshort *)DGHostPointer(dg_wire_message,1,(4*sizeof(GLshort)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLshort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribI4svEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 729: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLubyte * v=NULL;
    v=(const GLubyte *)DGHostPointer(dg_wire_message,1,(4*sizeof(GLubyte)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLubyte *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribI4ubvEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 730: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLushort * v=NULL;
    v=(const GLushort *)DGHostPointer(dg_wire_message,1,(4*sizeof(GLushort)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLushort *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribI4usvEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 732: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint * params=NULL;
    params=(GLint *)DGHostPointer(dg_wire_message,2,((DGVertexAttribCount(pname) ? DGVertexAttribCount(pname)*sizeof(GLint) : SIZE_MAX) ? (DGVertexAttribCount(pname) ? DGVertexAttribCount(pname)*sizeof(GLint) : SIZE_MAX) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLuint index, GLenum pname, GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetVertexAttribIivEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,pname,params);
    return 0;
}
case 733: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLuint * params=NULL;
    params=(GLuint *)DGHostPointer(dg_wire_message,2,((DGVertexAttribCount(pname) ? DGVertexAttribCount(pname)*sizeof(GLuint) : SIZE_MAX) ? (DGVertexAttribCount(pname) ? DGVertexAttribCount(pname)*sizeof(GLuint) : SIZE_MAX) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLuint index, GLenum pname, GLuint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetVertexAttribIuivEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,pname,params);
    return 0;
}
case 734: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLuint v0=0;memcpy(&v0,&dg_wire_message->args[1],sizeof(v0));
    typedef void (*Proc)(GLint location, GLuint v0);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform1uiEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,v0);
    return 0;
}
case 735: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLuint v0=0;memcpy(&v0,&dg_wire_message->args[1],sizeof(v0));
    GLuint v1=0;memcpy(&v1,&dg_wire_message->args[2],sizeof(v1));
    typedef void (*Proc)(GLint location, GLuint v0, GLuint v1);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform2uiEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,v0,v1);
    return 0;
}
case 736: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLuint v0=0;memcpy(&v0,&dg_wire_message->args[1],sizeof(v0));
    GLuint v1=0;memcpy(&v1,&dg_wire_message->args[2],sizeof(v1));
    GLuint v2=0;memcpy(&v2,&dg_wire_message->args[3],sizeof(v2));
    typedef void (*Proc)(GLint location, GLuint v0, GLuint v1, GLuint v2);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform3uiEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,v0,v1,v2);
    return 0;
}
case 737: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLuint v0=0;memcpy(&v0,&dg_wire_message->args[1],sizeof(v0));
    GLuint v1=0;memcpy(&v1,&dg_wire_message->args[2],sizeof(v1));
    GLuint v2=0;memcpy(&v2,&dg_wire_message->args[3],sizeof(v2));
    GLuint v3=0;memcpy(&v3,&dg_wire_message->args[4],sizeof(v3));
    typedef void (*Proc)(GLint location, GLuint v0, GLuint v1, GLuint v2, GLuint v3);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform4uiEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,v0,v1,v2,v3);
    return 0;
}
case 738: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    const GLuint * value=NULL;
    value=(const GLuint *)DGHostPointer(dg_wire_message,2,((count<=0 || location==-1) ? sizeof(GLuint) : DGArrayBytes(count,1*sizeof(GLuint))));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, const GLuint *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform1uivEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,value);
    return 0;
}
case 739: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    const GLuint * value=NULL;
    value=(const GLuint *)DGHostPointer(dg_wire_message,2,((count<=0 || location==-1) ? sizeof(GLuint) : DGArrayBytes(count,2*sizeof(GLuint))));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, const GLuint *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform2uivEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,value);
    return 0;
}
case 740: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    const GLuint * value=NULL;
    value=(const GLuint *)DGHostPointer(dg_wire_message,2,((count<=0 || location==-1) ? sizeof(GLuint) : DGArrayBytes(count,3*sizeof(GLuint))));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, const GLuint *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform3uivEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,value);
    return 0;
}
case 741: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    const GLuint * value=NULL;
    value=(const GLuint *)DGHostPointer(dg_wire_message,2,((count<=0 || location==-1) ? sizeof(GLuint) : DGArrayBytes(count,4*sizeof(GLuint))));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, const GLuint *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform4uivEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,value);
    return 0;
}
case 743: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLuint colorNumber=0;memcpy(&colorNumber,&dg_wire_message->args[1],sizeof(colorNumber));
    const GLchar * name=DGHostString(dg_wire_message,2);if(!name) return -1;
    typedef void (*Proc)(GLuint program, GLuint colorNumber, const GLchar *name);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glBindFragDataLocationEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,colorNumber,name);
    return 0;
}
case 744: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    const GLchar * name=DGHostString(dg_wire_message,1);if(!name) return -1;
    typedef GLint (*Proc)(GLuint program, const GLchar *name);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetFragDataLocationEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLint result=proc(program,name);
    reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 745: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLboolean r=0;memcpy(&r,&dg_wire_message->args[1],sizeof(r));
    GLboolean g=0;memcpy(&g,&dg_wire_message->args[2],sizeof(g));
    GLboolean b=0;memcpy(&b,&dg_wire_message->args[3],sizeof(b));
    GLboolean a=0;memcpy(&a,&dg_wire_message->args[4],sizeof(a));
    typedef void (*Proc)(GLuint index, GLboolean r, GLboolean g, GLboolean b, GLboolean a);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glColorMaskIndexedEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,r,g,b,a);
    return 0;
}
case 746: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    typedef void (*Proc)(GLenum target, GLuint index);
    static Proc ext,core;Proc proc;
    if((target==GL_SCISSOR_TEST || target==GL_SCISSOR_BOX) && context->profile!=kCGLOGLPVersion_Legacy) { if(!core)core=(Proc)dlsym(RTLD_DEFAULT,"glEnablei");proc=core; }
    else { if(!ext)ext=(Proc)dlsym(RTLD_DEFAULT,"glEnableIndexedEXT");proc=ext; }
    if(target==GL_SCISSOR_TEST)context->indexed_scissor=1;
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,index);
    return 0;
}
case 747: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    typedef void (*Proc)(GLenum target, GLuint index);
    static Proc ext,core;Proc proc;
    if((target==GL_SCISSOR_TEST || target==GL_SCISSOR_BOX) && context->profile!=kCGLOGLPVersion_Legacy) { if(!core)core=(Proc)dlsym(RTLD_DEFAULT,"glDisablei");proc=core; }
    else { if(!ext)ext=(Proc)dlsym(RTLD_DEFAULT,"glDisableIndexedEXT");proc=ext; }
    if(target==GL_SCISSOR_TEST)context->indexed_scissor=1;
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,index);
    return 0;
}
case 748: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    typedef GLboolean (*Proc)(GLenum target, GLuint index);
    static Proc ext,core;Proc proc;
    if((target==GL_SCISSOR_TEST || target==GL_SCISSOR_BOX) && context->profile!=kCGLOGLPVersion_Legacy) { if(!core)core=(Proc)dlsym(RTLD_DEFAULT,"glIsEnabledi");proc=core; }
    else { if(!ext)ext=(Proc)dlsym(RTLD_DEFAULT,"glIsEnabledIndexedEXT");proc=ext; }
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLboolean result=proc(target,index);
    reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 749: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[2],sizeof(transpose));
    const GLfloat * value=NULL;
    value=(const GLfloat *)DGHostPointer(dg_wire_message,3,(DGArrayBytes(count,6*sizeof(GLfloat))));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniformMatrix2x3fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,transpose,value);
    return 0;
}
case 750: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[2],sizeof(transpose));
    const GLfloat * value=NULL;
    value=(const GLfloat *)DGHostPointer(dg_wire_message,3,(DGArrayBytes(count,6*sizeof(GLfloat))));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniformMatrix3x2fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,transpose,value);
    return 0;
}
case 751: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[2],sizeof(transpose));
    const GLfloat * value=NULL;
    value=(const GLfloat *)DGHostPointer(dg_wire_message,3,(DGArrayBytes(count,8*sizeof(GLfloat))));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniformMatrix2x4fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,transpose,value);
    return 0;
}
case 752: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[2],sizeof(transpose));
    const GLfloat * value=NULL;
    value=(const GLfloat *)DGHostPointer(dg_wire_message,3,(DGArrayBytes(count,8*sizeof(GLfloat))));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniformMatrix4x2fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,transpose,value);
    return 0;
}
case 753: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[2],sizeof(transpose));
    const GLfloat * value=NULL;
    value=(const GLfloat *)DGHostPointer(dg_wire_message,3,(DGArrayBytes(count,12*sizeof(GLfloat))));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniformMatrix3x4fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,transpose,value);
    return 0;
}
case 754: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[2],sizeof(transpose));
    const GLfloat * value=NULL;
    value=(const GLfloat *)DGHostPointer(dg_wire_message,3,(DGArrayBytes(count,12*sizeof(GLfloat))));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniformMatrix4x3fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,transpose,value);
    return 0;
}
case 755: {
    GLint srcX0=0;memcpy(&srcX0,&dg_wire_message->args[0],sizeof(srcX0));
    GLint srcY0=0;memcpy(&srcY0,&dg_wire_message->args[1],sizeof(srcY0));
    GLint srcX1=0;memcpy(&srcX1,&dg_wire_message->args[2],sizeof(srcX1));
    GLint srcY1=0;memcpy(&srcY1,&dg_wire_message->args[3],sizeof(srcY1));
    GLint dstX0=0;memcpy(&dstX0,&dg_wire_message->args[4],sizeof(dstX0));
    GLint dstY0=0;memcpy(&dstY0,&dg_wire_message->args[5],sizeof(dstY0));
    GLint dstX1=0;memcpy(&dstX1,&dg_wire_message->args[6],sizeof(dstX1));
    GLint dstY1=0;memcpy(&dstY1,&dg_wire_message->args[7],sizeof(dstY1));
    GLbitfield mask=0;memcpy(&mask,&dg_wire_message->args[8],sizeof(mask));
    GLenum filter=0;memcpy(&filter,&dg_wire_message->args[9],sizeof(filter));
    typedef void (*Proc)(GLint srcX0, GLint srcY0, GLint srcX1, GLint srcY1, GLint dstX0, GLint dstY0, GLint dstX1, GLint dstY1, GLbitfield mask, GLenum filter);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glBlitFramebufferEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    if(!DGDrawableWritable(context)) return 0;
    proc(srcX0,srcY0,srcX1,srcY1,dstX0,dstY0,dstX1,dstY1,mask,filter);
    DGMarkDrawableDamage(context);
    return 0;
}
case 756: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLsizei samples=0;memcpy(&samples,&dg_wire_message->args[1],sizeof(samples));
    GLenum internalformat=0;memcpy(&internalformat,&dg_wire_message->args[2],sizeof(internalformat));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[3],sizeof(width));
    GLsizei height=0;memcpy(&height,&dg_wire_message->args[4],sizeof(height));
    typedef void (*Proc)(GLenum target, GLsizei samples, GLenum internalformat, GLsizei width, GLsizei height);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glRenderbufferStorageMultisampleEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,samples,internalformat,width,height);
    return 0;
}
case 757: {
    GLuint id=0;memcpy(&id,&dg_wire_message->args[0],sizeof(id));
    GLenum mode=0;memcpy(&mode,&dg_wire_message->args[1],sizeof(mode));
    typedef void (*Proc)(GLuint id, GLenum mode);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glBeginConditionalRenderNV");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(id,mode);
    return 0;
}
case 758: {
    typedef void (*Proc)(void);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glEndConditionalRenderNV");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc();
    return 0;
}
case 759: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLsizei maxCount=0;memcpy(&maxCount,&dg_wire_message->args[1],sizeof(maxCount));
    GLsizei * count=NULL;
    GLuint * shaders=NULL;
    count=(GLsizei *)DGHostPointer(dg_wire_message,2,((sizeof(GLsizei)) ? (sizeof(GLsizei)) : 1));
    if(dg_wire_message->args[2] && !count) return -1;
    shaders=(GLuint *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(maxCount,sizeof(GLuint))) ? (DGQueryArrayBytes(maxCount,sizeof(GLuint))) : 1));
    if((maxCount && !shaders) || (dg_wire_message->args[3] && !shaders)) return -1;
    typedef void (*Proc)(GLuint program, GLsizei maxCount, GLsizei *count, GLuint *shaders);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetAttachedShaders");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,maxCount,count,shaders);
    return 0;
}
case 760: {
    GLenum mode=0;memcpy(&mode,&dg_wire_message->args[0],sizeof(mode));
    typedef void (*Proc)(GLenum mode);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProvokingVertexEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(mode);
    return 0;
}
case 773: {
    GLfloat size=0;memcpy(&size,&dg_wire_message->args[0],sizeof(size));
    typedef void (*Proc)(GLfloat size);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexPointSizefAPPLE");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(size);
    return 0;
}
case 774: {
    GLenum buffer=0;memcpy(&buffer,&dg_wire_message->args[0],sizeof(buffer));
    GLint drawbuffer=0;memcpy(&drawbuffer,&dg_wire_message->args[1],sizeof(drawbuffer));
    if(!(buffer==GL_COLOR || buffer==GL_STENCIL)) { context->error=GL_INVALID_ENUM;return 0; }
    const GLint * value=NULL;
    value=(const GLint *)DGHostPointer(dg_wire_message,2,((buffer==GL_COLOR ? 4 : 1)*sizeof(GLint)));
    if(!value) return -1;
    typedef void (*Proc)(GLenum buffer, GLint drawbuffer, const GLint *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glClearBufferiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    if(!DGDrawableWritable(context)) return 0;
    proc(buffer,drawbuffer,value);
    if(buffer==GL_COLOR) DGMarkDrawableDamage(context);
    return 0;
}
case 775: {
    GLenum buffer=0;memcpy(&buffer,&dg_wire_message->args[0],sizeof(buffer));
    GLint drawbuffer=0;memcpy(&drawbuffer,&dg_wire_message->args[1],sizeof(drawbuffer));
    if(!(buffer==GL_COLOR)) { context->error=GL_INVALID_ENUM;return 0; }
    const GLuint * value=NULL;
    value=(const GLuint *)DGHostPointer(dg_wire_message,2,((buffer==GL_COLOR ? 4 : 1)*sizeof(GLuint)));
    if(!value) return -1;
    typedef void (*Proc)(GLenum buffer, GLint drawbuffer, const GLuint *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glClearBufferuiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    if(!DGDrawableWritable(context)) return 0;
    proc(buffer,drawbuffer,value);
    if(buffer==GL_COLOR) DGMarkDrawableDamage(context);
    return 0;
}
case 776: {
    GLenum buffer=0;memcpy(&buffer,&dg_wire_message->args[0],sizeof(buffer));
    GLint drawbuffer=0;memcpy(&drawbuffer,&dg_wire_message->args[1],sizeof(drawbuffer));
    if(!(buffer==GL_COLOR || buffer==GL_DEPTH)) { context->error=GL_INVALID_ENUM;return 0; }
    const GLfloat * value=NULL;
    value=(const GLfloat *)DGHostPointer(dg_wire_message,2,((buffer==GL_COLOR ? 4 : 1)*sizeof(GLfloat)));
    if(!value) return -1;
    typedef void (*Proc)(GLenum buffer, GLint drawbuffer, const GLfloat *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glClearBufferfv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    if(!DGDrawableWritable(context)) return 0;
    proc(buffer,drawbuffer,value);
    if(buffer==GL_COLOR) DGMarkDrawableDamage(context);
    return 0;
}
case 777: {
    GLenum buffer=0;memcpy(&buffer,&dg_wire_message->args[0],sizeof(buffer));
    GLint drawbuffer=0;memcpy(&drawbuffer,&dg_wire_message->args[1],sizeof(drawbuffer));
    GLfloat depth=0;memcpy(&depth,&dg_wire_message->args[2],sizeof(depth));
    GLint stencil=0;memcpy(&stencil,&dg_wire_message->args[3],sizeof(stencil));
    if(!(buffer==GL_DEPTH_STENCIL)) { context->error=GL_INVALID_ENUM;return 0; }
    typedef void (*Proc)(GLenum buffer, GLint drawbuffer, GLfloat depth, GLint stencil);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glClearBufferfi");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    if(!DGDrawableWritable(context)) return 0;
    proc(buffer,drawbuffer,depth,stencil);
    return 0;
}
case 784: {
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[0],sizeof(pname));
    GLint binary_count=0;GLenum count_key=DGStateArrayCountKey(pname);
    if(count_key) {
        if(dg_wire_message->args[14]>DG_MAX_BYTES/sizeof(GLint64))return -1;
        binary_count=(GLint)dg_wire_message->args[14];
        if(!DGHostStateArrayCapacity(context,count_key,binary_count))return 0;
    }
    GLint64 * params=NULL;
    params=(GLint64 *)DGHostPointer(dg_wire_message,1,((DGStateGetBytes(pname,binary_count,sizeof(GLint64))) ? (DGStateGetBytes(pname,binary_count,sizeof(GLint64))) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum pname, GLint64 *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetInteger64v");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pname,params);
    GLint virtual_value=0;if(params && DGVirtualInteger(context,pname,&virtual_value)) *params=(GLint64)(virtual_value);
    return 0;
}
case 786: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLsizei samples=0;memcpy(&samples,&dg_wire_message->args[1],sizeof(samples));
    GLint internalformat=0;memcpy(&internalformat,&dg_wire_message->args[2],sizeof(internalformat));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[3],sizeof(width));
    GLsizei height=0;memcpy(&height,&dg_wire_message->args[4],sizeof(height));
    GLboolean fixedsamplelocations=0;memcpy(&fixedsamplelocations,&dg_wire_message->args[5],sizeof(fixedsamplelocations));
    typedef void (*Proc)(GLenum target, GLsizei samples, GLint internalformat, GLsizei width, GLsizei height, GLboolean fixedsamplelocations);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexImage2DMultisample");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,samples,internalformat,width,height,fixedsamplelocations);
    return 0;
}
case 787: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLsizei samples=0;memcpy(&samples,&dg_wire_message->args[1],sizeof(samples));
    GLint internalformat=0;memcpy(&internalformat,&dg_wire_message->args[2],sizeof(internalformat));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[3],sizeof(width));
    GLsizei height=0;memcpy(&height,&dg_wire_message->args[4],sizeof(height));
    GLsizei depth=0;memcpy(&depth,&dg_wire_message->args[5],sizeof(depth));
    GLboolean fixedsamplelocations=0;memcpy(&fixedsamplelocations,&dg_wire_message->args[6],sizeof(fixedsamplelocations));
    typedef void (*Proc)(GLenum target, GLsizei samples, GLint internalformat, GLsizei width, GLsizei height, GLsizei depth, GLboolean fixedsamplelocations);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexImage3DMultisample");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,samples,internalformat,width,height,depth,fixedsamplelocations);
    return 0;
}
case 788: {
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[0],sizeof(pname));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    GLfloat * val=NULL;
    if(pname!=0x8e50) { context->error=GL_INVALID_ENUM;return 0; }
    val=(GLfloat *)DGHostPointer(dg_wire_message,2,((2*sizeof(GLfloat)) ? (2*sizeof(GLfloat)) : 1));
    if(!val) return -1;
    typedef void (*Proc)(GLenum pname, GLuint index, GLfloat *val);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetMultisamplefv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pname,index,val);
    return 0;
}
case 789: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLbitfield mask=0;memcpy(&mask,&dg_wire_message->args[1],sizeof(mask));
    typedef void (*Proc)(GLuint index, GLbitfield mask);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glSampleMaski");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,mask);
    return 0;
}
case 790: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum internalformat=0;memcpy(&internalformat,&dg_wire_message->args[1],sizeof(internalformat));
    GLuint buffer=0;memcpy(&buffer,&dg_wire_message->args[2],sizeof(buffer));
    typedef void (*Proc)(GLenum target, GLenum internalformat, GLuint buffer);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexBuffer");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,internalformat,buffer);
    return 0;
}
case 792: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    typedef void (*Proc)(GLuint index);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPrimitiveRestartIndex");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index);
    return 0;
}
case 793: {
    GLuint id=0;memcpy(&id,&dg_wire_message->args[0],sizeof(id));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint64EXT * params=NULL;
    params=(GLint64EXT *)DGHostPointer(dg_wire_message,2,((sizeof(GLint64EXT)) ? (sizeof(GLint64EXT)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLuint id, GLenum pname, GLint64EXT *params);
    Proc proc=context->profile==kCGLOGLPVersion_Legacy ? dg_core_api.signed_result_ext : dg_core_api.signed_result;
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(id,pname,params);
    return 0;
}
case 794: {
    GLuint id=0;memcpy(&id,&dg_wire_message->args[0],sizeof(id));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLuint64EXT * params=NULL;
    params=(GLuint64EXT *)DGHostPointer(dg_wire_message,2,((sizeof(GLuint64EXT)) ? (sizeof(GLuint64EXT)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLuint id, GLenum pname, GLuint64EXT *params);
    Proc proc=context->profile==kCGLOGLPVersion_Legacy ? dg_core_api.unsigned_result_ext : dg_core_api.unsigned_result;
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(id,pname,params);
    return 0;
}
case 797: {
    GLuint id=0;memcpy(&id,&dg_wire_message->args[0],sizeof(id));
    GLenum target=0;memcpy(&target,&dg_wire_message->args[1],sizeof(target));
    typedef void (*Proc)(GLuint id, GLenum target);
    Proc proc=dg_core_api.query_counter;
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(id,target);
    return 0;
}
case 798: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    GLint64 * data=NULL;
    if(!DGIndexedInteger64Count(target)) return -1;
    data=(GLint64 *)DGHostPointer(dg_wire_message,2,((DGIndexedInteger64Count(target)*sizeof(GLint64)) ? (DGIndexedInteger64Count(target)*sizeof(GLint64)) : 1));
    if(!data) return -1;
    typedef void (*Proc)(GLenum target, GLuint index, GLint64 *data);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetInteger64i_v");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,index,data);
    return 0;
}
case 800: {
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[0],sizeof(count));
    GLuint * samplers=NULL;
    samplers=(GLuint *)DGHostPointer(dg_wire_message,1,((DGQueryArrayBytes(count,sizeof(GLuint))) ? (DGQueryArrayBytes(count,sizeof(GLuint))) : 1));
    if(!samplers) return -1;
    typedef void (*Proc)(GLsizei count, GLuint *samplers);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGenSamplers");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(count,samplers);
    return 0;
}
case 801: {
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[0],sizeof(count));
    const GLuint * samplers=NULL;
    samplers=(const GLuint *)DGHostPointer(dg_wire_message,1,((DGQueryArrayBytes(count,sizeof(GLuint))) ? (DGQueryArrayBytes(count,sizeof(GLuint))) : 1));
    if(!samplers) return -1;
    typedef void (*Proc)(GLsizei count, const GLuint *samplers);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glDeleteSamplers");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(count,samplers);
    return 0;
}
case 802: {
    GLuint sampler=0;memcpy(&sampler,&dg_wire_message->args[0],sizeof(sampler));
    typedef GLboolean (*Proc)(GLuint sampler);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glIsSampler");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLboolean result=proc(sampler);
    reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 803: {
    GLuint unit=0;memcpy(&unit,&dg_wire_message->args[0],sizeof(unit));
    GLuint sampler=0;memcpy(&sampler,&dg_wire_message->args[1],sizeof(sampler));
    typedef void (*Proc)(GLuint unit, GLuint sampler);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glBindSampler");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(unit,sampler);
    return 0;
}
case 804: {
    GLuint sampler=0;memcpy(&sampler,&dg_wire_message->args[0],sizeof(sampler));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint param=0;memcpy(&param,&dg_wire_message->args[2],sizeof(param));
    typedef void (*Proc)(GLuint sampler, GLenum pname, GLint param);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glSamplerParameteri");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(sampler,pname,param);
    return 0;
}
case 805: {
    GLuint sampler=0;memcpy(&sampler,&dg_wire_message->args[0],sizeof(sampler));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    const GLint * param=NULL;
    if(!DGSamplerParameterCount(pname)) return -1;
    param=(const GLint *)DGHostPointer(dg_wire_message,2,(DGSamplerParameterCount(pname)*sizeof(GLint)));
    if(!param) return -1;
    typedef void (*Proc)(GLuint sampler, GLenum pname, const GLint *param);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glSamplerParameteriv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(sampler,pname,param);
    return 0;
}
case 806: {
    GLuint sampler=0;memcpy(&sampler,&dg_wire_message->args[0],sizeof(sampler));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLfloat param=0;memcpy(&param,&dg_wire_message->args[2],sizeof(param));
    typedef void (*Proc)(GLuint sampler, GLenum pname, GLfloat param);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glSamplerParameterf");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(sampler,pname,param);
    return 0;
}
case 807: {
    GLuint sampler=0;memcpy(&sampler,&dg_wire_message->args[0],sizeof(sampler));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    const GLfloat * param=NULL;
    if(!DGSamplerParameterCount(pname)) return -1;
    param=(const GLfloat *)DGHostPointer(dg_wire_message,2,(DGSamplerParameterCount(pname)*sizeof(GLfloat)));
    if(!param) return -1;
    typedef void (*Proc)(GLuint sampler, GLenum pname, const GLfloat *param);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glSamplerParameterfv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(sampler,pname,param);
    return 0;
}
case 808: {
    GLuint sampler=0;memcpy(&sampler,&dg_wire_message->args[0],sizeof(sampler));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    const GLint * param=NULL;
    if(!DGSamplerParameterCount(pname)) return -1;
    param=(const GLint *)DGHostPointer(dg_wire_message,2,(DGSamplerParameterCount(pname)*sizeof(GLint)));
    if(!param) return -1;
    typedef void (*Proc)(GLuint sampler, GLenum pname, const GLint *param);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glSamplerParameterIiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(sampler,pname,param);
    return 0;
}
case 809: {
    GLuint sampler=0;memcpy(&sampler,&dg_wire_message->args[0],sizeof(sampler));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    const GLuint * param=NULL;
    if(!DGSamplerParameterCount(pname)) return -1;
    param=(const GLuint *)DGHostPointer(dg_wire_message,2,(DGSamplerParameterCount(pname)*sizeof(GLuint)));
    if(!param) return -1;
    typedef void (*Proc)(GLuint sampler, GLenum pname, const GLuint *param);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glSamplerParameterIuiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(sampler,pname,param);
    return 0;
}
case 810: {
    GLuint sampler=0;memcpy(&sampler,&dg_wire_message->args[0],sizeof(sampler));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint * params=NULL;
    if(!DGSamplerParameterCount(pname)) return -1;
    params=(GLint *)DGHostPointer(dg_wire_message,2,((DGSamplerParameterCount(pname)*sizeof(GLint)) ? (DGSamplerParameterCount(pname)*sizeof(GLint)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLuint sampler, GLenum pname, GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetSamplerParameteriv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(sampler,pname,params);
    return 0;
}
case 811: {
    GLuint sampler=0;memcpy(&sampler,&dg_wire_message->args[0],sizeof(sampler));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLfloat * params=NULL;
    if(!DGSamplerParameterCount(pname)) return -1;
    params=(GLfloat *)DGHostPointer(dg_wire_message,2,((DGSamplerParameterCount(pname)*sizeof(GLfloat)) ? (DGSamplerParameterCount(pname)*sizeof(GLfloat)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLuint sampler, GLenum pname, GLfloat *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetSamplerParameterfv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(sampler,pname,params);
    return 0;
}
case 812: {
    GLuint sampler=0;memcpy(&sampler,&dg_wire_message->args[0],sizeof(sampler));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint * params=NULL;
    if(!DGSamplerParameterCount(pname)) return -1;
    params=(GLint *)DGHostPointer(dg_wire_message,2,((DGSamplerParameterCount(pname)*sizeof(GLint)) ? (DGSamplerParameterCount(pname)*sizeof(GLint)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLuint sampler, GLenum pname, GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetSamplerParameterIiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(sampler,pname,params);
    return 0;
}
case 813: {
    GLuint sampler=0;memcpy(&sampler,&dg_wire_message->args[0],sizeof(sampler));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLuint * params=NULL;
    if(!DGSamplerParameterCount(pname)) return -1;
    params=(GLuint *)DGHostPointer(dg_wire_message,2,((DGSamplerParameterCount(pname)*sizeof(GLuint)) ? (DGSamplerParameterCount(pname)*sizeof(GLuint)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLuint sampler, GLenum pname, GLuint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetSamplerParameterIuiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(sampler,pname,params);
    return 0;
}
case 814: {
    GLenum type=0;memcpy(&type,&dg_wire_message->args[0],sizeof(type));
    GLuint object=0;memcpy(&object,&dg_wire_message->args[1],sizeof(object));
    GLsizei length=0;memcpy(&length,&dg_wire_message->args[2],sizeof(length));
    const GLchar * label=NULL;
    label=length==0 ? (const GLchar *)DGHostString(dg_wire_message,3) : (const GLchar *)DGHostPointer(dg_wire_message,3,DGArrayBytes(length,1));
    if((length && !label) || (dg_wire_message->args[3] && !label)) return -1;
    typedef void (*Proc)(GLenum type, GLuint object, GLsizei length, const GLchar *label);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glLabelObjectEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(type,object,length,label);
    return 0;
}
case 815: {
    GLenum type=0;memcpy(&type,&dg_wire_message->args[0],sizeof(type));
    GLuint object=0;memcpy(&object,&dg_wire_message->args[1],sizeof(object));
    GLsizei bufSize=0;memcpy(&bufSize,&dg_wire_message->args[2],sizeof(bufSize));
    GLsizei * length=NULL;
    GLchar * label=NULL;
    length=(GLsizei *)DGHostPointer(dg_wire_message,3,((sizeof(GLsizei)) ? (sizeof(GLsizei)) : 1));
    if(dg_wire_message->args[3] && !length) return -1;
    label=(GLchar *)DGHostPointer(dg_wire_message,4,((DGQueryArrayBytes(bufSize,1)) ? (DGQueryArrayBytes(bufSize,1)) : 1));
    if(dg_wire_message->args[4] && !label) return -1;
    typedef void (*Proc)(GLenum type, GLuint object, GLsizei bufSize, GLsizei *length, GLchar *label);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetObjectLabelEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(type,object,bufSize,length,label);
    return 0;
}
case 816: {
    GLsizei length=0;memcpy(&length,&dg_wire_message->args[0],sizeof(length));
    const GLchar * marker=NULL;
    marker=length==0 ? (const GLchar *)DGHostString(dg_wire_message,1) : (const GLchar *)DGHostPointer(dg_wire_message,1,DGArrayBytes(length,1));
    if((length && !marker) || (dg_wire_message->args[1] && !marker)) return -1;
    typedef void (*Proc)(GLsizei length, const GLchar *marker);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glInsertEventMarkerEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(length,marker);
    return 0;
}
case 817: {
    GLsizei length=0;memcpy(&length,&dg_wire_message->args[0],sizeof(length));
    const GLchar * marker=NULL;
    marker=length==0 ? (const GLchar *)DGHostString(dg_wire_message,1) : (const GLchar *)DGHostPointer(dg_wire_message,1,DGArrayBytes(length,1));
    if((length && !marker) || (dg_wire_message->args[1] && !marker)) return -1;
    typedef void (*Proc)(GLsizei length, const GLchar *marker);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPushGroupMarkerEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(length,marker);
    return 0;
}
case 818: {
    typedef void (*Proc)(void);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPopGroupMarkerEXT");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc();
    return 0;
}
case 819: {
    GLuint pipeline=0;memcpy(&pipeline,&dg_wire_message->args[0],sizeof(pipeline));
    GLbitfield stages=0;memcpy(&stages,&dg_wire_message->args[1],sizeof(stages));
    GLuint program=0;memcpy(&program,&dg_wire_message->args[2],sizeof(program));
    typedef void (*Proc)(GLuint pipeline, GLbitfield stages, GLuint program);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUseProgramStages");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pipeline,stages,program);
    return 0;
}
case 820: {
    GLuint pipeline=0;memcpy(&pipeline,&dg_wire_message->args[0],sizeof(pipeline));
    GLuint program=0;memcpy(&program,&dg_wire_message->args[1],sizeof(program));
    typedef void (*Proc)(GLuint pipeline, GLuint program);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glActiveShaderProgram");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pipeline,program);
    return 0;
}
case 821: return DGHostCreateShaderProgram(context,dg_wire_message,reply);
case 822: {
    GLuint pipeline=0;memcpy(&pipeline,&dg_wire_message->args[0],sizeof(pipeline));
    typedef void (*Proc)(GLuint pipeline);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glBindProgramPipeline");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pipeline);
    return 0;
}
case 823: {
    GLsizei n=0;memcpy(&n,&dg_wire_message->args[0],sizeof(n));
    const GLuint * pipelines=NULL;
    pipelines=(const GLuint *)DGHostPointer(dg_wire_message,1,((DGQueryArrayBytes(n,sizeof(GLuint))) ? (DGQueryArrayBytes(n,sizeof(GLuint))) : 1));
    if(!pipelines) return -1;
    typedef void (*Proc)(GLsizei n, const GLuint *pipelines);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glDeleteProgramPipelines");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(n,pipelines);
    return 0;
}
case 824: {
    GLsizei n=0;memcpy(&n,&dg_wire_message->args[0],sizeof(n));
    GLuint * pipelines=NULL;
    pipelines=(GLuint *)DGHostPointer(dg_wire_message,1,((DGQueryArrayBytes(n,sizeof(GLuint))) ? (DGQueryArrayBytes(n,sizeof(GLuint))) : 1));
    if(!pipelines) return -1;
    typedef void (*Proc)(GLsizei n, GLuint *pipelines);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGenProgramPipelines");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(n,pipelines);
    return 0;
}
case 825: {
    GLuint pipeline=0;memcpy(&pipeline,&dg_wire_message->args[0],sizeof(pipeline));
    typedef GLboolean (*Proc)(GLuint pipeline);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glIsProgramPipeline");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLboolean result=proc(pipeline);
    reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 826: {
    GLuint pipeline=0;memcpy(&pipeline,&dg_wire_message->args[0],sizeof(pipeline));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLint * params=NULL;
    params=(GLint *)DGHostPointer(dg_wire_message,2,((sizeof(GLint)) ? (sizeof(GLint)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLuint pipeline, GLenum pname, GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetProgramPipelineiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pipeline,pname,params);
    return 0;
}
case 827: {
    GLuint pipeline=0;memcpy(&pipeline,&dg_wire_message->args[0],sizeof(pipeline));
    typedef void (*Proc)(GLuint pipeline);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glValidateProgramPipeline");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pipeline);
    return 0;
}
case 828: {
    GLuint pipeline=0;memcpy(&pipeline,&dg_wire_message->args[0],sizeof(pipeline));
    GLsizei bufSize=0;memcpy(&bufSize,&dg_wire_message->args[1],sizeof(bufSize));
    GLsizei * length=NULL;
    GLchar * infoLog=NULL;
    length=(GLsizei *)DGHostPointer(dg_wire_message,2,((sizeof(GLsizei)) ? (sizeof(GLsizei)) : 1));
    if(dg_wire_message->args[2] && !length) return -1;
    infoLog=(GLchar *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(bufSize,1)) ? (DGQueryArrayBytes(bufSize,1)) : 1));
    if(!infoLog) return -1;
    typedef void (*Proc)(GLuint pipeline, GLsizei bufSize, GLsizei *length, GLchar *infoLog);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetProgramPipelineInfoLog");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pipeline,bufSize,length,infoLog);
    return 0;
}
case 829: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLint x=0;memcpy(&x,&dg_wire_message->args[2],sizeof(x));
    typedef void (*Proc)(GLuint program, GLint location, GLint x);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform1i");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,x);
    return 0;
}
case 830: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLint x=0;memcpy(&x,&dg_wire_message->args[2],sizeof(x));
    GLint y=0;memcpy(&y,&dg_wire_message->args[3],sizeof(y));
    typedef void (*Proc)(GLuint program, GLint location, GLint x, GLint y);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform2i");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,x,y);
    return 0;
}
case 831: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLint x=0;memcpy(&x,&dg_wire_message->args[2],sizeof(x));
    GLint y=0;memcpy(&y,&dg_wire_message->args[3],sizeof(y));
    GLint z=0;memcpy(&z,&dg_wire_message->args[4],sizeof(z));
    typedef void (*Proc)(GLuint program, GLint location, GLint x, GLint y, GLint z);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform3i");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,x,y,z);
    return 0;
}
case 832: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLint x=0;memcpy(&x,&dg_wire_message->args[2],sizeof(x));
    GLint y=0;memcpy(&y,&dg_wire_message->args[3],sizeof(y));
    GLint z=0;memcpy(&z,&dg_wire_message->args[4],sizeof(z));
    GLint w=0;memcpy(&w,&dg_wire_message->args[5],sizeof(w));
    typedef void (*Proc)(GLuint program, GLint location, GLint x, GLint y, GLint z, GLint w);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform4i");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,x,y,z,w);
    return 0;
}
case 833: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLfloat x=0;memcpy(&x,&dg_wire_message->args[2],sizeof(x));
    typedef void (*Proc)(GLuint program, GLint location, GLfloat x);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform1f");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,x);
    return 0;
}
case 834: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLfloat x=0;memcpy(&x,&dg_wire_message->args[2],sizeof(x));
    GLfloat y=0;memcpy(&y,&dg_wire_message->args[3],sizeof(y));
    typedef void (*Proc)(GLuint program, GLint location, GLfloat x, GLfloat y);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform2f");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,x,y);
    return 0;
}
case 835: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLfloat x=0;memcpy(&x,&dg_wire_message->args[2],sizeof(x));
    GLfloat y=0;memcpy(&y,&dg_wire_message->args[3],sizeof(y));
    GLfloat z=0;memcpy(&z,&dg_wire_message->args[4],sizeof(z));
    typedef void (*Proc)(GLuint program, GLint location, GLfloat x, GLfloat y, GLfloat z);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform3f");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,x,y,z);
    return 0;
}
case 836: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLfloat x=0;memcpy(&x,&dg_wire_message->args[2],sizeof(x));
    GLfloat y=0;memcpy(&y,&dg_wire_message->args[3],sizeof(y));
    GLfloat z=0;memcpy(&z,&dg_wire_message->args[4],sizeof(z));
    GLfloat w=0;memcpy(&w,&dg_wire_message->args[5],sizeof(w));
    typedef void (*Proc)(GLuint program, GLint location, GLfloat x, GLfloat y, GLfloat z, GLfloat w);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform4f");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,x,y,z,w);
    return 0;
}
case 837: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    const GLint * value=NULL;
    value=(const GLint *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(location==-1 ? 0 : count,1*sizeof(GLint))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,1*sizeof(GLint))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, const GLint *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform1iv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,value);
    return 0;
}
case 838: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    const GLint * value=NULL;
    value=(const GLint *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(location==-1 ? 0 : count,2*sizeof(GLint))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,2*sizeof(GLint))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, const GLint *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform2iv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,value);
    return 0;
}
case 839: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    const GLint * value=NULL;
    value=(const GLint *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(location==-1 ? 0 : count,3*sizeof(GLint))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,3*sizeof(GLint))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, const GLint *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform3iv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,value);
    return 0;
}
case 840: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    const GLint * value=NULL;
    value=(const GLint *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(location==-1 ? 0 : count,4*sizeof(GLint))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,4*sizeof(GLint))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, const GLint *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform4iv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,value);
    return 0;
}
case 841: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    const GLfloat * value=NULL;
    value=(const GLfloat *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(location==-1 ? 0 : count,1*sizeof(GLfloat))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,1*sizeof(GLfloat))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, const GLfloat *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform1fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,value);
    return 0;
}
case 842: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    const GLfloat * value=NULL;
    value=(const GLfloat *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(location==-1 ? 0 : count,2*sizeof(GLfloat))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,2*sizeof(GLfloat))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, const GLfloat *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform2fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,value);
    return 0;
}
case 843: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    const GLfloat * value=NULL;
    value=(const GLfloat *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(location==-1 ? 0 : count,3*sizeof(GLfloat))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,3*sizeof(GLfloat))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, const GLfloat *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform3fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,value);
    return 0;
}
case 844: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    const GLfloat * value=NULL;
    value=(const GLfloat *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(location==-1 ? 0 : count,4*sizeof(GLfloat))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,4*sizeof(GLfloat))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, const GLfloat *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform4fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,value);
    return 0;
}
case 845: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[3],sizeof(transpose));
    const GLfloat * value=NULL;
    value=(const GLfloat *)DGHostPointer(dg_wire_message,4,((DGQueryArrayBytes(location==-1 ? 0 : count,4*sizeof(GLfloat))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,4*sizeof(GLfloat))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniformMatrix2fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,transpose,value);
    return 0;
}
case 846: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[3],sizeof(transpose));
    const GLfloat * value=NULL;
    value=(const GLfloat *)DGHostPointer(dg_wire_message,4,((DGQueryArrayBytes(location==-1 ? 0 : count,9*sizeof(GLfloat))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,9*sizeof(GLfloat))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniformMatrix3fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,transpose,value);
    return 0;
}
case 847: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[3],sizeof(transpose));
    const GLfloat * value=NULL;
    value=(const GLfloat *)DGHostPointer(dg_wire_message,4,((DGQueryArrayBytes(location==-1 ? 0 : count,16*sizeof(GLfloat))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,16*sizeof(GLfloat))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniformMatrix4fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,transpose,value);
    return 0;
}
case 848: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLuint x=0;memcpy(&x,&dg_wire_message->args[2],sizeof(x));
    typedef void (*Proc)(GLuint program, GLint location, GLuint x);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform1ui");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,x);
    return 0;
}
case 849: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLuint x=0;memcpy(&x,&dg_wire_message->args[2],sizeof(x));
    GLuint y=0;memcpy(&y,&dg_wire_message->args[3],sizeof(y));
    typedef void (*Proc)(GLuint program, GLint location, GLuint x, GLuint y);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform2ui");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,x,y);
    return 0;
}
case 850: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLuint x=0;memcpy(&x,&dg_wire_message->args[2],sizeof(x));
    GLuint y=0;memcpy(&y,&dg_wire_message->args[3],sizeof(y));
    GLuint z=0;memcpy(&z,&dg_wire_message->args[4],sizeof(z));
    typedef void (*Proc)(GLuint program, GLint location, GLuint x, GLuint y, GLuint z);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform3ui");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,x,y,z);
    return 0;
}
case 851: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLuint x=0;memcpy(&x,&dg_wire_message->args[2],sizeof(x));
    GLuint y=0;memcpy(&y,&dg_wire_message->args[3],sizeof(y));
    GLuint z=0;memcpy(&z,&dg_wire_message->args[4],sizeof(z));
    GLuint w=0;memcpy(&w,&dg_wire_message->args[5],sizeof(w));
    typedef void (*Proc)(GLuint program, GLint location, GLuint x, GLuint y, GLuint z, GLuint w);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform4ui");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,x,y,z,w);
    return 0;
}
case 852: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    const GLuint * value=NULL;
    value=(const GLuint *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(location==-1 ? 0 : count,1*sizeof(GLuint))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,1*sizeof(GLuint))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, const GLuint *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform1uiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,value);
    return 0;
}
case 853: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    const GLuint * value=NULL;
    value=(const GLuint *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(location==-1 ? 0 : count,2*sizeof(GLuint))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,2*sizeof(GLuint))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, const GLuint *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform2uiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,value);
    return 0;
}
case 854: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    const GLuint * value=NULL;
    value=(const GLuint *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(location==-1 ? 0 : count,3*sizeof(GLuint))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,3*sizeof(GLuint))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, const GLuint *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform3uiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,value);
    return 0;
}
case 855: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    const GLuint * value=NULL;
    value=(const GLuint *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(location==-1 ? 0 : count,4*sizeof(GLuint))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,4*sizeof(GLuint))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, const GLuint *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform4uiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,value);
    return 0;
}
case 856: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[3],sizeof(transpose));
    const GLfloat * value=NULL;
    value=(const GLfloat *)DGHostPointer(dg_wire_message,4,((DGQueryArrayBytes(location==-1 ? 0 : count,6*sizeof(GLfloat))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,6*sizeof(GLfloat))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniformMatrix2x3fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,transpose,value);
    return 0;
}
case 857: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[3],sizeof(transpose));
    const GLfloat * value=NULL;
    value=(const GLfloat *)DGHostPointer(dg_wire_message,4,((DGQueryArrayBytes(location==-1 ? 0 : count,6*sizeof(GLfloat))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,6*sizeof(GLfloat))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniformMatrix3x2fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,transpose,value);
    return 0;
}
case 858: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[3],sizeof(transpose));
    const GLfloat * value=NULL;
    value=(const GLfloat *)DGHostPointer(dg_wire_message,4,((DGQueryArrayBytes(location==-1 ? 0 : count,8*sizeof(GLfloat))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,8*sizeof(GLfloat))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniformMatrix2x4fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,transpose,value);
    return 0;
}
case 859: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[3],sizeof(transpose));
    const GLfloat * value=NULL;
    value=(const GLfloat *)DGHostPointer(dg_wire_message,4,((DGQueryArrayBytes(location==-1 ? 0 : count,8*sizeof(GLfloat))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,8*sizeof(GLfloat))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniformMatrix4x2fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,transpose,value);
    return 0;
}
case 860: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[3],sizeof(transpose));
    const GLfloat * value=NULL;
    value=(const GLfloat *)DGHostPointer(dg_wire_message,4,((DGQueryArrayBytes(location==-1 ? 0 : count,12*sizeof(GLfloat))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,12*sizeof(GLfloat))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniformMatrix3x4fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,transpose,value);
    return 0;
}
case 861: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[3],sizeof(transpose));
    const GLfloat * value=NULL;
    value=(const GLfloat *)DGHostPointer(dg_wire_message,4,((DGQueryArrayBytes(location==-1 ? 0 : count,12*sizeof(GLfloat))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,12*sizeof(GLfloat))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, GLboolean transpose, const GLfloat *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniformMatrix4x3fv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,transpose,value);
    return 0;
}
case 862: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLuint colorNumber=0;memcpy(&colorNumber,&dg_wire_message->args[1],sizeof(colorNumber));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[2],sizeof(index));
    const GLchar * name=DGHostString(dg_wire_message,3);if(!name) return -1;
    typedef void (*Proc)(GLuint program, GLuint colorNumber, GLuint index, const GLchar *name);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glBindFragDataLocationIndexed");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,colorNumber,index,name);
    return 0;
}
case 863: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    const GLchar * name=DGHostString(dg_wire_message,1);if(!name) return -1;
    typedef GLint (*Proc)(GLuint program, const GLchar *name);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetFragDataIndex");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLint result=proc(program,name);
    reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 864: {
    GLuint buf=0;memcpy(&buf,&dg_wire_message->args[0],sizeof(buf));
    GLenum src=0;memcpy(&src,&dg_wire_message->args[1],sizeof(src));
    GLenum dst=0;memcpy(&dst,&dg_wire_message->args[2],sizeof(dst));
    typedef void (*Proc)(GLuint buf, GLenum src, GLenum dst);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glBlendFunci");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(buf,src,dst);
    return 0;
}
case 865: {
    GLuint buf=0;memcpy(&buf,&dg_wire_message->args[0],sizeof(buf));
    GLenum srcRGB=0;memcpy(&srcRGB,&dg_wire_message->args[1],sizeof(srcRGB));
    GLenum dstRGB=0;memcpy(&dstRGB,&dg_wire_message->args[2],sizeof(dstRGB));
    GLenum srcAlpha=0;memcpy(&srcAlpha,&dg_wire_message->args[3],sizeof(srcAlpha));
    GLenum dstAlpha=0;memcpy(&dstAlpha,&dg_wire_message->args[4],sizeof(dstAlpha));
    typedef void (*Proc)(GLuint buf, GLenum srcRGB, GLenum dstRGB, GLenum srcAlpha, GLenum dstAlpha);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glBlendFuncSeparatei");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(buf,srcRGB,dstRGB,srcAlpha,dstAlpha);
    return 0;
}
case 866: {
    GLuint buf=0;memcpy(&buf,&dg_wire_message->args[0],sizeof(buf));
    GLenum mode=0;memcpy(&mode,&dg_wire_message->args[1],sizeof(mode));
    typedef void (*Proc)(GLuint buf, GLenum mode);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glBlendEquationi");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(buf,mode);
    return 0;
}
case 867: {
    GLuint buf=0;memcpy(&buf,&dg_wire_message->args[0],sizeof(buf));
    GLenum modeRGB=0;memcpy(&modeRGB,&dg_wire_message->args[1],sizeof(modeRGB));
    GLenum modeAlpha=0;memcpy(&modeAlpha,&dg_wire_message->args[2],sizeof(modeAlpha));
    typedef void (*Proc)(GLuint buf, GLenum modeRGB, GLenum modeAlpha);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glBlendEquationSeparatei");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(buf,modeRGB,modeAlpha);
    return 0;
}
case 868: {
    if(context->inside_begin) { if(!context->error)context->error=GL_INVALID_OPERATION;return 0; }
    GLenum type=0;memcpy(&type,&dg_wire_message->args[0],sizeof(type));
    GLint namelen=0;memcpy(&namelen,&dg_wire_message->args[1],sizeof(namelen));
    const GLchar * name=NULL;
    GLint stringlen=0;memcpy(&stringlen,&dg_wire_message->args[3],sizeof(stringlen));
    const GLchar * string=NULL;
    name=DGHostIncludeString(dg_wire_message,2,namelen);
    if(dg_wire_message->args[2] && !name)return -1;
    string=DGHostIncludeString(dg_wire_message,4,stringlen);
    if(dg_wire_message->args[4] && !string)return -1;
    if(!name || !string) { if(!context->error)context->error=GL_INVALID_VALUE;return 0; }
    typedef void (*Proc)(GLenum type, GLint namelen, const GLchar *name, GLint stringlen, const GLchar *string);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glNamedStringARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(type,namelen,name,stringlen,string);
    return 0;
}
case 869: {
    if(context->inside_begin) { if(!context->error)context->error=GL_INVALID_OPERATION;return 0; }
    GLint namelen=0;memcpy(&namelen,&dg_wire_message->args[0],sizeof(namelen));
    const GLchar * name=NULL;
    name=DGHostIncludeString(dg_wire_message,1,namelen);
    if(dg_wire_message->args[1] && !name)return -1;
    if(!name) { if(!context->error)context->error=GL_INVALID_VALUE;return 0; }
    typedef void (*Proc)(GLint namelen, const GLchar *name);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glDeleteNamedStringARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(namelen,name);
    return 0;
}
case 870: return DGHostCompileShaderInclude(context,dg_wire_message);
case 871: {
    if(context->inside_begin) { if(!context->error)context->error=GL_INVALID_OPERATION;return 0; }
    GLint namelen=0;memcpy(&namelen,&dg_wire_message->args[0],sizeof(namelen));
    const GLchar * name=NULL;
    name=DGHostIncludeString(dg_wire_message,1,namelen);
    if(dg_wire_message->args[1] && !name)return -1;
    if(!name)return 0;
    typedef GLboolean (*Proc)(GLint namelen, const GLchar *name);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glIsNamedStringARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLboolean result=proc(namelen,name);
    reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 872: {
    if(context->inside_begin) { if(!context->error)context->error=GL_INVALID_OPERATION;return 0; }
    GLint namelen=0;memcpy(&namelen,&dg_wire_message->args[0],sizeof(namelen));
    const GLchar * name=NULL;
    GLsizei bufSize=0;memcpy(&bufSize,&dg_wire_message->args[2],sizeof(bufSize));
    GLint * stringlen=NULL;
    GLchar * string=NULL;
    name=DGHostIncludeString(dg_wire_message,1,namelen);
    if(dg_wire_message->args[1] && !name)return -1;
    stringlen=(GLint *)DGHostPointer(dg_wire_message,3,((sizeof(GLint)) ? (sizeof(GLint)) : 1));
    if(dg_wire_message->args[3] && !stringlen) return -1;
    string=(GLchar *)DGHostPointer(dg_wire_message,4,((DGQueryArrayBytes(bufSize,1)) ? (DGQueryArrayBytes(bufSize,1)) : 1));
    if(dg_wire_message->args[4] && !string) return -1;
    if(!name || bufSize<0 || (bufSize>0 && !string)) { if(!context->error)context->error=GL_INVALID_VALUE;return 0; }
    typedef void (*Proc)(GLint namelen, const GLchar *name, GLsizei bufSize, GLint *stringlen, GLchar *string);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetNamedStringARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(namelen,name,bufSize,stringlen,string);
    return 0;
}
case 873: {
    if(context->inside_begin) { if(!context->error)context->error=GL_INVALID_OPERATION;return 0; }
    GLint namelen=0;memcpy(&namelen,&dg_wire_message->args[0],sizeof(namelen));
    const GLchar * name=NULL;
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[2],sizeof(pname));
    GLint * params=NULL;
    name=DGHostIncludeString(dg_wire_message,1,namelen);
    if(dg_wire_message->args[1] && !name)return -1;
    params=(GLint *)DGHostPointer(dg_wire_message,3,((sizeof(GLint)) ? (sizeof(GLint)) : 1));
    if(dg_wire_message->args[3] && !params) return -1;
    if(!name || !params) { if(!context->error)context->error=GL_INVALID_VALUE;return 0; }
    typedef void (*Proc)(GLint namelen, const GLchar *name, GLenum pname, GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetNamedStringivARB");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(namelen,name,pname,params);
    return 0;
}
case 874: {
    typedef void (*Proc)(void);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glReleaseShaderCompiler");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc();
    return 0;
}
case 875: {
    GLint n=0;memcpy(&n,&dg_wire_message->args[0],sizeof(n));
    const GLuint * shaders=NULL;
    GLenum binaryformat=0;memcpy(&binaryformat,&dg_wire_message->args[2],sizeof(binaryformat));
    const GLvoid * binary=NULL;
    GLint length=0;memcpy(&length,&dg_wire_message->args[4],sizeof(length));
    shaders=(const GLuint *)DGHostPointer(dg_wire_message,1,((DGQueryArrayBytes(n<0 || length<0 ? 0 : n,sizeof(GLuint))) ? (DGQueryArrayBytes(n<0 || length<0 ? 0 : n,sizeof(GLuint))) : 1));
    if(!shaders) return -1;
    binary=(const GLvoid *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(n<0 || length<0 ? 0 : length,1)) ? (DGQueryArrayBytes(n<0 || length<0 ? 0 : length,1)) : 1));
    if(!binary) return -1;
    typedef void (*Proc)(GLint n, const GLuint *shaders, GLenum binaryformat, const GLvoid *binary, GLint length);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glShaderBinary");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(n,shaders,binaryformat,binary,length);
    return 0;
}
case 876: {
    GLenum shadertype=0;memcpy(&shadertype,&dg_wire_message->args[0],sizeof(shadertype));
    GLenum precisiontype=0;memcpy(&precisiontype,&dg_wire_message->args[1],sizeof(precisiontype));
    GLint * range=NULL;
    GLint * precision=NULL;
    range=(GLint *)DGHostPointer(dg_wire_message,2,((2*sizeof(GLint)) ? (2*sizeof(GLint)) : 1));
    if(!range) return -1;
    precision=(GLint *)DGHostPointer(dg_wire_message,3,((1*sizeof(GLint)) ? (1*sizeof(GLint)) : 1));
    if(!precision) return -1;
    typedef void (*Proc)(GLenum shadertype, GLenum precisiontype, GLint *range, GLint *precision);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetShaderPrecisionFormat");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(shadertype,precisiontype,range,precision);
    return 0;
}
case 877: {
    GLclampf zNear=0;memcpy(&zNear,&dg_wire_message->args[0],sizeof(zNear));
    GLclampf zFar=0;memcpy(&zFar,&dg_wire_message->args[1],sizeof(zFar));
    typedef void (*Proc)(GLclampf zNear, GLclampf zFar);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glDepthRangef");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(zNear,zFar);
    return 0;
}
case 878: {
    GLclampf depth=0;memcpy(&depth,&dg_wire_message->args[0],sizeof(depth));
    typedef void (*Proc)(GLclampf depth);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glClearDepthf");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(depth);
    return 0;
}
case 879: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLenum type=0;memcpy(&type,&dg_wire_message->args[1],sizeof(type));
    GLboolean normalized=0;memcpy(&normalized,&dg_wire_message->args[2],sizeof(normalized));
    GLuint value=0;memcpy(&value,&dg_wire_message->args[3],sizeof(value));
    typedef void (*Proc)(GLuint index, GLenum type, GLboolean normalized, GLuint value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribP1ui");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,type,normalized,value);
    return 0;
}
case 880: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLenum type=0;memcpy(&type,&dg_wire_message->args[1],sizeof(type));
    GLboolean normalized=0;memcpy(&normalized,&dg_wire_message->args[2],sizeof(normalized));
    GLuint value=0;memcpy(&value,&dg_wire_message->args[3],sizeof(value));
    typedef void (*Proc)(GLuint index, GLenum type, GLboolean normalized, GLuint value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribP2ui");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,type,normalized,value);
    return 0;
}
case 881: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLenum type=0;memcpy(&type,&dg_wire_message->args[1],sizeof(type));
    GLboolean normalized=0;memcpy(&normalized,&dg_wire_message->args[2],sizeof(normalized));
    GLuint value=0;memcpy(&value,&dg_wire_message->args[3],sizeof(value));
    typedef void (*Proc)(GLuint index, GLenum type, GLboolean normalized, GLuint value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribP3ui");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,type,normalized,value);
    return 0;
}
case 882: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLenum type=0;memcpy(&type,&dg_wire_message->args[1],sizeof(type));
    GLboolean normalized=0;memcpy(&normalized,&dg_wire_message->args[2],sizeof(normalized));
    GLuint value=0;memcpy(&value,&dg_wire_message->args[3],sizeof(value));
    typedef void (*Proc)(GLuint index, GLenum type, GLboolean normalized, GLuint value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribP4ui");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,type,normalized,value);
    return 0;
}
case 883: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLenum type=0;memcpy(&type,&dg_wire_message->args[1],sizeof(type));
    GLboolean normalized=0;memcpy(&normalized,&dg_wire_message->args[2],sizeof(normalized));
    const GLuint * value=NULL;
    value=(const GLuint *)DGHostPointer(dg_wire_message,3,(sizeof(GLuint)));
    if(!value) return -1;
    typedef void (*Proc)(GLuint index, GLenum type, GLboolean normalized, const GLuint *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribP1uiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,type,normalized,value);
    return 0;
}
case 884: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLenum type=0;memcpy(&type,&dg_wire_message->args[1],sizeof(type));
    GLboolean normalized=0;memcpy(&normalized,&dg_wire_message->args[2],sizeof(normalized));
    const GLuint * value=NULL;
    value=(const GLuint *)DGHostPointer(dg_wire_message,3,(sizeof(GLuint)));
    if(!value) return -1;
    typedef void (*Proc)(GLuint index, GLenum type, GLboolean normalized, const GLuint *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribP2uiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,type,normalized,value);
    return 0;
}
case 885: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLenum type=0;memcpy(&type,&dg_wire_message->args[1],sizeof(type));
    GLboolean normalized=0;memcpy(&normalized,&dg_wire_message->args[2],sizeof(normalized));
    const GLuint * value=NULL;
    value=(const GLuint *)DGHostPointer(dg_wire_message,3,(sizeof(GLuint)));
    if(!value) return -1;
    typedef void (*Proc)(GLuint index, GLenum type, GLboolean normalized, const GLuint *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribP3uiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,type,normalized,value);
    return 0;
}
case 886: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLenum type=0;memcpy(&type,&dg_wire_message->args[1],sizeof(type));
    GLboolean normalized=0;memcpy(&normalized,&dg_wire_message->args[2],sizeof(normalized));
    const GLuint * value=NULL;
    value=(const GLuint *)DGHostPointer(dg_wire_message,3,(sizeof(GLuint)));
    if(!value) return -1;
    typedef void (*Proc)(GLuint index, GLenum type, GLboolean normalized, const GLuint *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribP4uiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,type,normalized,value);
    return 0;
}
case 887: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLsizei bufSize=0;memcpy(&bufSize,&dg_wire_message->args[1],sizeof(bufSize));
    GLsizei * length=NULL;
    GLenum * binaryFormat=NULL;
    GLvoid * binary=NULL;
    length=(GLsizei *)DGHostPointer(dg_wire_message,2,((sizeof(GLsizei)) ? (sizeof(GLsizei)) : 1));
    if(dg_wire_message->args[2] && !length) return -1;
    binaryFormat=(GLenum *)DGHostPointer(dg_wire_message,3,((sizeof(GLenum)) ? (sizeof(GLenum)) : 1));
    if(!binaryFormat) return -1;
    binary=(GLvoid *)DGHostPointer(dg_wire_message,4,((DGQueryArrayBytes(bufSize,1)) ? (DGQueryArrayBytes(bufSize,1)) : 1));
    if(!binary) return -1;
    typedef void (*Proc)(GLuint program, GLsizei bufSize, GLsizei *length, GLenum *binaryFormat, GLvoid *binary);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetProgramBinary");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,bufSize,length,binaryFormat,binary);
    return 0;
}
case 888: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLenum binaryFormat=0;memcpy(&binaryFormat,&dg_wire_message->args[1],sizeof(binaryFormat));
    const GLvoid * binary=NULL;
    GLsizei length=0;memcpy(&length,&dg_wire_message->args[3],sizeof(length));
    binary=(const GLvoid *)DGHostPointer(dg_wire_message,2,((DGQueryArrayBytes(length,1)) ? (DGQueryArrayBytes(length,1)) : 1));
    if(!binary) return -1;
    typedef void (*Proc)(GLuint program, GLenum binaryFormat, const GLvoid *binary, GLsizei length);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramBinary");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,binaryFormat,binary,length);
    DGForgetUniformShapes(context,program);
    return 0;
}
case 889: {
    GLclampf value=0;memcpy(&value,&dg_wire_message->args[0],sizeof(value));
    typedef void (*Proc)(GLclampf value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glMinSampleShading");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(value);
    return 0;
}
case 890: {
    GLuint first=0;memcpy(&first,&dg_wire_message->args[0],sizeof(first));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    const GLfloat * v=NULL;
    v=(const GLfloat *)DGHostPointer(dg_wire_message,2,((DGQueryArrayBytes(count,4*sizeof(GLfloat))) ? (DGQueryArrayBytes(count,4*sizeof(GLfloat))) : 1));
    if(!v) return -1;
    typedef void (*Proc)(GLuint first, GLsizei count, const GLfloat * v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glViewportArrayv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(first,count,v);
    return 0;
}
case 891: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLfloat x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    GLfloat y=0;memcpy(&y,&dg_wire_message->args[2],sizeof(y));
    GLfloat w=0;memcpy(&w,&dg_wire_message->args[3],sizeof(w));
    GLfloat h=0;memcpy(&h,&dg_wire_message->args[4],sizeof(h));
    typedef void (*Proc)(GLuint index, GLfloat x, GLfloat y, GLfloat w, GLfloat h);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glViewportIndexedf");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,x,y,w,h);
    return 0;
}
case 892: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLfloat * v=NULL;
    v=(const GLfloat *)DGHostPointer(dg_wire_message,1,(4*sizeof(GLfloat)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLfloat * v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glViewportIndexedfv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 893: {
    GLuint first=0;memcpy(&first,&dg_wire_message->args[0],sizeof(first));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    const GLint * v=NULL;
    v=(const GLint *)DGHostPointer(dg_wire_message,2,((DGQueryArrayBytes(count,4*sizeof(GLint))) ? (DGQueryArrayBytes(count,4*sizeof(GLint))) : 1));
    if(!v) return -1;
    typedef void (*Proc)(GLuint first, GLsizei count, const GLint * v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glScissorArrayv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(first,count,v);
    return 0;
}
case 894: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLint left=0;memcpy(&left,&dg_wire_message->args[1],sizeof(left));
    GLint bottom=0;memcpy(&bottom,&dg_wire_message->args[2],sizeof(bottom));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[3],sizeof(width));
    GLsizei height=0;memcpy(&height,&dg_wire_message->args[4],sizeof(height));
    typedef void (*Proc)(GLuint index, GLint left, GLint bottom, GLsizei width, GLsizei height);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glScissorIndexed");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,left,bottom,width,height);
    return 0;
}
case 895: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLint * v=NULL;
    v=(const GLint *)DGHostPointer(dg_wire_message,1,(4*sizeof(GLint)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLint * v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glScissorIndexedv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 896: {
    GLuint first=0;memcpy(&first,&dg_wire_message->args[0],sizeof(first));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    const GLclampd * v=NULL;
    v=(const GLclampd *)DGHostPointer(dg_wire_message,2,((DGQueryArrayBytes(count,2*sizeof(GLclampd))) ? (DGQueryArrayBytes(count,2*sizeof(GLclampd))) : 1));
    if(!v) return -1;
    typedef void (*Proc)(GLuint first, GLsizei count, const GLclampd * v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glDepthRangeArrayv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(first,count,v);
    return 0;
}
case 897: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLclampd n=0;memcpy(&n,&dg_wire_message->args[1],sizeof(n));
    GLclampd f=0;memcpy(&f,&dg_wire_message->args[2],sizeof(f));
    typedef void (*Proc)(GLuint index, GLclampd n, GLclampd f);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glDepthRangeIndexed");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,n,f);
    return 0;
}
case 898: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    GLfloat * data=NULL;
    if(!DGIndexedInteger64Count(target)) { context->error=GL_INVALID_ENUM;return 0; }
    data=(GLfloat *)DGHostPointer(dg_wire_message,2,((DGIndexedInteger64Count(target)*sizeof(GLfloat)) ? (DGIndexedInteger64Count(target)*sizeof(GLfloat)) : 1));
    if(!data) return -1;
    typedef void (*Proc)(GLenum target, GLuint index, GLfloat *data);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetFloati_v");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,index,data);
    return 0;
}
case 899: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    GLdouble * data=NULL;
    if(!DGIndexedInteger64Count(target)) { context->error=GL_INVALID_ENUM;return 0; }
    data=(GLdouble *)DGHostPointer(dg_wire_message,2,((DGIndexedInteger64Count(target)*sizeof(GLdouble)) ? (DGIndexedInteger64Count(target)*sizeof(GLdouble)) : 1));
    if(!data) return -1;
    typedef void (*Proc)(GLenum target, GLuint index, GLdouble *data);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetDoublei_v");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,index,data);
    return 0;
}
case 902: {
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[0],sizeof(pname));
    GLint value=0;memcpy(&value,&dg_wire_message->args[1],sizeof(value));
    typedef void (*Proc)(GLenum pname, GLint value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPatchParameteri");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pname,value);
    return 0;
}
case 903: {
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[0],sizeof(pname));
    const GLfloat* values=NULL;
    if(!DGPatchLevelCount(pname)) { if(!context->error)context->error=GL_INVALID_ENUM;return 0; }
    values=(const GLfloat*)DGHostPointer(dg_wire_message,1,(DGPatchLevelCount(pname)*sizeof(GLfloat)));
    if(!values) return -1;
    typedef void (*Proc)(GLenum pname, const GLfloat* values);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPatchParameterfv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(pname,values);
    return 0;
}
case 904: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint name=0;memcpy(&name,&dg_wire_message->args[1],sizeof(name));
    typedef void (*Proc)(GLenum target, GLuint name);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glBindTransformFeedback");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,name);
    return 0;
}
case 905: {
    GLsizei n=0;memcpy(&n,&dg_wire_message->args[0],sizeof(n));
    GLuint* ids=NULL;
    ids=(GLuint*)DGHostPointer(dg_wire_message,1,((DGQueryArrayBytes(n,sizeof(GLuint))) ? (DGQueryArrayBytes(n,sizeof(GLuint))) : 1));
    if(!ids) return -1;
    typedef void (*Proc)(GLsizei n, GLuint* ids);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGenTransformFeedbacks");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(n,ids);
    return 0;
}
case 906: {
    GLsizei n=0;memcpy(&n,&dg_wire_message->args[0],sizeof(n));
    const GLuint* ids=NULL;
    ids=(const GLuint*)DGHostPointer(dg_wire_message,1,((DGQueryArrayBytes(n,sizeof(GLuint))) ? (DGQueryArrayBytes(n,sizeof(GLuint))) : 1));
    if(!ids) return -1;
    typedef void (*Proc)(GLsizei n, const GLuint* ids);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glDeleteTransformFeedbacks");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(n,ids);
    return 0;
}
case 907: {
    typedef void (*Proc)(void);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glPauseTransformFeedback");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc();
    return 0;
}
case 908: {
    typedef void (*Proc)(void);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glResumeTransformFeedback");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc();
    return 0;
}
case 909: {
    GLuint name=0;memcpy(&name,&dg_wire_message->args[0],sizeof(name));
    typedef GLboolean (*Proc)(GLuint name);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glIsTransformFeedback");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLboolean result=proc(name);
    reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 911: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    GLuint id=0;memcpy(&id,&dg_wire_message->args[2],sizeof(id));
    typedef void (*Proc)(GLenum target, GLuint index, GLuint id);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glBeginQueryIndexed");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,index,id);
    return 0;
}
case 912: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    typedef void (*Proc)(GLenum target, GLuint index);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glEndQueryIndexed");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,index);
    return 0;
}
case 913: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[1],sizeof(index));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[2],sizeof(pname));
    GLint * params=NULL;
    params=(GLint *)DGHostPointer(dg_wire_message,3,((sizeof(GLint)) ? (sizeof(GLint)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLuint index, GLenum pname, GLint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetQueryIndexediv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,index,pname,params);
    return 0;
}
case 915: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLdouble x=0;memcpy(&x,&dg_wire_message->args[2],sizeof(x));
    typedef void (*Proc)(GLuint program, GLint location, GLdouble x);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform1d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,x);
    return 0;
}
case 916: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLdouble x=0;memcpy(&x,&dg_wire_message->args[2],sizeof(x));
    GLdouble y=0;memcpy(&y,&dg_wire_message->args[3],sizeof(y));
    typedef void (*Proc)(GLuint program, GLint location, GLdouble x, GLdouble y);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform2d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,x,y);
    return 0;
}
case 917: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLdouble x=0;memcpy(&x,&dg_wire_message->args[2],sizeof(x));
    GLdouble y=0;memcpy(&y,&dg_wire_message->args[3],sizeof(y));
    GLdouble z=0;memcpy(&z,&dg_wire_message->args[4],sizeof(z));
    typedef void (*Proc)(GLuint program, GLint location, GLdouble x, GLdouble y, GLdouble z);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform3d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,x,y,z);
    return 0;
}
case 918: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLdouble x=0;memcpy(&x,&dg_wire_message->args[2],sizeof(x));
    GLdouble y=0;memcpy(&y,&dg_wire_message->args[3],sizeof(y));
    GLdouble z=0;memcpy(&z,&dg_wire_message->args[4],sizeof(z));
    GLdouble w=0;memcpy(&w,&dg_wire_message->args[5],sizeof(w));
    typedef void (*Proc)(GLuint program, GLint location, GLdouble x, GLdouble y, GLdouble z, GLdouble w);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform4d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,x,y,z,w);
    return 0;
}
case 919: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    const GLdouble * value=NULL;
    value=(const GLdouble *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(location==-1 ? 0 : count,1*sizeof(GLdouble))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,1*sizeof(GLdouble))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, const GLdouble *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform1dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,value);
    return 0;
}
case 920: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    const GLdouble * value=NULL;
    value=(const GLdouble *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(location==-1 ? 0 : count,2*sizeof(GLdouble))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,2*sizeof(GLdouble))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, const GLdouble *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform2dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,value);
    return 0;
}
case 921: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    const GLdouble * value=NULL;
    value=(const GLdouble *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(location==-1 ? 0 : count,3*sizeof(GLdouble))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,3*sizeof(GLdouble))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, const GLdouble *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform3dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,value);
    return 0;
}
case 922: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    const GLdouble * value=NULL;
    value=(const GLdouble *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(location==-1 ? 0 : count,4*sizeof(GLdouble))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,4*sizeof(GLdouble))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, const GLdouble *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniform4dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,value);
    return 0;
}
case 923: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[3],sizeof(transpose));
    const GLdouble * value=NULL;
    value=(const GLdouble *)DGHostPointer(dg_wire_message,4,((DGQueryArrayBytes(location==-1 ? 0 : count,4*sizeof(GLdouble))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,4*sizeof(GLdouble))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, GLboolean transpose, const GLdouble *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniformMatrix2dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,transpose,value);
    return 0;
}
case 924: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[3],sizeof(transpose));
    const GLdouble * value=NULL;
    value=(const GLdouble *)DGHostPointer(dg_wire_message,4,((DGQueryArrayBytes(location==-1 ? 0 : count,9*sizeof(GLdouble))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,9*sizeof(GLdouble))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, GLboolean transpose, const GLdouble *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniformMatrix3dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,transpose,value);
    return 0;
}
case 925: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[3],sizeof(transpose));
    const GLdouble * value=NULL;
    value=(const GLdouble *)DGHostPointer(dg_wire_message,4,((DGQueryArrayBytes(location==-1 ? 0 : count,16*sizeof(GLdouble))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,16*sizeof(GLdouble))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, GLboolean transpose, const GLdouble *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniformMatrix4dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,transpose,value);
    return 0;
}
case 926: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[3],sizeof(transpose));
    const GLdouble * value=NULL;
    value=(const GLdouble *)DGHostPointer(dg_wire_message,4,((DGQueryArrayBytes(location==-1 ? 0 : count,6*sizeof(GLdouble))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,6*sizeof(GLdouble))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, GLboolean transpose, const GLdouble *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniformMatrix2x3dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,transpose,value);
    return 0;
}
case 927: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[3],sizeof(transpose));
    const GLdouble * value=NULL;
    value=(const GLdouble *)DGHostPointer(dg_wire_message,4,((DGQueryArrayBytes(location==-1 ? 0 : count,6*sizeof(GLdouble))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,6*sizeof(GLdouble))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, GLboolean transpose, const GLdouble *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniformMatrix3x2dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,transpose,value);
    return 0;
}
case 928: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[3],sizeof(transpose));
    const GLdouble * value=NULL;
    value=(const GLdouble *)DGHostPointer(dg_wire_message,4,((DGQueryArrayBytes(location==-1 ? 0 : count,8*sizeof(GLdouble))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,8*sizeof(GLdouble))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, GLboolean transpose, const GLdouble *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniformMatrix2x4dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,transpose,value);
    return 0;
}
case 929: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[3],sizeof(transpose));
    const GLdouble * value=NULL;
    value=(const GLdouble *)DGHostPointer(dg_wire_message,4,((DGQueryArrayBytes(location==-1 ? 0 : count,8*sizeof(GLdouble))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,8*sizeof(GLdouble))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, GLboolean transpose, const GLdouble *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniformMatrix4x2dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,transpose,value);
    return 0;
}
case 930: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[3],sizeof(transpose));
    const GLdouble * value=NULL;
    value=(const GLdouble *)DGHostPointer(dg_wire_message,4,((DGQueryArrayBytes(location==-1 ? 0 : count,12*sizeof(GLdouble))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,12*sizeof(GLdouble))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, GLboolean transpose, const GLdouble *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniformMatrix3x4dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,transpose,value);
    return 0;
}
case 931: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[2],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[3],sizeof(transpose));
    const GLdouble * value=NULL;
    value=(const GLdouble *)DGHostPointer(dg_wire_message,4,((DGQueryArrayBytes(location==-1 ? 0 : count,12*sizeof(GLdouble))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,12*sizeof(GLdouble))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLuint program, GLint location, GLsizei count, GLboolean transpose, const GLdouble *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glProgramUniformMatrix4x3dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,location,count,transpose,value);
    return 0;
}
case 932: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLdouble x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    typedef void (*Proc)(GLint location, GLdouble x);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform1d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,x);
    return 0;
}
case 933: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLdouble x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    GLdouble y=0;memcpy(&y,&dg_wire_message->args[2],sizeof(y));
    typedef void (*Proc)(GLint location, GLdouble x, GLdouble y);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform2d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,x,y);
    return 0;
}
case 934: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLdouble x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    GLdouble y=0;memcpy(&y,&dg_wire_message->args[2],sizeof(y));
    GLdouble z=0;memcpy(&z,&dg_wire_message->args[3],sizeof(z));
    typedef void (*Proc)(GLint location, GLdouble x, GLdouble y, GLdouble z);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform3d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,x,y,z);
    return 0;
}
case 935: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLdouble x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    GLdouble y=0;memcpy(&y,&dg_wire_message->args[2],sizeof(y));
    GLdouble z=0;memcpy(&z,&dg_wire_message->args[3],sizeof(z));
    GLdouble w=0;memcpy(&w,&dg_wire_message->args[4],sizeof(w));
    typedef void (*Proc)(GLint location, GLdouble x, GLdouble y, GLdouble z, GLdouble w);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform4d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,x,y,z,w);
    return 0;
}
case 936: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    const GLdouble * value=NULL;
    value=(const GLdouble *)DGHostPointer(dg_wire_message,2,((DGQueryArrayBytes(location==-1 ? 0 : count,1*sizeof(GLdouble))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,1*sizeof(GLdouble))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, const GLdouble *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform1dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,value);
    return 0;
}
case 937: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    const GLdouble * value=NULL;
    value=(const GLdouble *)DGHostPointer(dg_wire_message,2,((DGQueryArrayBytes(location==-1 ? 0 : count,2*sizeof(GLdouble))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,2*sizeof(GLdouble))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, const GLdouble *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform2dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,value);
    return 0;
}
case 938: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    const GLdouble * value=NULL;
    value=(const GLdouble *)DGHostPointer(dg_wire_message,2,((DGQueryArrayBytes(location==-1 ? 0 : count,3*sizeof(GLdouble))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,3*sizeof(GLdouble))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, const GLdouble *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform3dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,value);
    return 0;
}
case 939: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    const GLdouble * value=NULL;
    value=(const GLdouble *)DGHostPointer(dg_wire_message,2,((DGQueryArrayBytes(location==-1 ? 0 : count,4*sizeof(GLdouble))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,4*sizeof(GLdouble))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, const GLdouble *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniform4dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,value);
    return 0;
}
case 940: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[2],sizeof(transpose));
    const GLdouble * value=NULL;
    value=(const GLdouble *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(location==-1 ? 0 : count,4*sizeof(GLdouble))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,4*sizeof(GLdouble))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, GLboolean transpose, const GLdouble *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniformMatrix2dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,transpose,value);
    return 0;
}
case 941: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[2],sizeof(transpose));
    const GLdouble * value=NULL;
    value=(const GLdouble *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(location==-1 ? 0 : count,9*sizeof(GLdouble))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,9*sizeof(GLdouble))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, GLboolean transpose, const GLdouble *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniformMatrix3dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,transpose,value);
    return 0;
}
case 942: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[2],sizeof(transpose));
    const GLdouble * value=NULL;
    value=(const GLdouble *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(location==-1 ? 0 : count,16*sizeof(GLdouble))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,16*sizeof(GLdouble))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, GLboolean transpose, const GLdouble *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniformMatrix4dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,transpose,value);
    return 0;
}
case 943: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[2],sizeof(transpose));
    const GLdouble * value=NULL;
    value=(const GLdouble *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(location==-1 ? 0 : count,6*sizeof(GLdouble))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,6*sizeof(GLdouble))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, GLboolean transpose, const GLdouble *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniformMatrix2x3dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,transpose,value);
    return 0;
}
case 944: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[2],sizeof(transpose));
    const GLdouble * value=NULL;
    value=(const GLdouble *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(location==-1 ? 0 : count,6*sizeof(GLdouble))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,6*sizeof(GLdouble))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, GLboolean transpose, const GLdouble *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniformMatrix3x2dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,transpose,value);
    return 0;
}
case 945: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[2],sizeof(transpose));
    const GLdouble * value=NULL;
    value=(const GLdouble *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(location==-1 ? 0 : count,8*sizeof(GLdouble))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,8*sizeof(GLdouble))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, GLboolean transpose, const GLdouble *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniformMatrix2x4dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,transpose,value);
    return 0;
}
case 946: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[2],sizeof(transpose));
    const GLdouble * value=NULL;
    value=(const GLdouble *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(location==-1 ? 0 : count,8*sizeof(GLdouble))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,8*sizeof(GLdouble))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, GLboolean transpose, const GLdouble *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniformMatrix4x2dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,transpose,value);
    return 0;
}
case 947: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[2],sizeof(transpose));
    const GLdouble * value=NULL;
    value=(const GLdouble *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(location==-1 ? 0 : count,12*sizeof(GLdouble))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,12*sizeof(GLdouble))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, GLboolean transpose, const GLdouble *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniformMatrix3x4dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,transpose,value);
    return 0;
}
case 948: {
    GLint location=0;memcpy(&location,&dg_wire_message->args[0],sizeof(location));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    GLboolean transpose=0;memcpy(&transpose,&dg_wire_message->args[2],sizeof(transpose));
    const GLdouble * value=NULL;
    value=(const GLdouble *)DGHostPointer(dg_wire_message,3,((DGQueryArrayBytes(location==-1 ? 0 : count,12*sizeof(GLdouble))) ? (DGQueryArrayBytes(location==-1 ? 0 : count,12*sizeof(GLdouble))) : 1));
    if(!value) return -1;
    typedef void (*Proc)(GLint location, GLsizei count, GLboolean transpose, const GLdouble *value);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniformMatrix4x3dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(location,count,transpose,value);
    return 0;
}
case 950: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLdouble x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    typedef void (*Proc)(GLuint index, GLdouble x);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribL1d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,x);
    return 0;
}
case 951: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLdouble x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    GLdouble y=0;memcpy(&y,&dg_wire_message->args[2],sizeof(y));
    typedef void (*Proc)(GLuint index, GLdouble x, GLdouble y);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribL2d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,x,y);
    return 0;
}
case 952: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLdouble x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    GLdouble y=0;memcpy(&y,&dg_wire_message->args[2],sizeof(y));
    GLdouble z=0;memcpy(&z,&dg_wire_message->args[3],sizeof(z));
    typedef void (*Proc)(GLuint index, GLdouble x, GLdouble y, GLdouble z);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribL3d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,x,y,z);
    return 0;
}
case 953: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLdouble x=0;memcpy(&x,&dg_wire_message->args[1],sizeof(x));
    GLdouble y=0;memcpy(&y,&dg_wire_message->args[2],sizeof(y));
    GLdouble z=0;memcpy(&z,&dg_wire_message->args[3],sizeof(z));
    GLdouble w=0;memcpy(&w,&dg_wire_message->args[4],sizeof(w));
    typedef void (*Proc)(GLuint index, GLdouble x, GLdouble y, GLdouble z, GLdouble w);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribL4d");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,x,y,z,w);
    return 0;
}
case 954: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLdouble * v=NULL;
    v=(const GLdouble *)DGHostPointer(dg_wire_message,1,(1*sizeof(GLdouble)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLdouble *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribL1dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 955: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLdouble * v=NULL;
    v=(const GLdouble *)DGHostPointer(dg_wire_message,1,(2*sizeof(GLdouble)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLdouble *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribL2dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 956: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLdouble * v=NULL;
    v=(const GLdouble *)DGHostPointer(dg_wire_message,1,(3*sizeof(GLdouble)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLdouble *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribL3dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 957: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    const GLdouble * v=NULL;
    v=(const GLdouble *)DGHostPointer(dg_wire_message,1,(4*sizeof(GLdouble)));
    if(!v) return -1;
    typedef void (*Proc)(GLuint index, const GLdouble *v);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glVertexAttribL4dv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,v);
    return 0;
}
case 959: {
    GLuint index=0;memcpy(&index,&dg_wire_message->args[0],sizeof(index));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[1],sizeof(pname));
    GLdouble * params=NULL;
    params=(GLdouble *)DGHostPointer(dg_wire_message,2,((DGVertexAttribCount(pname) ? DGVertexAttribCount(pname)*sizeof(GLdouble) : SIZE_MAX) ? (DGVertexAttribCount(pname) ? DGVertexAttribCount(pname)*sizeof(GLdouble) : SIZE_MAX) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLuint index, GLenum pname, GLdouble *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetVertexAttribLdv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(index,pname,params);
    return 0;
}
case 960: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLenum shadertype=0;memcpy(&shadertype,&dg_wire_message->args[1],sizeof(shadertype));
    const GLchar * name=DGHostString(dg_wire_message,2);if(!name) return -1;
    typedef GLint (*Proc)(GLuint program, GLenum shadertype, const GLchar *name);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetSubroutineUniformLocation");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLint result=proc(program,shadertype,name);
    reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 961: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLenum shadertype=0;memcpy(&shadertype,&dg_wire_message->args[1],sizeof(shadertype));
    const GLchar * name=DGHostString(dg_wire_message,2);if(!name) return -1;
    typedef GLuint (*Proc)(GLuint program, GLenum shadertype, const GLchar *name);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetSubroutineIndex");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLuint result=proc(program,shadertype,name);
    reply->result=DGBits(&result,sizeof(result));
    return 0;
}
case 962: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLenum shadertype=0;memcpy(&shadertype,&dg_wire_message->args[1],sizeof(shadertype));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[2],sizeof(index));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[3],sizeof(pname));
    if(dg_wire_message->args[14]>DG_MAX_BYTES/sizeof(GLint))return -1;
    GLint compatible_count=(GLint)dg_wire_message->args[14];
    if(pname!=0x8e4b && compatible_count!=1)return -1;
    if(pname==0x8e4b && !DGHostSubroutineCapacity(context,program,shadertype,index,compatible_count))return 0;
    GLint * values=NULL;
    values=(GLint *)DGHostPointer(dg_wire_message,4,((DGQueryArrayBytes(compatible_count,sizeof(GLint))) ? (DGQueryArrayBytes(compatible_count,sizeof(GLint))) : 1));
    if(!values) return -1;
    typedef void (*Proc)(GLuint program, GLenum shadertype, GLuint index, GLenum pname, GLint *values);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetActiveSubroutineUniformiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,shadertype,index,pname,values);
    return 0;
}
case 963: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLenum shadertype=0;memcpy(&shadertype,&dg_wire_message->args[1],sizeof(shadertype));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[2],sizeof(index));
    GLsizei bufsize=0;memcpy(&bufsize,&dg_wire_message->args[3],sizeof(bufsize));
    GLsizei * length=NULL;
    GLchar * name=NULL;
    length=(GLsizei *)DGHostPointer(dg_wire_message,4,((sizeof(GLsizei)) ? (sizeof(GLsizei)) : 1));
    if(dg_wire_message->args[4] && !length) return -1;
    name=(GLchar *)DGHostPointer(dg_wire_message,5,((DGQueryArrayBytes(bufsize,1)) ? (DGQueryArrayBytes(bufsize,1)) : 1));
    if(!name) return -1;
    typedef void (*Proc)(GLuint program, GLenum shadertype, GLuint index, GLsizei bufsize, GLsizei *length, GLchar *name);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetActiveSubroutineUniformName");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,shadertype,index,bufsize,length,name);
    return 0;
}
case 964: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLenum shadertype=0;memcpy(&shadertype,&dg_wire_message->args[1],sizeof(shadertype));
    GLuint index=0;memcpy(&index,&dg_wire_message->args[2],sizeof(index));
    GLsizei bufsize=0;memcpy(&bufsize,&dg_wire_message->args[3],sizeof(bufsize));
    GLsizei * length=NULL;
    GLchar * name=NULL;
    length=(GLsizei *)DGHostPointer(dg_wire_message,4,((sizeof(GLsizei)) ? (sizeof(GLsizei)) : 1));
    if(dg_wire_message->args[4] && !length) return -1;
    name=(GLchar *)DGHostPointer(dg_wire_message,5,((DGQueryArrayBytes(bufsize,1)) ? (DGQueryArrayBytes(bufsize,1)) : 1));
    if(!name) return -1;
    typedef void (*Proc)(GLuint program, GLenum shadertype, GLuint index, GLsizei bufsize, GLsizei *length, GLchar *name);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetActiveSubroutineName");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,shadertype,index,bufsize,length,name);
    return 0;
}
case 965: {
    GLenum shadertype=0;memcpy(&shadertype,&dg_wire_message->args[0],sizeof(shadertype));
    GLsizei count=0;memcpy(&count,&dg_wire_message->args[1],sizeof(count));
    const GLuint * indices=NULL;
    indices=(const GLuint *)DGHostPointer(dg_wire_message,2,((DGQueryArrayBytes(count,sizeof(GLuint))) ? (DGQueryArrayBytes(count,sizeof(GLuint))) : 1));
    if(!indices) return -1;
    typedef void (*Proc)(GLenum shadertype, GLsizei count, const GLuint *indices);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glUniformSubroutinesuiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(shadertype,count,indices);
    return 0;
}
case 966: {
    GLenum shadertype=0;memcpy(&shadertype,&dg_wire_message->args[0],sizeof(shadertype));
    GLint location=0;memcpy(&location,&dg_wire_message->args[1],sizeof(location));
    GLuint * params=NULL;
    params=(GLuint *)DGHostPointer(dg_wire_message,2,((sizeof(GLuint)) ? (sizeof(GLuint)) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum shadertype, GLint location, GLuint *params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetUniformSubroutineuiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(shadertype,location,params);
    return 0;
}
case 967: {
    GLuint program=0;memcpy(&program,&dg_wire_message->args[0],sizeof(program));
    GLenum shadertype=0;memcpy(&shadertype,&dg_wire_message->args[1],sizeof(shadertype));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[2],sizeof(pname));
    GLint * values=NULL;
    values=(GLint *)DGHostPointer(dg_wire_message,3,((sizeof(GLint)) ? (sizeof(GLint)) : 1));
    if(!values) return -1;
    typedef void (*Proc)(GLuint program, GLenum shadertype, GLenum pname, GLint *values);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetProgramStageiv");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(program,shadertype,pname,values);
    return 0;
}
case 968: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLenum internalformat=0;memcpy(&internalformat,&dg_wire_message->args[1],sizeof(internalformat));
    GLenum pname=0;memcpy(&pname,&dg_wire_message->args[2],sizeof(pname));
    GLsizei bufSize=0;memcpy(&bufSize,&dg_wire_message->args[3],sizeof(bufSize));
    GLint* params=NULL;
    params=(GLint*)DGHostPointer(dg_wire_message,4,((DGQueryArrayBytes(bufSize,sizeof(GLint))) ? (DGQueryArrayBytes(bufSize,sizeof(GLint))) : 1));
    if(!params) return -1;
    typedef void (*Proc)(GLenum target, GLenum internalformat, GLenum pname, GLsizei bufSize, GLint* params);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glGetInternalformativ");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,internalformat,pname,bufSize,params);
    return 0;
}
case 969: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLsizei levels=0;memcpy(&levels,&dg_wire_message->args[1],sizeof(levels));
    GLenum internalformat=0;memcpy(&internalformat,&dg_wire_message->args[2],sizeof(internalformat));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[3],sizeof(width));
    typedef void (*Proc)(GLenum target, GLsizei levels, GLenum internalformat, GLsizei width);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexStorage1D");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,levels,internalformat,width);
    return 0;
}
case 970: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLsizei levels=0;memcpy(&levels,&dg_wire_message->args[1],sizeof(levels));
    GLenum internalformat=0;memcpy(&internalformat,&dg_wire_message->args[2],sizeof(internalformat));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[3],sizeof(width));
    GLsizei height=0;memcpy(&height,&dg_wire_message->args[4],sizeof(height));
    typedef void (*Proc)(GLenum target, GLsizei levels, GLenum internalformat, GLsizei width, GLsizei height);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexStorage2D");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    GLuint redefining_alias=DGBeginAliasRedefinition(context,target,0);
    proc(target,levels,internalformat,width,height);
    DGEndAliasRedefinition(context,redefining_alias);
    return 0;
}
case 971: {
    GLenum target=0;memcpy(&target,&dg_wire_message->args[0],sizeof(target));
    GLsizei levels=0;memcpy(&levels,&dg_wire_message->args[1],sizeof(levels));
    GLenum internalformat=0;memcpy(&internalformat,&dg_wire_message->args[2],sizeof(internalformat));
    GLsizei width=0;memcpy(&width,&dg_wire_message->args[3],sizeof(width));
    GLsizei height=0;memcpy(&height,&dg_wire_message->args[4],sizeof(height));
    GLsizei depth=0;memcpy(&depth,&dg_wire_message->args[5],sizeof(depth));
    typedef void (*Proc)(GLenum target, GLsizei levels, GLenum internalformat, GLsizei width, GLsizei height, GLsizei depth);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTexStorage3D");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc(target,levels,internalformat,width,height,depth);
    return 0;
}
case 973: {
    typedef void (*Proc)(void);
    static Proc proc;if(!proc) proc=(Proc)dlsym(RTLD_DEFAULT,"glTextureBarrierNV");
    if(!proc) { context->error=GL_INVALID_OPERATION;return 0; }
    proc();
    DGRefreshFlippedAliases(context,0);
    return 0;
}
